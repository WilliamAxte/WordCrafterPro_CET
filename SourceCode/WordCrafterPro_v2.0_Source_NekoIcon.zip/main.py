# ==============================================================================
# WordCrafter Pro — 启动入口（PySide6 / Qt6 渲染核心）
# 运行方式: python main.py
# ==============================================================================
import os
import sys

APP_DIR = os.path.dirname(os.path.abspath(__file__))
if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

from PySide6.QtWidgets import QApplication

from wordcrafter.qt.chrome import MainWindow


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("WordCrafter Pro")
    app.setStyle("Fusion")
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
