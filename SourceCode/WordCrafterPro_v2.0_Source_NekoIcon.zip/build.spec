# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all

datas = []
binaries = []
hiddenimports = [
    # --- wordcrafter 包结构（Qt6 UI 内核） ---
    'wordcrafter',
    'wordcrafter.webui',
    'wordcrafter.resources',
    'wordcrafter.core',
    'wordcrafter.core.repository',
    'wordcrafter.core.session',
    'wordcrafter.core.srs',
    'wordcrafter.core.study',
    'wordcrafter.core.deck',
    'wordcrafter.core.folders',
    'wordcrafter.core.text_utils',
    'wordcrafter.core.dictionary_store',
    'wordcrafter.theme',
    'wordcrafter.theme.palette',
    'wordcrafter.theme.presets',
    'wordcrafter.theme.light',
    'wordcrafter.theme.dark',
    'wordcrafter.theme.tokens',
    'wordcrafter.services',
    'wordcrafter.services.ai',
    'wordcrafter.services.definitions',
    'wordcrafter.services.dictionary',
    'wordcrafter.services.wordbooks',
    'wordcrafter.services.microsoft',
    'wordcrafter.services.updater',
    'wordcrafter.qt',
    'wordcrafter.qt.backdrop',
    'wordcrafter.qt.context',
    'wordcrafter.qt.theme',
    'wordcrafter.qt.widgets',
    'wordcrafter.qt.chrome',
    'wordcrafter.qt.newspaper',
    'wordcrafter.qt.immersion',
    'wordcrafter.qt.renderer',
    'wordcrafter.qt.typography',
    'wordcrafter.qt.vocab_dialog',
    'wordcrafter.qt.pages',
    'wordcrafter.qt.pages.acg_page',
    'wordcrafter.qt.pages.dictionary_page',
    'wordcrafter.qt.pages.reading_page',
    'wordcrafter.qt.pages.settings_page',
    'wordcrafter.qt.pages.study_page',
    'wordcrafter.qt.pages.vocab_page',
    # --- 第三方库 ---
    'PySide6',
]

block_cipher = None

# 图标资源随包分发（运行时 QIcon 需要 png/ico）
datas += [('assets', 'assets')]

a = Analysis(
    ['main.py'],
    pathex=['.'],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='WordCrafterPro',
    icon='assets/app_icon.ico',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='WordCrafterPro',
)
