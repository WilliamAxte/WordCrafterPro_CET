# ==============================================================================
# 文件路径: wordcrafter/qt/backdrop.py
# WindowEffectsManager（统一毛玻璃抽象）
#   - 优先：Windows 11 Mica（DWM backdrop，无窗口透明风险）
#   - 不支持时：自动 fallback（保持现有不透明主题背景），绝不产生黑屏/黑块
# 稳定性原则：本模块从不改变 Qt 窗口透明度或 frameless 状态。
# ==============================================================================
import ctypes
import platform
import sys


class BackdropManager:
    """统一管理 Windows DWM 背景效果（Mica / Acrylic 尽力而为）。"""

    DWMWA_SYSTEMBACKDROP_TYPE = 38   # Win11 22621+
    DWMSBT_MAINWINDOW = 2            # Mica

    @staticmethod
    def supported():
        if sys.platform != "win32":
            return False
        try:
            ver = platform.version()          # e.g. 10.0.22621...
            parts = ver.split(".")
            if len(parts) >= 3:
                build = int(parts[2])
                return build >= 22621
        except Exception:
            return False
        return False

    @classmethod
    def apply_mica(cls, qwindow):
        """尽力启用 Mica；任何失败都返回 False（UI 保持现有样式）。"""
        if not cls.supported():
            return False
        try:
            hwnd = int(qwindow.winId())
            value = ctypes.c_int(cls.DWMSBT_MAINWINDOW)
            ok = ctypes.windll.dwmapi.DwmSetWindowAttribute(
                hwnd, cls.DWMWA_SYSTEMBACKDROP_TYPE,
                ctypes.byref(value), ctypes.sizeof(value))
            return ok == 0
        except Exception:
            return False

    @classmethod
    def apply(cls, qwindow):
        """入口：Mica（Win11）→ 其它系统无操作（透明样式保留）。"""
        try:
            ok = cls.apply_mica(qwindow)
        except Exception:
            ok = False
        return ok
