# ==============================================================================
# 文件路径: wordcrafter/qt/context.py
# Qt 应用上下文：与 core/AppConfig 等价的配置/数据访问，
# 但不依赖 Tk/customtkinter（字体与色板由 Qt 样式表承载）。
# ==============================================================================
from ..core.dictionary_store import DictionaryStore
from ..core.repository import ConfigRepository, VocabRepository
from ..theme.palette import build_palette


class QtConfig:
    """Qt UI 的应用配置门面（字段语义与 core.app_config.AppConfig 对齐）。"""

    def __init__(self):
        self.config_repo = ConfigRepository()
        self.vocab_repo = VocabRepository()
        self.font_family = "Microsoft YaHei UI"
        accent = self.config_repo.data.get("theme_accent", "indigo") or "indigo"
        self.apply_accent(accent, persist=False)

    # ---------- 色板 ----------
    def apply_accent(self, accent, persist=True):
        from ..theme.presets import ACCENTS
        if accent not in ACCENTS:
            accent = "indigo"
        if persist:
            self.config_repo.save_all({"theme_accent": accent})
        self.accent_id = accent
        T = build_palette(accent)
        self.c_primary = T["accent"]
        self.c_primary_hover = T["accent_hover"]
        self.c_on_primary = T["on_accent"]
        self.c_secondary = T["accent_soft"]
        self.c_on_secondary = T["on_accent_soft"]
        self.c_bg_window = T["bg"]
        self.c_surface = T["surface"]
        self.c_surface_variant = T["surface_alt"]
        self.c_input_bg = T["input"]
        self.c_border = T["border"]
        self.c_border_light = T["border_subtle"]
        self.c_btn = T["surface_alt"]
        self.c_btn_hover = T["control_hover"]
        self.c_btn_del = T["danger_bg"]
        self.c_btn_del_hover = T["danger_bg_hover"]
        self.c_success = T["success"]
        self.c_success_bg = T["success_bg"]
        self.c_error = T["danger"]
        self.c_error_bg = T["danger_bg"]
        self.c_text = T["text"]
        self.c_text_secondary = T["text_secondary"]
        self.c_text_muted = T["text_muted"]

    # ---------- 属性（与 AppConfig 语义一致） ----------
    @property
    def appearance_mode(self):
        mode = self.config_repo.data.get("appearance_mode", "深色模式")
        return {"浅色模式": "Light", "跟随系统": "System"}.get(mode, "Dark")

    @property
    def gpu_enabled(self):
        return bool(self.config_repo.data.get("gpu_acceleration", True))

    @property
    def wallpaper_path(self):
        return self.config_repo.data.get("wallpaper_path", "")

    @property
    def wallpaper_blur(self):
        return int(self.config_repo.data.get("wallpaper_blur", 12))

    @property
    def wallpaper_opacity(self):
        return float(self.config_repo.data.get("wallpaper_opacity", 0.45))

    @property
    def translate_engine(self):
        return self.config_repo.data.get("translate_engine", "AI 智能模型")

    @property
    def ms_translator_key(self):
        return self.config_repo.data.get("ms_translator_key", "")

    @property
    def ms_translator_region(self):
        return self.config_repo.data.get("ms_translator_region", "global")

    @property
    def ms_speech_key(self):
        return self.config_repo.data.get("ms_speech_key", "")

    @property
    def ms_speech_region(self):
        return self.config_repo.data.get("ms_speech_region", "eastasia")

    @property
    def ms_voice_name(self):
        return self.config_repo.data.get("ms_voice_name", "en-US-JennyNeural")

    @property
    def api_url(self):
        return self.config_repo.data.get("api_url", "")

    @property
    def api_key(self):
        return self.config_repo.data.get("api_key", "")

    @property
    def model_name(self):
        return self.config_repo.data.get("model_name", "deepseek-chat")

    @property
    def difficulty(self):
        return self.config_repo.data.get("difficulty", "初高中/日常通俗 (周围词汇极简)")

    @property
    def dictionary_enabled_sources(self):
        val = self.config_repo.data.get("dictionary_enabled_sources")
        if isinstance(val, list):
            return [str(x) for x in val]
        return ["wiktionary", "freedict"]

    @property
    def vocab_history(self):
        return self.vocab_repo.history

    @property
    def vocab_cache(self):
        return self.vocab_repo.cache

    @property
    def dictionary_store(self):
        store = getattr(self, "_dictionary_store", None)
        if store is None:
            store = DictionaryStore()
            self._dictionary_store = store
        return store

    def save_config(self, url, key, model, diff):
        self.config_repo.save(url, key, model, diff)
