# ==============================================================================
# 文件路径: wordcrafter/qt/widgets.py
# Qt 通用组件：按钮工厂 · 空态 · Toast · 流式缓冲 · 查词弹窗
# ==============================================================================
import os

from PySide6.QtCore import QObject, QPointF, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QBrush, QColor, QIcon, QImage, QPainter, QPainterPath, QPen, QPixmap, QPolygonF
from PySide6.QtWidgets import (QDialog, QFrame, QGraphicsOpacityEffect, QHBoxLayout,
                               QLabel, QPushButton, QVBoxLayout)

from ..core.text_utils import parse_words
from ..services.definitions import DictionaryService
from ..services.pronunciation import PronunciationService
from .theme import is_light_mode


def make_button(text, kind="secondary", command=None, parent=None):
    btn = QPushButton(text, parent)
    btn.setProperty("btnClass", kind)
    btn.setCursor(Qt.PointingHandCursor)
    if command:
        btn.clicked.connect(command)
    return btn


def make_pill(text, parent=None, checked=False):
    btn = QPushButton(text, parent)
    btn.setProperty("pill", "true")
    btn.setCheckable(True)
    btn.setChecked(checked)
    btn.setCursor(Qt.PointingHandCursor)
    return btn


def make_emoji_icon(text, command=None, tip=None, size=30):
    """纯图标按钮（🔊 等）：使用 Segoe UI Emoji 字体，避免字形缺失不可见。"""
    from PySide6.QtGui import QFont
    btn = QPushButton(text)
    btn.setFont(QFont("Segoe UI Emoji", 13))
    # 用白色矢量喇叭图标，避免 Windows 在亮色模式下把 emoji/系统图标
    # 渲染成白色或黑色而与背景融在一起。
    pix = QPixmap(18, 18)
    pix.fill(Qt.transparent)
    painter = QPainter(pix)
    painter.setRenderHint(QPainter.Antialiasing)
    white = QColor("#FFFFFF")
    painter.setPen(QPen(white, 1.8, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
    painter.setBrush(QBrush(white))
    painter.drawRect(2, 7, 4, 4)
    painter.drawPolygon(QPolygonF([QPointF(6, 7), QPointF(11, 3),
                                   QPointF(11, 15), QPointF(6, 11)]))
    path = QPainterPath()
    path.moveTo(13, 6)
    path.arcTo(9, 5, 9, 9, 45, -90)
    painter.drawPath(path)
    path2 = QPainterPath()
    path2.moveTo(15, 3)
    path2.arcTo(8, 2, 14, 14, 45, -90)
    painter.drawPath(path2)
    painter.end()
    btn.setIcon(QIcon(pix))
    btn.setIconSize(QSize(17, 17))
    btn.setProperty("audioButton", "true")
    btn.setFixedSize(size, size)
    btn.setCursor(Qt.PointingHandCursor)
    btn.setFocusPolicy(Qt.NoFocus)
    if tip:
        btn.setToolTip(tip)
    if command:
        btn.clicked.connect(command)
    return btn


def _grayscale_keep_alpha(pm):
    """灰度化但保留 alpha（避免 Format_Grayscale8 丢透明变成黑方块）。"""
    img = pm.toImage().convertToFormat(QImage.Format_ARGB32)
    w, h = img.width(), img.height()
    for y in range(h):
        for x in range(w):
            c = img.pixelColor(x, y)
            g = int(0.299 * c.red() + 0.587 * c.green() + 0.114 * c.blue())
            img.setPixelColor(x, y, QColor(g, g, g, c.alpha()))
    return QPixmap.fromImage(img)


def make_image_icon_button(image_path, command=None, size=30):
    """用图片文件作图标按钮：开启=原色，关闭=灰度（保留透明，单图标无文字）。"""
    btn = QPushButton()
    btn.setProperty("btnClass", "ghost")
    btn.setFixedSize(size, size)
    btn.setCursor(Qt.PointingHandCursor)
    btn.setFocusPolicy(Qt.NoFocus)
    btn._on = True
    btn._image_path = image_path
    px = int(size * 0.9)

    def _pix(on):
        pm = None
        if image_path and os.path.exists(image_path):
            raw = QPixmap(image_path)
            if not raw.isNull():
                # 高分辨率下平滑缩小，避免发糊
                pm = raw.scaled(int(px * 2), int(px * 2),
                                Qt.KeepAspectRatio, Qt.SmoothTransformation)
                pm = pm.scaled(px, px, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                if not on:
                    pm = _grayscale_keep_alpha(pm)
        if pm is None:
            pm = _wifi_pixmap("#8E8E98", px)
        return QIcon(pm)

    btn._icon_on = _pix(True)
    btn._icon_off = _pix(False)

    def _paint():
        btn.setIcon(btn._icon_on if btn._on else btn._icon_off)
        btn.setIconSize(QSize(px, px))

    def set_state(on, _accent=None):
        btn._on = bool(on)
        _paint()

    btn.set_state = set_state
    if command:
        btn.clicked.connect(command)
    _paint()
    return btn


def _wifi_pixmap(color, size=20):
    """自绘简洁 WiFi：底部圆点 + 三条同心弧（矢量，主题一致）。"""
    from PySide6.QtCore import QRectF
    pix = QPixmap(size, size)
    pix.fill(Qt.transparent)
    painter = QPainter(pix)
    painter.setRenderHint(QPainter.Antialiasing)
    col = QColor(color)
    pen = QPen(col, max(1.5, size / 12.0), Qt.SolidLine, Qt.RoundCap)
    painter.setPen(pen)
    cx, cy = size / 2.0, size - size / 8.0
    for r in sorted([size * 0.52, size * 0.36, size * 0.21], reverse=True):
        painter.drawArc(QRectF(cx - r, cy - r, 2 * r, 2 * r), int(205 * 16), int(130 * 16))
    painter.setPen(Qt.NoPen)
    painter.setBrush(col)
    d = max(2.4, size / 8.0)
    painter.drawEllipse(QRectF(cx - d / 2, cy - d / 2, d, d))
    painter.end()
    return pix


def make_wifi_button(command=None, size=30):
    """单个 WiFi 开关按钮：关=灰、开=主题强调色（纯图标，无文字）。"""
    btn = QPushButton()
    btn.setProperty("btnClass", "ghost")
    btn.setFixedSize(size, size)
    btn.setCursor(Qt.PointingHandCursor)
    btn.setFocusPolicy(Qt.NoFocus)
    btn._on = False
    btn._accent = "#4F46E5"

    def _paint():
        color = btn._accent if btn._on else "#8E8E98"
        btn.setIcon(QIcon(_wifi_pixmap(color, int(size * 0.74))))
        btn.setIconSize(QSize(int(size * 0.74), int(size * 0.74)))

    def set_state(on, accent=None):
        btn._on = bool(on)
        if accent:
            btn._accent = accent
        _paint()

    btn.set_state = set_state
    if command:
        btn.clicked.connect(command)
    _paint()
    return btn


def cfg_hex(cfg, role):
    """取当前模式下语义色的具体 hex（浅=元组0 深=元组1）。"""
    idx = 0 if is_light_mode(cfg) else 1
    return getattr(cfg, "c_" + role, ("#888888", "#888888"))[idx]


class EmptyState(QFrame):
    def __init__(self, cfg, icon="📭", title="暂无内容", subtitle="开始一次新的学习任务吧",
                 action_label=None, action_command=None, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        lay = QVBoxLayout(self)
        lay.setAlignment(Qt.AlignCenter)
        lay.setSpacing(6)
        self.lbl_icon = QLabel(icon)
        self.lbl_icon.setStyleSheet("font-size: 40px;")
        lay.addWidget(self.lbl_icon, 0, Qt.AlignCenter)
        self.lbl_title = QLabel(title)
        self.lbl_title.setStyleSheet("font-size: 16px; font-weight: 600;")
        lay.addWidget(self.lbl_title, 0, Qt.AlignCenter)
        self.lbl_sub = QLabel(subtitle)
        self.lbl_sub.setObjectName("muted")
        self.lbl_sub.setAlignment(Qt.AlignCenter)
        self.lbl_sub.setWordWrap(True)
        lay.addWidget(self.lbl_sub, 0, Qt.AlignCenter)
        if action_label and action_command:
            btn = make_button(action_label, "primary", action_command, self)
            btn.setFixedHeight(34)
            lay.addWidget(btn, 0, Qt.AlignCenter)


class ToastHost(QObject):
    """右上角 Toast（淡入淡出，自动消失）。"""

    def __init__(self, anchor, cfg):
        super().__init__(anchor)
        self.anchor = anchor
        self.cfg = cfg
        self._labels = []

    def show(self, message, kind="info", duration=2600):
        bg = cfg_hex(self.cfg, {"info": "surface_variant", "success": "success_bg",
                                "error": "error_bg"}.get(kind, "surface_variant"))
        fg = cfg_hex(self.cfg, {"info": "text_secondary", "success": "success",
                                "error": "error"}.get(kind, "text_secondary"))
        icon = {"info": "ℹ", "success": "✓", "error": "✕"}.get(kind, "ℹ")
        lbl = QLabel(f"{icon}  {message}", self.anchor)
        lbl.setStyleSheet(f"background: {bg}; color: {fg}; border-radius: 10px;"
                          f"padding: 8px 16px; font-size: 12px;")
        lbl.adjustSize()
        idx = len(self._labels)
        lbl.move(self.anchor.width() - lbl.width() - 18, 16 + idx * 56)
        lbl.raise_()
        lbl.show()
        self._labels.append(lbl)
        effect = QGraphicsOpacityEffect(lbl)
        lbl.setGraphicsEffect(effect)
        effect.setOpacity(0.0)
        self._fade(effect, 0.0, 1.0, 10, 18)
        QTimer.singleShot(duration, lambda: self._close(lbl, effect))

    def _fade(self, effect, start, end, steps, ms):
        step = [0]

        def _tick():
            step[0] += 1
            effect.setOpacity(start + (end - start) * (step[0] / steps))
            if step[0] < steps:
                QTimer.singleShot(ms, _tick)

        _tick()

    def _close(self, lbl, effect):
        self._fade(effect, 1.0, 0.0, 8, 20)
        QTimer.singleShot(8 * 20 + 40, lambda: self._remove(lbl))

    def _remove(self, lbl):
        if lbl in self._labels:
            self._labels.remove(lbl)
        lbl.deleteLater()
        for i, other in enumerate(self._labels):
            other.move(self.anchor.width() - other.width() - 18, 16 + i * 56)


# ---------- 流式缓冲：把后台线程 Router 输出转为主线程文本追加 ----------
class ChunkSink(QObject):
    """跨线程流式缓冲：主线程创建，chunk 信号自动排队回主线程。"""

    chunk = Signal(str)

    def insert(self, index, text):
        if index == "end" and text:
            self.chunk.emit(text)


# ---------- 富文本编辑辅助（多页共享） ----------
def style_scroll(area):
    """让 QScrollArea 无边框、viewport 透明（随主题背景，避免黑底）。"""
    from PySide6.QtWidgets import QFrame
    area.setFrameShape(QFrame.NoFrame)
    vp = area.viewport()
    vp.setAutoFillBackground(False)
    area.setStyleSheet("QScrollArea { background: transparent; border: none; }")
    return area


def append_text(edit, text):
    """在 QPlainTextEdit/QTextEdit 末尾追加文本并保持滚动到底部。"""
    from PySide6.QtGui import QTextCursor
    cursor = edit.textCursor()
    cursor.movePosition(QTextCursor.End)
    cursor.insertText(text)
    edit.setTextCursor(cursor)
    sb = edit.verticalScrollBar()
    sb.setValue(sb.maximum())


def word_at_pos(edit, pos):
    from PySide6.QtGui import QTextCursor
    import re
    cursor = edit.cursorForPosition(pos)
    cursor.select(QTextCursor.WordUnderCursor)
    text = cursor.selectedText().strip()
    clean = re.sub(r"[^a-zA-Z\-]", "", text).lower()
    return clean


def attach_text_menu(edit, cfg, app):
    """右键菜单：查词 / 朗读 / 收入生词库（无选中词时显示默认菜单）。"""
    from PySide6.QtGui import QAction
    from PySide6.QtWidgets import QMenu
    edit.setContextMenuPolicy(Qt.CustomContextMenu)

    def _menu(pos):
        cursor = edit.textCursor()
        selection = cursor.selectedText().strip() if cursor.hasSelection() else ""
        word = word_at_pos(edit, pos)
        menu = QMenu(edit)
        target = selection or word
        if target:
            act_lookup = QAction(f"🔍 查词：{target[:24]}", edit)
            act_lookup.triggered.connect(lambda: LookupDialog(app, cfg, app, target).exec())
            menu.addAction(act_lookup)
            act_speak = QAction("🔊 朗读", edit)
            act_speak.triggered.connect(lambda: PronunciationService.play(target, cfg))
            menu.addAction(act_speak)
            act_add = QAction("＋ 收入生词库", edit)
            act_add.triggered.connect(lambda: add_word(app, cfg, target))
            menu.addAction(act_add)
        else:
            menu.addActions(edit.createStandardContextMenu().actions())
        menu.exec(edit.viewport().mapToGlobal(pos))

    edit.customContextMenuRequested.connect(_menu)


def add_word(app, cfg, word):
    from ..core.text_utils import parse_words
    try:
        cfg.vocab_repo.add_words(parse_words(word))
        if app is not None and hasattr(app, "update_global_vocab_status"):
            app.update_global_vocab_status()
        if app is not None and hasattr(app, "toasts"):
            app.toasts.show(f"已收入生词库：{word}", kind="success")
    except Exception:
        pass


# ---------- 查词弹窗 ----------
class LookupDialog(QDialog):
    """划词查词弹窗（统一查词服务，后台线程结果经信号回主线程）。"""

    _result_ready = Signal(object)

    def __init__(self, parent, cfg, app, word):
        super().__init__(parent)
        self.cfg = cfg
        self.app = app
        self.word = word.strip()
        self.setWindowTitle(f"词典 · {self.word}")
        self.setMinimumWidth(460)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 16, 20, 16)

        head = QHBoxLayout()
        lbl = QLabel(self.word)
        lbl.setStyleSheet("font-size: 20px; font-weight: 700; color: %s;"
                          % cfg_hex(cfg, "primary"))
        head.addWidget(lbl)
        head.addStretch(1)
        btn_speak = make_button("🔊 朗读", "ghost", self._speak, self)
        head.addWidget(btn_speak)
        btn_add = make_button("＋ 收入生词库", "secondary", self._add, self)
        head.addWidget(btn_add)
        lay.addLayout(head)

        self.lbl_phonetic = QLabel("…")
        self.lbl_phonetic.setObjectName("muted")
        lay.addWidget(self.lbl_phonetic)

        self.txt = QLabel("正在解析…")
        self.txt.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.txt.setWordWrap(True)
        lay.addWidget(self.txt, 1)

        self.status = QLabel("")
        self.status.setObjectName("muted")
        lay.addWidget(self.status)

        self._result_ready.connect(self._apply)
        DictionaryService.lookup_async(self.word, cfg,
                                       lambda entry, layer: self._result_ready.emit((entry, layer)))

    def _apply(self, payload):
        entry, layer = payload
        if not entry:
            entry = {"phonetic": "", "pos_def": "未查询到释义，可在设置中配置词典源。", "example": ""}
        elif layer == "online":
            try:
                self.cfg.vocab_repo.cache[self.word.lower()] = entry
                self.cfg.vocab_repo.save_cache()
            except Exception:
                pass
        self.lbl_phonetic.setText(entry.get("phonetic", ""))
        body = f"【核心释义】\n{entry.get('pos_def', '')}\n\n【典型例句】\n{entry.get('example', '')}"
        self.txt.setText(body)

    def _speak(self):
        PronunciationService.play(self.word, self.cfg)

    def _add(self):
        try:
            self.cfg.vocab_repo.add_words(parse_words(self.word))
            if self.app is not None and hasattr(self.app, "update_global_vocab_status"):
                self.app.update_global_vocab_status()
        except Exception:
            pass
        self.status.setText("✓ 已收入生词库")
