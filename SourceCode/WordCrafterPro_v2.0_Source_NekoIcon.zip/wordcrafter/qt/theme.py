# ==============================================================================
# 文件路径: wordcrafter/qt/theme.py
# 设计令牌 → QSS：把 wordcrafter/theme 的语义色板渲染成 Qt 样式表
# ==============================================================================
from ..theme.palette import resolve
from ..theme.presets import ACCENTS
from ..theme import tokens as TKN

FONT_FAMILY = "Microsoft YaHei UI"


def is_light_mode(cfg):
    mode = cfg.appearance_mode
    if mode == "浅色模式":
        return True
    if mode == "深色模式":
        return False
    # 跟随系统：用 Qt 系统配色方案
    try:
        from PySide6.QtGui import QGuiApplication
        scheme = QGuiApplication.styleHints().colorScheme()
        from PySide6.QtCore import Qt
        return scheme == Qt.ColorScheme.Light
    except Exception:
        return True


def build_palette(cfg):
    """返回当前模式/强调色下的具体 hex dict。"""
    return resolve(is_light_mode(cfg), getattr(cfg, "accent_id", "indigo"))


def qss(cfg):
    """生成整窗样式表。"""
    c = build_palette(cfg)
    f = FONT_FAMILY
    light = is_light_mode(cfg)
    # 主窗口已经对壁纸做了整体模糊；面板使用半透明底色和边框，
    # 让所有模块共享一致的 Frosted Glass 观感，同时避免透明窗口黑屏。
    glass_surface = "rgba(255, 255, 255, 220)" if light else "rgba(31, 31, 34, 224)"
    glass_input = "rgba(255, 255, 255, 196)" if light else "rgba(32, 32, 36, 214)"
    return f"""
* {{ font-family: "{f}"; }}
QWidget {{ background: transparent; color: {c['text']}; }}
QMainWindow {{ background: {c['bg']}; }}
QWidget#bg {{ background: transparent; }}
QDialog, QMessageBox, QInputDialog {{ background: {c['bg']}; }}
QFrame#surface {{ background: {glass_surface}; border: 1px solid {c['border']}; border-radius: {TKN.RADIUS['panel']}px; }}
QFrame#card {{ background: {glass_surface}; border: 1px solid {c['border_subtle']}; border-radius: {TKN.RADIUS['card']}px; }}
QFrame#bar {{ background: {glass_surface}; border: 1px solid {c['border_subtle']}; border-radius: {TKN.RADIUS['card']}px; }}
QLabel {{ background: transparent; }}
QLabel#muted {{ color: {c['text_muted']}; }}
QLabel#secondary {{ color: {c['text_secondary']}; }}
QLabel#brand {{ font-weight: 700; font-size: 17px; color: {c['text']}; }}

QPushButton {{
    background: {c['surface_alt']}; color: {c['text']};
    border: none; border-radius: {TKN.RADIUS['control']}px;
    padding: 8px 18px; font-size: 13px;
}}
QPushButton:hover {{ background: {c['control_hover']}; }}
QPushButton:pressed {{ background: {c['control_hover']}; }}
QPushButton:disabled {{ color: {c['text_muted']}; }}

QPushButton[btnClass="primary"] {{ background: {c['accent']}; color: {c['on_accent']}; font-weight: 600; }}
QPushButton[btnClass="primary"]:hover {{ background: {c['accent_hover']}; }}
QPushButton[btnClass="ghost"] {{ background: transparent; color: {c['text_secondary']}; }}
QPushButton[btnClass="ghost"]:hover {{ background: {c['surface_alt']}; color: {c['text']}; }}
QPushButton#sidebarToggle {{
    background: {c['surface_alt']}; color: {c['text_secondary']};
    border: 1px solid {c['border']}; border-radius: 7px; padding: 0;
    font-size: 16px; font-weight: 600;
}}
QPushButton#sidebarToggle:hover {{
    background: {c['accent_soft']}; color: {c['accent']};
    border-color: {c['accent']};
}}
QPushButton[btnClass="danger"] {{ background: transparent; color: {c['danger']}; }}
QPushButton[btnClass="danger"]:hover {{ background: {c['danger_bg']}; }}

QPushButton[audioButton="true"] {{
    background: #6B7280; color: #FFFFFF; border: none;
    border-radius: {TKN.RADIUS['control']}px; padding: 0;
}}
QPushButton[audioButton="true"]:hover {{ background: {c['accent']}; color: #FFFFFF; }}
QPushButton[audioButton="true"]:pressed {{ background: {c['accent_hover']}; color: #FFFFFF; }}

QPushButton[pill="true"] {{ background: transparent; color: {c['text_secondary']};
    border-radius: {TKN.RADIUS['chip']}px; padding: 7px 18px; font-size: 13px; }}
QPushButton[pill="true"]:hover {{ background: {c['surface_alt']}; }}
QPushButton[pill="true"]:checked {{ background: {c['accent_soft']}; color: {c['on_accent_soft']}; font-weight: 600; }}

QLineEdit, QComboBox, QPlainTextEdit, QTextEdit {{
    background: {glass_input}; color: {c['text']};
    border: 1px solid {c['border']}; border-radius: {TKN.RADIUS['chip']}px;
    padding: 5px 8px; selection-background-color: {c['accent']};
    selection-color: {c['on_accent']};
}}
QLineEdit:focus, QComboBox:focus {{
    border: 1px solid {c['accent']};
}}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox QAbstractItemView {{
    background: {c['surface']}; color: {c['text']};
    border: 1px solid {c['border']}; selection-background-color: {c['accent_soft']};
    selection-color: {c['on_accent_soft']};
}}

QListWidget {{ background: transparent; border: none; outline: 0; }}
QListWidget::item {{ padding: 7px 10px; border-radius: 8px; color: {c['text']}; }}
QListWidget::item:hover {{ background: {c['surface_alt']}; }}
QListWidget::item:selected {{ background: {c['accent_soft']}; color: {c['on_accent_soft']}; }}

QScrollArea {{ background: transparent; border: none; }}
QScrollBar:vertical {{ background: transparent; width: 8px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {c['border']}; border-radius: 4px; min-height: 24px; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
QScrollBar:horizontal {{ background: transparent; height: 8px; margin: 2px; }}
QScrollBar::handle:horizontal {{ background: {c['border']}; border-radius: 4px; min-width: 24px; }}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0; }}
QMenu {{ background: {c['surface']}; color: {c['text']}; border: 1px solid {c['border']}; }}
QMenu::item {{ padding: 6px 22px; border-radius: 6px; }}
QMenu::item:selected {{ background: {c['accent_soft']}; color: {c['on_accent_soft']}; }}
QCheckBox {{ color: {c['text_secondary']}; }}
QCheckBox::indicator {{ width: 16px; height: 16px; }}
QCheckBox::indicator:checked {{ background: {c['accent']}; border-radius: 4px; }}
QCheckBox::indicator:unchecked {{ background: transparent; border: 1px solid {c['border']}; border-radius: 4px; }}
QListWidget::indicator {{ width: 17px; height: 17px; }}
QListWidget::indicator:unchecked {{ background: transparent; border: 1px solid {c['border']}; border-radius: 4px; }}
QListWidget::indicator:checked {{ background: {c['accent']}; border: 1px solid {c['accent']}; border-radius: 4px; }}
"""
