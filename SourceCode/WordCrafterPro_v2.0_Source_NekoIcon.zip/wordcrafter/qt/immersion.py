# ==============================================================================
# 文件路径: wordcrafter/qt/immersion.py
# 真正的沉浸阅读（Reader Mode）：
#   - 独立顶层窗口，showFullScreen() 真全屏（非 resize 伪装）
#   - F11 全屏 ⇄ 窗口；Esc 退出；← 返回
#   - 自动复用 DocumentView（自动排版 + 字号控制 + 中英模式 + 背景主题）
#   - 背景：Light / Dark / Sepia / 跟随系统（默认不黑屏）
#   - 顶部悬浮工具条：鼠标移到顶部出现，闲置隐藏
# ==============================================================================
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QKeySequence, QShortcut
from PySide6.QtWidgets import (QButtonGroup, QFrame, QHBoxLayout, QLabel,
                               QVBoxLayout, QWidget)

from .renderer import DocumentView
from .theme import is_light_mode, qss
from .typography import DEFAULT_SIZE, get_saved_size, save_size, step_size
from .widgets import make_button, make_pill

THEME_ORDER = ["light", "dark", "sepia"]
THEME_NAMES = {"light": "浅色", "dark": "深色", "sepia": "护眼"}

MAX_WIDTH = 900


class ImmersionReader(QWidget):
    """独立沉浸阅读窗口。"""

    def __init__(self, cfg, title, en, zh):
        super().__init__()
        self.cfg = cfg
        self.title = title
        self.px = get_saved_size(cfg, "reading_font_size", DEFAULT_SIZE)
        self.mode = "dual"
        self.theme = self._initial_theme()
        self._mouse_active = False
        self._hide_job = None

        self.setObjectName("_immRoot")
        self._qss_base = qss(cfg)
        self._hide_timer = QTimer(self)
        self._hide_timer.setSingleShot(True)
        self._hide_timer.timeout.connect(self._hide_bar)

        self.setWindowTitle(f"沉浸阅读 · {title}")
        self.setMinimumSize(640, 480)
        self.resize(1000, 760)

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # 顶部悬浮工具条
        self.bar = QFrame()
        self.bar.setObjectName("bar")
        row = QHBoxLayout(self.bar)
        row.setContentsMargins(10, 6, 10, 6)
        row.setSpacing(6)

        btn_back = make_button("← 返回", "secondary", self._back)
        row.addWidget(btn_back)

        row.addStretch(1)

        # 字号
        btn_font_m = make_button("A−", "ghost", lambda: self._font(-1))
        row.addWidget(btn_font_m)
        self.lbl_font = QLabel(f"{self.px}px")
        self.lbl_font.setObjectName("muted")
        row.addWidget(self.lbl_font)
        btn_font_p = make_button("A+", "ghost", lambda: self._font(1))
        row.addWidget(btn_font_p)

        # 中英模式
        bg = QButtonGroup(self)
        self._pills = {}
        for key, label in (("dual", "中英对照"), ("en", "仅英文"), ("zh", "仅中文")):
            pill = make_pill(label, checked=(key == self.mode))
            pill.clicked.connect(lambda _=False, k=key: self._set_mode(k))
            bg.addButton(pill)
            self._pills[key] = pill
            row.addWidget(pill)

        # 背景
        self.btn_theme = make_button("背景：浅色", "ghost", self._cycle_theme)
        row.addWidget(self.btn_theme)

        btn_fs = make_button("⛶", "ghost", self._toggle_fullscreen)
        row.addWidget(btn_fs)
        btn_close = make_button("✕", "danger", self.close)
        row.addWidget(btn_close)

        root.addWidget(self.bar)
        root.addWidget(self._vspacer(), 1)

        # 正文（限宽居中）
        center = QHBoxLayout()
        center.setContentsMargins(16, 4, 16, 4)
        center.addStretch(1)
        self.doc = DocumentView(cfg)
        self.doc.set_content(en, zh)
        self.doc.setMaximumWidth(MAX_WIDTH)
        center.addWidget(self.doc)
        center.addStretch(1)
        root.addLayout(center, 1)
        root.addWidget(self._vspacer(), 1)

        self._apply_theme()
        self._apply_font_labels()

        # 快捷键
        QShortcut(QKeySequence("F11"), self, activated=self._toggle_fullscreen)
        QShortcut(QKeySequence("Escape"), self, activated=self._escape)
        QShortcut(QKeySequence("p"), self, activated=self._speak_selection)
        QShortcut(QKeySequence("P"), self, activated=self._speak_selection)

        self._schedule_hide()

    # ---------------- 布局辅助 ----------------
    @staticmethod
    def _vspacer():
        w = QWidget()
        w.setFixedHeight(10)
        return w

    def _initial_theme(self):
        try:
            return "light" if is_light_mode(self.cfg) else "dark"
        except Exception:
            return "light"

    # ---------------- 交互 ----------------
    def _back(self):
        if self.isFullScreen():
            self.showNormal()
        self.close()

    def _escape(self):
        if self.isFullScreen():
            self.showNormal()
            self._schedule_hide()
        else:
            self.close()

    def _toggle_fullscreen(self):
        if self.isFullScreen():
            self.showNormal()
        else:
            self.showFullScreen()
        self._schedule_hide()

    def _font(self, delta):
        self.px = step_size(self.cfg, "reading_font_size", self.px, delta)
        save_size(self.cfg, "reading_font_size", self.px)
        self.doc.apply_typography(px=self.px)
        self._apply_font_labels()

    def _set_mode(self, key):
        self.mode = key
        for k, p in self._pills.items():
            p.setChecked(k == key)
        self.doc.apply_typography(mode=key)

    def _cycle_theme(self):
        i = THEME_ORDER.index(self.theme)
        self.theme = THEME_ORDER[(i + 1) % len(THEME_ORDER)]
        self._apply_theme()

    def _apply_theme(self):
        self.doc.apply_typography(theme=self.theme)
        self.btn_theme.setText(f"背景：{THEME_NAMES.get(self.theme, self.theme)}")
        from .renderer import THEMES
        bg = THEMES.get(self.theme, THEMES["light"])["bg"]
        # 基础样式 + 阅读背景（非纯黑；护眼=暖米色）
        self.setStyleSheet(self._qss_base + f"\nQWidget#_immRoot {{ background: {bg}; }}")

    def _apply_font_labels(self):
        self.lbl_font.setText(f"{self.px}px")

    def _speak_selection(self):
        from ..services.pronunciation import PronunciationService
        cursor = self.doc.textCursor()
        text = cursor.selectedText().strip() if cursor.hasSelection() else ""
        if text:
            PronunciationService.play(text, self.cfg)

    # ---------------- 悬浮工具条 ----------------
    def mouseMoveEvent(self, event):
        super().mouseMoveEvent(event)
        if event.position().y() < 90:
            self.bar.setVisible(True)
            self._schedule_hide(2000)

    def _schedule_hide(self, ms=2500):
        self._hide_timer.stop()
        self._hide_timer.start(ms)

    def _hide_bar(self):
        if not self.isFullScreen():
            return
        self.bar.setVisible(False)
