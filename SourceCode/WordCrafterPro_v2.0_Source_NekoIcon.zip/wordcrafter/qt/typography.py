# ==============================================================================
# 文件路径: wordcrafter/qt/typography.py
# 统一阅读排版设置（TypographyController）：
#   - 字体等级：正文默认 18px，标题/副标题/注释分级
#   - A− / A / A+ 步进（持久化 per 页面键，如 reading_font_size）
#   - DPI 安全：使用 pixelSize（随系统缩放）
# ==============================================================================
from PySide6.QtGui import QFont, QTextCharFormat, QTextCursor
from PySide6.QtWidgets import QHBoxLayout, QLabel, QWidget

CONTENT_SIZES = [14, 16, 18, 20, 22, 24, 28, 32]
DEFAULT_SIZE = 18
SIZE_STEPS = [14, 16, 18, 20, 22, 24, 28, 32]

FONT_STACK = "Microsoft YaHei UI"

# 语义字号（相对正文比例的 px；正文由用户调整）
HEADING_PX = 26
SUBHEADING_PX = 20
NOTE_PX = 14


def get_saved_size(cfg, key, default=DEFAULT_SIZE):
    try:
        return int(cfg.config_repo.data.get(key, default))
    except Exception:
        return default


def save_size(cfg, key, size):
    try:
        cfg.config_repo.save_all({key: int(size)})
    except Exception:
        pass


def set_plain_font(edit, px):
    """给纯文本编辑控件设置字号（像素，DPI 安全）。"""
    f = QFont(FONT_STACK)
    f.setPixelSize(max(10, px))
    edit.setFont(f)
    return px


def step_size(cfg, key, current, delta):
    sizes = SIZE_STEPS
    idx = sizes.index(current) if current in sizes else sizes.index(DEFAULT_SIZE)
    n = max(0, min(len(sizes) - 1, idx + delta))
    return sizes[n]


def make_size_control(cfg, key, apply_cb, container=None):
    """构建 A− / 100% / A+ 行；apply_cb(px) 负责实时应用。返回 (widget, refresh_fn)。"""
    if container is None:
        container = QWidget()
    row = QHBoxLayout(container)
    row.setContentsMargins(0, 0, 0, 0)
    row.setSpacing(2)

    from .widgets import make_button

    def _apply(px):
        save_size(cfg, key, px)
        apply_cb(px)

    current = [get_saved_size(cfg, key)]
    lbl = QLabel(f"{current[0]}px")
    lbl.setObjectName("muted")

    def _step(delta):
        current[0] = step_size(cfg, key, current[0], delta)
        lbl.setText(f"{current[0]}px")
        _apply(current[0])

    btn_m = make_button("A−", "ghost", lambda: _step(-1))
    btn_a = make_button("A", "ghost", lambda: _apply(DEFAULT_SIZE))
    btn_p = make_button("A+", "ghost", lambda: _step(1))
    for b in (btn_m, btn_a, btn_p):
        b.setFixedSize(30, 26)
    row.addWidget(btn_m)
    row.addWidget(lbl)
    row.addWidget(btn_a)
    row.addWidget(btn_p)
    return container
