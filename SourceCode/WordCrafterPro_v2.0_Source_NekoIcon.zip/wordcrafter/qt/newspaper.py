# ==============================================================================
# 文件路径: wordcrafter/qt/newspaper.py
# 报纸式沉浸阅读（Responsive Newspaper Layout）：
#   - 宽屏自动 1/2/3 栏（默认 2，>1800 尝试 3，可手动覆盖）
#   - 标题/副标题跨栏置顶；正文按「段落块(英+中配对)」逐栏流动，不切断段落
#   - 20 世纪初美国报纸视觉：报头、日期线、衬线字体、首字下沉、栏间分隔线
#   - 字号 A−/A+ 调整后自动重新 Flow；背景 Light/Dark/Sepia；F11/Esc
#   - 真实全屏 showFullScreen；无透明/无黑屏风险
# ==============================================================================
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor, QKeySequence, QShortcut, QTextBlockFormat, QTextCharFormat, QTextCursor
from PySide6.QtWidgets import (QButtonGroup, QComboBox, QFrame, QHBoxLayout,
                               QLabel, QScrollArea, QVBoxLayout, QWidget)

from .renderer import THEMES, _split_paras
from .theme import is_light_mode, qss
from .typography import DEFAULT_SIZE, get_saved_size, save_size, step_size
from .widgets import make_button, make_pill

THEME_ORDER = ["light", "dark", "sepia"]
THEME_NAMES = {"light": "浅色", "dark": "深色", "sepia": "护眼"}
COLUMN_GAP = 40


def _auto_columns(width):
    if width < 1180:
        return 1
    if width <= 1850:
        return 2
    return 3


class NewspaperReader(QWidget):
    """全屏报纸阅读窗口（段落块为最小流动单位）。"""

    def __init__(self, cfg, title, en, zh):
        super().__init__()
        self.cfg = cfg
        self.en = en or ""
        self.zh = zh or ""
        self.px = get_saved_size(cfg, "reading_font_size", DEFAULT_SIZE)
        # 报纸默认采用复古纸张色；仍可从工具栏切换深色/浅色。
        self.theme = "sepia"
        self.columns_choice = "auto"   # auto | 1 | 2 | 3
        self._qss_base = qss(cfg)
        self.setObjectName("_newspaper")
        self.setWindowTitle(f"报纸阅读 · {title}")
        self.setMinimumSize(700, 500)
        self.resize(1600, 900)

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ---- 工具条 ----
        self.bar = QFrame()
        self.bar.setObjectName("bar")
        row = QHBoxLayout(self.bar)
        row.setContentsMargins(10, 6, 10, 6)
        row.setSpacing(6)
        btn_back = make_button("← 返回", "secondary", self._back)
        row.addWidget(btn_back)
        row.addStretch(1)

        def _font(delta):
            self.px = step_size(self.cfg, "reading_font_size", self.px, delta)
            save_size(self.cfg, "reading_font_size", self.px)
            self._rebuild()

        row.addWidget(make_button("A−", "ghost", lambda: _font(-1)))
        row.addWidget(make_button("A+", "ghost", lambda: _font(1)))

        row.addWidget(QLabel("栏数"))
        self.combo_cols = QComboBox()
        self.combo_cols.addItem("自动", "auto")
        self.combo_cols.addItem("单栏", "1")
        self.combo_cols.addItem("双栏", "2")
        self.combo_cols.addItem("三栏", "3")
        self.combo_cols.currentIndexChanged.connect(lambda *_: self._on_cols())
        row.addWidget(self.combo_cols)

        bg = QButtonGroup(self)
        self._pills = {}
        for key, label in (("dual", "中英对照"), ("en", "仅英文"), ("zh", "仅中文")):
            p = make_pill(label, checked=(key == "dual"))
            p.clicked.connect(lambda _=False, k=key: self._on_mode(k))
            bg.addButton(p)
            self._pills[key] = p
            row.addWidget(p)

        self.btn_theme = make_button("背景", "ghost", self._cycle_theme)
        row.addWidget(self.btn_theme)
        self.btn_fullscreen = make_button("⛶", "ghost", self._toggle_fullscreen)
        self.btn_fullscreen.setToolTip("全屏阅读（全屏时隐藏工具栏）")
        row.addWidget(self.btn_fullscreen)
        row.addWidget(make_button("✕", "danger", self.close))
        root.addWidget(self.bar)

        # ---- 内容区（标题 + 多栏滚动） ----
        content = QWidget()
        cl = QVBoxLayout(content)
        cl.setContentsMargins(24, 6, 24, 10)
        cl.setSpacing(4)
        masthead = QFrame()
        masthead.setObjectName("newspaperMasthead")
        mh = QVBoxLayout(masthead)
        mh.setContentsMargins(0, 6, 0, 8)
        mh.setSpacing(2)
        eyebrow = QLabel("THE WORDCRAFTER DAILY")
        eyebrow.setObjectName("newspaperEyebrow")
        eyebrow.setAlignment(Qt.AlignCenter)
        mh.addWidget(eyebrow)
        date_line = QLabel("SPECIAL EDITION  ·  ENGLISH READING  ·  VOL. 02")
        date_line.setObjectName("newspaperDate")
        date_line.setAlignment(Qt.AlignCenter)
        mh.addWidget(date_line)
        cl.addWidget(masthead)

        self.lbl_title = QLabel(title)
        self.lbl_title.setWordWrap(True)
        self.lbl_title.setObjectName("newspaperTitle")
        self.lbl_title.setAlignment(Qt.AlignCenter)
        cl.addWidget(self.lbl_title)
        rule = QFrame()
        rule.setObjectName("newspaperRule")
        rule.setFrameShape(QFrame.HLine)
        rule.setFixedHeight(2)
        cl.addWidget(rule)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self._scroll_content = QWidget()
        self._cols_row = QHBoxLayout(self._scroll_content)
        self._cols_row.setContentsMargins(8, 6, 8, 16)
        self._cols_row.setSpacing(COLUMN_GAP)
        self.scroll.setWidget(self._scroll_content)
        cl.addWidget(self.scroll, 1)
        root.addWidget(content, 1)

        self._mode = "dual"
        self._column_edits = []
        self._rebuild()

        QShortcut(QKeySequence("F11"), self, activated=self._toggle_fullscreen)
        QShortcut(QKeySequence("Escape"), self, activated=self._escape)
        QTimer.singleShot(0, self._apply_theme)

    # ---------------- 布局计算 ----------------
    def _n_columns(self):
        width = self.width() - 48 - 16
        if self.columns_choice != "auto":
            return int(self.columns_choice)
        return _auto_columns(width)

    def _units(self):
        """段落级单元：每单元 (en_text, zh_text)；标题类单独返回。"""
        en_paras = _split_paras(self.en)
        zh_paras = _split_paras(self.zh)
        units = []
        for i in range(max(len(en_paras), len(zh_paras))):
            en = en_paras[i] if i < len(en_paras) else ""
            zh = zh_paras[i] if i < len(zh_paras) else ""
            if en or zh:
                units.append((en, zh))
        return units

    def _assign_columns(self, units, n):
        """按字符量均分到 n 栏（每单元整体放入某栏，不切断）。"""
        if n <= 1:
            return [units]
        total = sum(len(u[0]) + len(u[1]) + 2 for u in units)
        per = max(1, total / n)
        cols = [[] for _ in range(n)]
        acc = [0.0] * n
        # 顺序流动但尽量均衡：贪心放最“空”的一栏
        for u in units:
            weight = len(u[0]) + len(u[1]) + 2
            idx = acc.index(min(acc))
            cols[idx].append(u)
            acc[idx] += weight
        return cols

    def _rebuild(self):
        while self._cols_row.count():
            item = self._cols_row.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()
        self._column_edits = []
        n = self._n_columns()
        cols = self._assign_columns(self._units(), n)
        for i, col_units in enumerate(cols):
            edit = self._make_column()
            self._fill_column(edit, col_units)
            self._cols_row.addWidget(edit, 1)
            self._column_edits.append(edit)
            if i < len(cols) - 1:
                divider = QFrame()
                divider.setObjectName("newspaperColumnRule")
                divider.setFrameShape(QFrame.VLine)
                divider.setFixedWidth(1)
                self._cols_row.addWidget(divider)
        self._apply_theme()

    def _make_column(self):
        from PySide6.QtWidgets import QTextEdit
        edit = QTextEdit()
        edit.setReadOnly(True)
        edit.setLineWrapMode(QTextEdit.WidgetWidth)
        edit.setFrameShape(QFrame.NoFrame)
        edit.setFontFamily("Georgia")
        return edit

    def _fill_column(self, edit, units):
        if not units:
            return
        t = THEMES.get(self.theme, THEMES["light"])
        idx = 0 if is_light_mode(self.cfg) else 1
        try:
            accent = QColor(self.cfg.c_primary[idx])
        except Exception:
            accent = QColor("#4F46E5")
        fg = QColor(t["fg"])
        sub = QColor(t["sub"])
        base_pt = max(8, int(round(self.px * 0.75)))
        cursor = QTextCursor(edit.document())
        first = True
        for en, zh in units:
            fmt_en = QTextCharFormat()
            fmt_en.setFontPointSize(base_pt)
            fmt_en.setFontFamily("Georgia")
            fmt_en.setForeground(fg)
            if en:
                if not first:
                    cursor.insertBlock()
                # 首段首字下沉，形成早期报纸常见的导语视觉。
                if first and len(en) > 1 and en[0].isalpha():
                    drop = QTextCharFormat(fmt_en)
                    drop.setFontPointSize(max(base_pt + 6, int(base_pt * 2.1)))
                    drop.setFontWeight(700)
                    drop.setForeground(accent)
                    cursor.insertText(en[0], drop)
                    cursor.insertText(en[1:], fmt_en)
                else:
                    cursor.insertText(en, fmt_en)
                first = False
            if zh and self._mode in ("dual", "zh"):
                fmt_zh = QTextCharFormat()
                fmt_zh.setFontPointSize(int(base_pt * 0.92))
                fmt_zh.setFontFamily("Microsoft YaHei UI")
                fmt_zh.setForeground(sub if self._mode == "dual" else fg)
                if not first:
                    cursor.insertBlock()
                cursor.insertText(zh, fmt_zh)
                first = False
        edit.document().setDocumentMargin(6)

    # ---------------- 主题 / 模式 / 栏数 ----------------
    def _apply_theme(self):
        t = THEMES.get(self.theme, THEMES["light"])
        for edit in self._column_edits:
            edit.setStyleSheet(f"QTextEdit {{ background: {t['bg']}; border: none; }}")
        self.btn_theme.setText(f"背景：{THEME_NAMES.get(self.theme, self.theme)}")
        self.lbl_title.setStyleSheet(
            f"font-family: Georgia, 'Times New Roman'; font-size: 34px;"
            f" font-weight: 700; color: {t['fg']};")
        self.setStyleSheet(self._qss_base + f"""
            QWidget#_newspaper {{ background: {t['bg']}; }}
            QLabel#newspaperEyebrow {{
                color: {t['fg']}; font-family: Georgia, 'Times New Roman';
                font-size: 13px; font-weight: 700; letter-spacing: 3px;
            }}
            QLabel#newspaperDate {{
                color: {t['sub']}; font-family: Georgia, 'Times New Roman';
                font-size: 10px; letter-spacing: 1px;
            }}
            QFrame#newspaperMasthead {{
                border-top: 3px solid {t['fg']};
                border-bottom: 1px solid {t['fg']};
            }}
            QFrame#newspaperRule, QFrame#newspaperColumnRule {{
                background: {t['fg']}; color: {t['fg']};
            }}
        """)

    def _cycle_theme(self):
        i = THEME_ORDER.index(self.theme)
        self.theme = THEME_ORDER[(i + 1) % len(THEME_ORDER)]
        self._rebuild()

    def _on_mode(self, key):
        self._mode = key
        for k, p in self._pills.items():
            p.setChecked(k == key)
        self._rebuild()

    def _on_cols(self):
        self.columns_choice = self.combo_cols.currentData()
        self._rebuild()

    # ---------------- 窗口控制 ----------------
    def _back(self):
        if self.isFullScreen():
            self.showNormal()
        self.close()

    def _escape(self):
        if self.isFullScreen():
            self.showNormal()
            self.bar.show()
        else:
            self.close()

    def _toggle_fullscreen(self):
        if self.isFullScreen():
            self.showNormal()
            self.bar.show()
        else:
            self.showFullScreen()
            # 工具栏只在用户主动进入全屏时隐藏，不再按计时器自动消失。
            self.bar.hide()
        QTimer.singleShot(60, self._rebuild)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._rebuild()

    def mouseMoveEvent(self, event):
        super().mouseMoveEvent(event)
        if self.isFullScreen() and event.position().y() < 90:
            self.bar.setVisible(True)
