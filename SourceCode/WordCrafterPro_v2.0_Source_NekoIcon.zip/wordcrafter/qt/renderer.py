# ==============================================================================
# 文件路径: wordcrafter/qt/renderer.py
# ContentRenderer —— 统一内容渲染/自动排版：
#   解析 AI 输出 → 识别标题/段落/列表/引用/释义标签 → 生成排版 HTML
#   - 不修改原文（仅 Presentation 层）
#   - 支持 仅英文 / 中英对照(段落级交替) / 仅中文
#   - 字号(px) / 行高 1.7 / 段距 / 中英弱化 由 CSS 控制，DPI 安全
# ==============================================================================
import html
import re

from PySide6.QtWidgets import QTextEdit

from .theme import is_light_mode

FONT_FAMILY = "Microsoft YaHei UI"

# 阅读背景方案（禁止默认纯黑）
THEMES = {
    "light":  {"bg": "#FAFAF9", "fg": "#2B2B2B", "sub": "#6B6B6B"},
    "dark":   {"bg": "#1F1F22", "fg": "#E8E8EA", "sub": "#9A9AA2"},
    "sepia":  {"bg": "#F5ECDd", "fg": "#4A3F30", "sub": "#7A6F5C"},
}


def _split_paras(text):
    lines = [ln.strip() for ln in (text or "").replace("\r\n", "\n").split("\n")]
    paras = []
    buf = []
    for ln in lines:
        if not ln:
            if buf:
                paras.append("\n".join(buf))
                buf = []
            continue
        buf.append(ln)
    if buf:
        paras.append("\n".join(buf))
    return paras


def _en_groups(en):
    """英文拆成段落组；每组为 [(kind, text), ...]，标题/列表/引用各自独立。"""
    groups = []
    for para in _split_paras(en):
        lines = para.split("\n")
        kinds = [_block_kind(ln) for ln in lines]
        group = []
        if kinds and kinds[0] in ("h", "h2"):
            heading = lines[0]
            head_text = heading.lstrip("#").rstrip(":").strip()
            group.append(("title" if kinds[0] == "h" else "sub", head_text))
            rest = "\n".join(lines[1:]).strip()
            if rest:
                group.append(("en", rest))
        elif all(k == "li" for k in kinds):
            for ln in lines:
                group.append(("li", re.sub(r"^(\-|\*|•|\d+[\.\)])\s*", "", ln)))
        elif kinds and kinds[0] == "quote":
            body = "\n".join(ln.lstrip("> ").strip() for ln in lines)
            group.append(("quote", body))
        else:
            group.append(("en", para))
        groups.append(group)
    return groups


def visual_blocks(en, zh, mode):
    """按模式生成可视化块序列 [(kind, text)]，供富文本构建使用。
    kind: title/sub/en/zh(辅助)/zh_main(仅中文主文本)/li/quote"""
    en_groups = _en_groups(en) if en else []
    zh_paras = _split_paras(zh) if zh else []
    blocks = []
    if mode == "zh":
        for p in zh_paras:
            blocks.append(("zh_main", p))
        return blocks
    if mode == "en":
        for g in en_groups:
            blocks.extend(g)
        return blocks
    # dual：英文段落组与中文段落按顺序配对流动
    for i in range(max(len(en_groups), len(zh_paras))):
        if i < len(en_groups):
            blocks.extend(en_groups[i])
        if i < len(zh_paras):
            blocks.append(("zh", zh_paras[i]))
    return blocks


def _looks_title(line):
    """标题候选：短行、无句末标点、英文词多为首字母大写（Title Case）。"""
    s = line.strip()
    if not s or len(s) > 44:
        return False
    if re.search(r"[.!?;。！？；，,:]$", s):
        return False
    words = re.findall(r"[A-Za-z\u4e00-\u9fff]+", s)
    if not words:
        return False
    # 单个大写单词（如 "Title"）且无句末标点 → 视为标题
    if len(words) == 1:
        w = words[0]
        return bool(w and w[0].isupper() and len(s) <= 30 and not s.endswith("."))
    alpha = [w for w in words if w and w[0].isalpha()]
    if not alpha:
        return False
    capped = sum(1 for w in alpha if w[0].isupper())
    return capped / len(alpha) >= 0.75


def _block_kind(line):
    s = line.strip()
    if not s:
        return None
    if s.startswith("#"):
        return "h"
    if s.startswith("> "):
        return "quote"
    if re.match(r"^(\-|\*|•)\s+", s) or re.match(r"^\d+[\.\)]\s+", s):
        return "li"
    if len(s) < 46 and s.endswith(":") and not s.endswith("::"):
        return "h2"
    if s.isupper() and 3 <= len(s) <= 32:
        return "h2"
    if _looks_title(s):
        return "h2"
    return "p"


def _render_paras(paras, css_px, t):
    out = []
    for p in paras:
        lines = p.split("\n")
        kinds = [_block_kind(ln) for ln in lines]
        esc = lambda s: html.escape(s)
        if kinds and kinds[0] == "h":
            out.append(f"<h2>{esc(lines[0].lstrip('#').strip())}</h2>")
            rest = "\n".join(lines[1:]).strip()
            if rest:
                out.append(f"<p>{esc(rest)}</p>")
            continue
        if kinds and kinds[0] == "h2":
            out.append(f"<h3>{esc(lines[0].rstrip(':').strip())}</h3>")
            rest = "\n".join(lines[1:]).strip()
            if rest:
                out.append(f"<p>{esc(rest)}</p>")
            continue
        if all(k == "li" for k in kinds):
            items = []
            for ln in lines:
                items.append("• " + esc(re.sub(r"^(\-|\*|•|\d+[\.\)])\s*", "", ln)))
            out.append(f"<p class='li'>" + "<br>".join(items) + "</p>")
            continue
        if kinds and kinds[0] == "quote":
            body = "<br>".join(esc(ln.lstrip("> ").strip()) for ln in lines)
            out.append(f"<blockquote>{body}</blockquote>")
            continue
        out.append(f"<p>{esc(p)}</p>")
    return "\n".join(out)


def render_html(en, zh=None, px=18, mode="dual", theme_key="light",
                accent_soft=None, accent=None):
    """把 英文/中文 渲染为排版 HTML。mode: en | dual | zh"""
    t = THEMES.get(theme_key, THEMES["light"])
    base = max(12, int(px))
    h2px = int(base * 1.5)
    h3px = int(base * 1.25)
    sub = t["sub"]
    accent_color = accent or "#4F46E5"

    en_paras = _split_paras(en) if en else []
    zh_paras = _split_paras(zh) if zh else []

    body_parts = []
    if mode in ("en", "dual"):
        if mode == "dual" and zh_paras:
            # 段落级中英对照：逐段交替；段落数不一致时兜底整段拼接
            n = max(len(en_paras), len(zh_paras))
            for i in range(n):
                if i < len(en_paras):
                    body_parts.append(_render_paras([en_paras[i]], base, t))
                if i < len(zh_paras):
                    body_parts.append(
                        f"<p class='zh'>{html.escape(zh_paras[i])}</p>")
        else:
            body_parts.append(_render_paras(en_paras, base, t))
    else:  # zh
        body_parts.append(_render_paras(zh_paras, base, t))

    body = "\n".join(body_parts) or "<p></p>"
    css = (
        f"<style>"
        f"body{{ font-family:'{FONT_FAMILY}'; background:{t['bg']}; color:{t['fg']};"
        f" line-height:1.7; margin:24px 8px;}}"
        f"h2{{ font-size:{h2px}px; color:{accent_color}; margin:1.2em 0 .5em; line-height:1.4;}}"
        f"h3{{ font-size:{h3px}px; color:{t['fg']}; margin:1.1em 0 .4em;}}"
        f"p{{ font-size:{base}px; margin:.55em 0;}}"
        f"p.zh{{ font-size:{int(base*0.92)}px; color:{sub};}}"
        f"blockquote{{ border-left:3px solid {accent_color}; padding:.2em 1em;"
        f" color:{sub}; margin:.8em 0;}}"
        f"</style>"
    )
    return f"<!DOCTYPE html><html><head><meta charset='utf-8'>{css}</head><body>{body}</body></html>"


class DocumentView(QTextEdit):
    """自动排版阅读视图：结构化富文本（真实字号/层级/行距），保存参数随时重排版。"""

    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self._en = ""
        self._zh = ""
        self.px = 18
        self.mode = "dual"
        self.theme = "light"
        self.setReadOnly(True)
        self.setLineWrapMode(QTextEdit.WidgetWidth)

    def set_content(self, en, zh):
        self._en = en or ""
        self._zh = zh or ""
        self.rerender()

    def apply_typography(self, px=None, mode=None, theme=None):
        if px is not None:
            self.px = max(12, int(px))
        if mode is not None:
            self.mode = mode
        if theme is not None:
            self.theme = theme
        self.rerender()

    def rerender(self):
        from PySide6.QtGui import QColor, QTextBlockFormat, QTextCharFormat, QTextCursor
        _prop = QTextBlockFormat.ProportionalHeight
        _LH = int(getattr(_prop, "value", 1))
        from PySide6.QtWidgets import QTextEdit
        t = THEMES.get(self.theme, THEMES["light"])
        idx = 0 if is_light_mode(self.cfg) else 1
        try:
            accent = QColor(getattr(self.cfg, "c_primary", ("#4F46E5", "#818CF8"))[idx])
        except Exception:
            accent = QColor("#4F46E5")
        fg = QColor(t["fg"])
        sub = QColor(t["sub"])
        base = max(12, int(self.px))
        base_pt = max(8, int(round(base * 0.75)))  # px → pt（96dpi 折算，DPI 自适应）

        self.clear()
        cursor = QTextCursor(self.document())
        first = True
        for kind, text in visual_blocks(self._en, self._zh, self.mode):
            fmt = QTextCharFormat()
            bf = QTextBlockFormat()
            bf.setLineHeight(170, _LH)
            if kind == "title":
                fmt.setFontPointSize(int(base_pt * 1.5))
                fmt.setFontWeight(700)
                fmt.setForeground(accent)
                bf.setTopMargin(base_pt * 2.2)
                bf.setBottomMargin(base_pt * 0.8)
            elif kind == "sub":
                fmt.setFontPointSize(int(base_pt * 1.2))
                fmt.setFontWeight(600)
                fmt.setForeground(fg)
                bf.setTopMargin(base_pt * 1.8)
                bf.setBottomMargin(base_pt * 0.5)
            elif kind in ("zh", "zh_main"):
                fmt.setFontPointSize(int(base_pt * 0.94))
                fmt.setForeground(fg if kind == "zh_main" else sub)
            elif kind == "quote":
                fmt.setFontPointSize(base_pt)
                fmt.setForeground(sub)
                bf.setLeftMargin(base_pt * 1.4)
                bf.setTopMargin(base_pt * 0.7)
                bf.setBottomMargin(base_pt * 0.7)
            elif kind == "li":
                fmt.setFontPointSize(base_pt)
                fmt.setForeground(fg)
                bf.setLeftMargin(base_pt * 0.8)
                text = "• " + text
            else:
                fmt.setFontPointSize(base_pt)
                fmt.setForeground(fg)
            if not first:
                cursor.insertBlock(bf, fmt)
            cursor.insertText(text, fmt)
            first = False
        # 背景随主题（非纯黑默认）
        self.setStyleSheet(f"QTextEdit {{ background: {t['bg']}; border: none; }}")
        self.document().setDocumentMargin(18)
        self.verticalScrollBar().setValue(0)
