# ==============================================================================
# 文件路径: wordcrafter/qt/pages/vocab_page.py
# 单词模式（Qt）—— 情境短文：底部输入条(多行生词) + 参数行 + 流式正文
# 保留能力：抽词模式/篇幅/拓展词 · TXT 导入 · 自动收入生词库 · 划词查词
#           parse_input_words()（供 ACG 页"从第一页抽词"）
# ==============================================================================
import random
import threading

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtWidgets import (QButtonGroup, QCheckBox, QComboBox, QFileDialog,
                               QFrame, QHBoxLayout, QLabel, QLineEdit,
                               QPlainTextEdit, QStackedLayout, QVBoxLayout,
                               QWidget)

from ...core.text_utils import parse_words, read_text_any_encoding
from ...services.ai import AIService, StreamRouter
from ..newspaper import NewspaperReader
from ..typography import (DEFAULT_SIZE, get_saved_size, save_size, set_plain_font,
                          step_size)
from ..widgets import (ChunkSink, EmptyState, append_text, attach_text_menu,
                       cfg_hex, make_button, make_pill)

FONT_KEY = "content_font_size"

_WORD_MODES = ["全部使用", "随机抽取 3 个", "随机抽取 5 个", "随机抽取 8 个", "自定义抽词量"]
_LENGTHS = ["短篇 (~200词)", "中篇 (~400词)", "长篇 (~600词)", "千字长篇 (~1000词)", "自定义字数"]
_CUSTOM = "自定义字数"
_DOTS = ["●○○", "○●○", "○○●"]


class VocabPage(QWidget):
    """Qt 情境短文工作页。"""

    finished_ok = Signal(object)
    failed = Signal(str)

    def __init__(self, app):
        super().__init__()
        self.app = app
        self.cfg = app.config
        self.generating = False
        self._dots = 0
        self.word_input = None  # 底部输入条构建后创建
        self.px = get_saved_size(self.cfg, FONT_KEY, DEFAULT_SIZE)

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        self.stack = QStackedLayout()
        root.addLayout(self.stack, 1)

        self.empty = EmptyState(self.cfg, "✍️", "开始一篇情境短文",
                                "在下方输入目标生词，选择抽词与篇幅后生成中英对照短文")
        self.stack.addWidget(self.empty)
        self._build_reader()
        self.stack.addWidget(self.reader)
        self.set_state("empty")

        self.finished_ok.connect(self._on_success)
        self.failed.connect(self._on_error)

    # ---------------- 正文卡 ----------------
    def _build_reader(self):
        cfg = self.cfg
        self.reader = QFrame()
        self.reader.setObjectName("surface")
        lay = QVBoxLayout(self.reader)
        lay.setContentsMargins(16, 12, 16, 12)
        lay.setSpacing(6)

        head = QHBoxLayout()
        self.lbl_title = QLabel("情境短文")
        self.lbl_title.setStyleSheet("font-size: 16px; font-weight: 600;")
        head.addWidget(self.lbl_title)
        self.lbl_state = QLabel("")
        self.lbl_state.setObjectName("muted")
        head.addWidget(self.lbl_state)
        head.addStretch(1)
        bg = QButtonGroup(self)
        self._pills = {}
        for i, (key, text) in enumerate([("dual", "📖 双语对照"), ("en", "🔤 纯英文"),
                                         ("zh", "🇨🇳 仅看中文")]):
            pill = make_pill(text, checked=(key == "dual"))
            pill.clicked.connect(lambda _=False, k=key: self.set_view(k))
            bg.addButton(pill, i)
            self._pills[key] = pill
            head.addWidget(pill)
        lay.addLayout(head)

        body = QWidget()
        bl = QVBoxLayout(body)
        bl.setContentsMargins(0, 0, 0, 0)
        bl.setSpacing(6)
        self.txt_en = QPlainTextEdit()
        self.txt_zh = QPlainTextEdit()
        for e in (self.txt_en, self.txt_zh):
            e.setReadOnly(True)
            e.setLineWrapMode(QPlainTextEdit.WidgetWidth)
            attach_text_menu(e, cfg, self.app)
        set_plain_font(self.txt_en, self.px)
        set_plain_font(self.txt_zh, self.px)
        bl.addWidget(self.txt_en, 1)
        bl.addWidget(self.txt_zh, 1)
        lay.addWidget(body, 1)

        tools = QHBoxLayout()
        tools.setSpacing(4)

        def _apply_font(delta):
            self.px = step_size(cfg, FONT_KEY, self.px, delta)
            save_size(cfg, FONT_KEY, self.px)
            set_plain_font(self.txt_en, self.px)
            set_plain_font(self.txt_zh, self.px)

        btn_fm = make_button("A−", "ghost", lambda: _apply_font(-1))
        tools.addWidget(btn_fm)
        btn_fp = make_button("A+", "ghost", lambda: _apply_font(1))
        tools.addWidget(btn_fp)
        btn_full = make_button("📖 沉浸阅读", "primary", self.open_immersion)
        tools.addWidget(btn_full)
        btn_export = make_button("📤 导出短文", "ghost", self.export_article)
        tools.addWidget(btn_export)
        tools.addStretch(1)
        lay.addLayout(tools)

    # ---------------- 状态/视图 ----------------
    def set_state(self, state):
        if state == "generating":
            self.stack.setCurrentWidget(self.reader)
            self.generating = True
            self._dots = 0
            self.lbl_state.setText("生成中 " + _DOTS[0])
            self._spin()
        elif state == "content":
            self.generating = False
            self.lbl_state.setText("")
            self.stack.setCurrentWidget(self.reader)
        else:
            self.generating = False
            self.lbl_state.setText("")
            self.stack.setCurrentWidget(self.empty)

    def _spin(self):
        if not self.generating:
            return
        self.lbl_state.setText("生成中 " + _DOTS[self._dots % 3])
        self._dots += 1
        QTimer.singleShot(160, self._spin)

    def set_view(self, key):
        self.txt_en.setVisible(key in ("dual", "en"))
        self.txt_zh.setVisible(key in ("dual", "zh"))
        for k, p in self._pills.items():
            p.setChecked(k == key)

    # ---------------- 词输入能力（供 ACG 引用） ----------------
    def parse_input_words(self):
        if self.word_input is None:
            return []
        return parse_words(self.word_input.toPlainText())

    def import_txt_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "导入 TXT", "", "Text Files (*.txt)")
        if not path:
            return
        content, ok = read_text_any_encoding(path)
        if not ok:
            self._status("编码不支持", "error")
            return
        if self.word_input is not None:
            self.word_input.setPlainText(", ".join(parse_words(content)))

    # ---------------- 全屏/导出 ----------------
    def open_fullscreen(self):
        self.open_immersion()

    def open_immersion(self):
        en = self.txt_en.toPlainText().strip()
        zh = self.txt_zh.toPlainText().strip()
        if not en and not zh:
            self.app.toasts.show("当前无内容", kind="info")
            return
        reader = NewspaperReader(self.cfg, "情境短文", en, zh)
        reader.show()

    def export_article(self):
        en = self.txt_en.toPlainText().strip()
        zh = self.txt_zh.toPlainText().strip()
        if not en and not zh:
            self.app.toasts.show("当前无内容", kind="info")
            return
        path, _ = QFileDialog.getSaveFileName(self, "导出短文", "story.txt",
                                              "Text Files (*.txt)")
        if not path:
            return
        with open(path, "w", encoding="utf-8") as f:
            f.write(f"=== English Context Story ===\n\n{en}\n\n"
                    f"=== Chinese Translation ===\n\n{zh}\n")
        self.app.toasts.show("短文已导出", kind="success")

    # ---------------- 底部 ContextActionBar ----------------
    def build_context_bar(self, container):
        cfg = self.cfg
        bar = QFrame(container)
        bar.setObjectName("bar")
        v = QVBoxLayout(bar)
        v.setContentsMargins(14, 8, 14, 8)
        v.setSpacing(6)

        # 行1：词输入 + 生成
        r1 = QHBoxLayout()
        r1.setSpacing(8)
        self.word_input = QPlainTextEdit()
        self.word_input.setPlaceholderText("目标生词，逗号/空格分隔，例如：serendipity, persist, hesitate")
        self.word_input.setFixedHeight(56)
        self.word_input.setLineWrapMode(QPlainTextEdit.WidgetWidth)
        r1.addWidget(self.word_input, 1)
        act = QVBoxLayout()
        act.setSpacing(4)
        self.btn_generate = make_button("🚀 生成短文", "primary", self.start_generation)
        act.addWidget(self.btn_generate)
        btn_import = make_button("导入 TXT", "ghost", self.import_txt_file)
        act.addWidget(btn_import)
        act_w = QWidget()
        act_w.setLayout(act)
        r1.addWidget(act_w)
        v.addLayout(r1)

        # 行2：参数
        r2 = QHBoxLayout()
        r2.setSpacing(6)
        r2.addWidget(QLabel("抽词"))
        self.combo_mode = QComboBox()
        self.combo_mode.addItems(_WORD_MODES)
        self.combo_mode.currentTextChanged.connect(self._on_mode_change)
        r2.addWidget(self.combo_mode)
        self.edit_count = QLineEdit("5")
        self.edit_count.setFixedWidth(44)
        r2.addWidget(self.edit_count)

        r2.addWidget(QLabel("篇幅"))
        self.combo_len = QComboBox()
        self.combo_len.addItems(_LENGTHS)
        self.combo_len.currentTextChanged.connect(self._on_len_change)
        r2.addWidget(self.combo_len)
        self.edit_custom_len = QLineEdit("1000")
        self.edit_custom_len.setFixedWidth(56)
        self.edit_custom_len.hide()
        r2.addWidget(self.edit_custom_len)

        self.chk_extra = QCheckBox("拓展生词")
        r2.addWidget(self.chk_extra)
        self.edit_extra = QLineEdit("3")
        self.edit_extra.setFixedWidth(40)
        r2.addWidget(self.edit_extra)

        r2.addStretch(1)
        self.lbl_status = QLabel("")
        self.lbl_status.setObjectName("muted")
        r2.addWidget(self.lbl_status)
        v.addLayout(r2)

        cbox = container.layout()
        if cbox is None:
            cbox = QVBoxLayout(container)
            cbox.setContentsMargins(0, 0, 0, 0)
        cbox.addWidget(bar)

    def _on_mode_change(self, text):
        self.edit_count.setVisible("自定义" in text)

    def _on_len_change(self, text):
        self.edit_custom_len.setVisible(_CUSTOM in text)

    # ---------------- 生成 ----------------
    def start_generation(self):
        if self.generating:
            return
        all_words = self.parse_input_words()
        if not all_words:
            self._status("请输入至少一个目标单词", "error")
            return
        mode = self.combo_mode.currentText()
        if "3 个" in mode:
            chosen = random.sample(all_words, min(3, len(all_words)))
        elif "5 个" in mode:
            chosen = random.sample(all_words, min(5, len(all_words)))
        elif "8 个" in mode:
            chosen = random.sample(all_words, min(8, len(all_words)))
        elif "自定义" in mode:
            try:
                n = max(1, min(int(self.edit_count.text().strip()), len(all_words)))
                chosen = random.sample(all_words, n)
            except Exception:
                chosen = all_words
        else:
            chosen = all_words

        len_mode = self.combo_len.currentText()
        target_len = (f"{self.edit_custom_len.text().strip()} 词左右"
                      if _CUSTOM in len_mode else len_mode)
        extra_cnt = 0
        if self.chk_extra.isChecked():
            try:
                extra_cnt = max(0, int(self.edit_extra.text().strip()))
            except Exception:
                extra_cnt = 3

        # 收入生词库（保留行为）
        try:
            self.cfg.vocab_repo.add_words(chosen)
            if hasattr(self.app, "update_global_vocab_status"):
                self.app.update_global_vocab_status()
        except Exception:
            pass

        self.txt_en.clear()
        self.txt_zh.clear()
        self.btn_generate.setEnabled(False)
        self.set_state("generating")
        self._status("正在构思生成…", None)

        sink_en = ChunkSink(self)
        sink_zh = ChunkSink(self)
        sink_en.chunk.connect(lambda t: append_text(self.txt_en, t))
        sink_zh.chunk.connect(lambda t: append_text(self.txt_zh, t))
        threading.Thread(target=self._worker,
                         args=(chosen, extra_cnt, target_len, sink_en, sink_zh),
                         daemon=True).start()

    def _worker(self, words, extra_cnt, target_len, sink_en, sink_zh):
        cfg = self.cfg
        router = StreamRouter(sink_en, sink_zh)
        try:
            AIService.generate_vocab_story_stream(
                words, extra_cnt, target_len,
                cfg.difficulty, cfg.api_key, cfg.api_url, cfg.model_name, router.feed)
            router.close()
            self.finished_ok.emit({"words": words, "length": target_len})
        except Exception as exc:
            self.failed.emit(str(exc))

    def _on_success(self, meta):
        self.generating = False
        self.btn_generate.setEnabled(True)
        self._status("✓ 生成完成 · 右键划词可查词/朗读/收入生词库", "success")
        self.set_state("content")
        try:
            title = " · ".join(meta["words"][:5]) + ("…" if len(meta["words"]) > 5 else "")
            en = self.txt_en.toPlainText().strip()
            zh = self.txt_zh.toPlainText().strip()
            self.app.add_session("vocab", title[:40],
                                 summary=(en or "")[:120].replace("\n", " "),
                                 meta={"words": meta["words"][:8],
                                       "length": meta["length"]},
                                 content={"en": en, "zh": zh})
        except Exception:
            pass

    def restore_session(self, session):
        """从历史恢复：还原单词短文内容与输入词。"""
        content = session.get("content") or {}
        en = (content.get("en") or "").strip()
        zh = (content.get("zh") or "").strip()
        if not en and not zh:
            return False
        self.txt_en.setPlainText(en)
        self.txt_zh.setPlainText(zh)
        params = session.get("parameters") or {}
        words = params.get("words")
        if words and self.word_input is not None:
            self.word_input.setPlainText(", ".join(words))
        self.set_state("content")
        return True

    def _on_error(self, err):
        self.generating = False
        self.btn_generate.setEnabled(True)
        self._status(f"✕ 生成失败：{err}", "error")
        self.set_state("content")
        self.app.toasts.show(f"生成失败：{err}", kind="error")

    def _status(self, text, tone):
        color = {"success": cfg_hex(self.cfg, "success"),
                 "error": cfg_hex(self.cfg, "error")}.get(tone)
        if not hasattr(self, "lbl_status"):
            return
        self.lbl_status.setText(text)
        self.lbl_status.setStyleSheet(f"color: {color};" if color else "")
