# ==============================================================================
# 词典页：我的词典（本地导入） · 在线词典（GitHub 下载） · 已下载词典管理
# ==============================================================================
import os
import threading

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QFileDialog, QHBoxLayout, QLabel, QListWidget,
                               QListWidgetItem, QMessageBox, QScrollArea,
                               QVBoxLayout, QWidget)

from ..widgets import cfg_hex, make_button, style_scroll


class DictionaryPage(QWidget):
    """管理本地词典，并按需下载 KyleBing 的公开词典。"""

    _online_list_ready = Signal(object)
    _download_done = Signal(object)

    def __init__(self, app):
        super().__init__()
        self.app = app
        self.cfg = app.config
        self._remote_files = []
        self._downloading = False

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        style_scroll(scroll)
        scroll.setWidgetResizable(True)
        root.addWidget(scroll)

        body = QWidget()
        body.setObjectName("surface")
        scroll.setWidget(body)
        bl = QVBoxLayout(body)
        bl.setContentsMargins(20, 16, 20, 16)
        bl.setSpacing(8)

        head = QHBoxLayout()
        title = QLabel("词典")
        title.setStyleSheet("font-size: 18px; font-weight: 700;")
        head.addWidget(title)
        head.addStretch(1)
        self.lbl_stats = QLabel("")
        self.lbl_stats.setObjectName("muted")
        head.addWidget(self.lbl_stats)
        bl.addLayout(head)

        # 1. 本地导入
        bl.addWidget(self._section("1. 添加我的词典"))
        note = QLabel("从电脑选择 JSON 或 TXT 词典。导入后会保存在本地，可用于查词和新建学习计划。")
        note.setObjectName("muted")
        note.setWordWrap(True)
        bl.addWidget(note)
        local_row = QHBoxLayout()
        self.btn_local = make_button("📂 选择本地词典", "primary", self.pick_local)
        local_row.addWidget(self.btn_local)
        self.lbl_local = QLabel("")
        self.lbl_local.setObjectName("muted")
        local_row.addWidget(self.lbl_local, 1)
        bl.addLayout(local_row)

        # 2. 在线获取
        bl.addWidget(self._section("2. 获取在线词典"))
        online_note = QLabel(
            "来源：KyleBing/english-vocabulary。点击获取后会自动读取项目中的全部可用词典"
            "（TXT / JSON / JSONL / TSV），勾选需要的词典再下载；下载后可离线使用。")
        online_note.setObjectName("muted")
        online_note.setWordWrap(True)
        bl.addWidget(online_note)
        online_row = QHBoxLayout()
        self.btn_fetch = make_button("🌐 获取在线词典", "secondary", self.fetch_online)
        online_row.addWidget(self.btn_fetch)
        self.btn_download = make_button("下载选中的词典", "primary", self.download_selected)
        self.btn_download.setEnabled(False)
        online_row.addWidget(self.btn_download)
        self.lbl_online = QLabel("")
        self.lbl_online.setObjectName("muted")
        online_row.addWidget(self.lbl_online, 1)
        bl.addLayout(online_row)

        self.remote_list = QListWidget()
        self.remote_list.setMinimumHeight(160)
        self.remote_list.setVisible(False)
        self.remote_list.itemChanged.connect(self._update_download_button)
        bl.addWidget(self.remote_list)

        # 已下载/已导入列表
        bl.addWidget(self._section("我的词典列表（已下载 / 本地导入）"))
        self.files_box = QVBoxLayout()
        self.files_box.setSpacing(4)
        bl.addLayout(self.files_box)
        bl.addStretch(1)

        self._online_list_ready.connect(self._on_online_list)
        self._download_done.connect(self._on_download_done)
        self.refresh()

    def _section(self, text):
        lbl = QLabel(text)
        lbl.setStyleSheet("color: %s; font-weight: 600; font-size: 14px;"
                          % cfg_hex(self.cfg, "primary"))
        return lbl

    # ---------------- 本地词典 ----------------
    def pick_local(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "选择我的词典", "",
            "词典文件 (*.json *.txt);;JSON 词典 (*.json);;TXT 词典 (*.txt);;所有文件 (*.*)")
        if not path:
            return
        try:
            if os.path.splitext(path)[1].lower() == ".txt":
                record = self.cfg.dictionary_store.import_text_file(path)
            else:
                record = self.cfg.dictionary_store.import_file(path)
        except Exception as exc:
            self.lbl_local.setText(f"导入失败：{exc}")
            self.lbl_local.setStyleSheet("color: %s;" % cfg_hex(self.cfg, "error"))
            return
        self.lbl_local.setText(f"✓ 已添加「{record['label']}」，共 {record['count']} 词")
        self.lbl_local.setStyleSheet("color: %s;" % cfg_hex(self.cfg, "success"))
        self.refresh()

    # ---------------- 在线词典 ----------------
    def fetch_online(self):
        if self._downloading:
            return
        self.btn_fetch.setEnabled(False)
        self.btn_download.setEnabled(False)
        self.lbl_online.setText("正在读取 GitHub 词典列表…")

        def _work():
            try:
                from ...services.wordbooks import KyleBingWordbooks
                files = KyleBingWordbooks.list_dictionary_files()
                self._online_list_ready.emit(files)
            except Exception as exc:
                self._online_list_ready.emit({"error": str(exc)})

        threading.Thread(target=_work, daemon=True).start()

    def _on_online_list(self, payload):
        self.btn_fetch.setEnabled(True)
        if isinstance(payload, dict) and payload.get("error"):
            self.remote_list.setVisible(False)
            self.lbl_online.setText(f"获取失败：{payload['error']}")
            return

        self._remote_files = list(payload or [])
        self.remote_list.clear()
        for entry in self._remote_files:
            name = entry.get("name", "词典")
            size = int(entry.get("size", 0) or 0)
            fmt = {"json": "JSON", "jsonl": "JSONL", "tsv": "TSV", "txt": "TXT"}.get(
                entry.get("format"), "词典")
            item = QListWidgetItem(f"{name}　[{fmt}]　({size / 1024 / 1024:.1f} MB)")
            item.setData(Qt.UserRole, entry)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Unchecked)
            self.remote_list.addItem(item)
        self.remote_list.setVisible(bool(self._remote_files))
        self.lbl_online.setText(f"共发现 {len(self._remote_files)} 本词典，请勾选后下载")
        self._update_download_button()

    def _checked_entries(self):
        out = []
        for i in range(self.remote_list.count()):
            item = self.remote_list.item(i)
            if item.checkState() == Qt.Checked:
                out.append(item.data(Qt.UserRole))
        return out

    def _update_download_button(self, *_):
        self.btn_download.setEnabled(bool(self._checked_entries()) and not self._downloading)

    def download_selected(self):
        entries = self._checked_entries()
        if not entries or self._downloading:
            return
        self._downloading = True
        self.btn_fetch.setEnabled(False)
        self.btn_download.setEnabled(False)
        self.lbl_online.setText(f"准备下载 {len(entries)} 本词典…")

        def _work():
            records = []
            errors = []
            try:
                from ...services.wordbooks import KyleBingWordbooks
                for i, entry in enumerate(entries, 1):
                    try:
                        name = entry.get("name", "词典")
                        self._download_done.emit({"progress": f"正在下载 {i}/{len(entries)}：{name}"})
                        records.append(KyleBingWordbooks.import_to_store(
                            entry, self.cfg.dictionary_store))
                    except Exception as exc:
                        errors.append(f"{entry.get('name', '词典')}：{exc}")
            except Exception as exc:
                errors.append(str(exc))
            self._download_done.emit({"records": records, "errors": errors})

        threading.Thread(target=_work, daemon=True).start()

    def _on_download_done(self, payload):
        if payload.get("progress"):
            self.lbl_online.setText(payload["progress"])
            return
        self._downloading = False
        self.btn_fetch.setEnabled(True)
        self._update_download_button()
        records = payload.get("records", [])
        errors = payload.get("errors", [])
        if records and errors:
            self.lbl_online.setText(f"已下载 {len(records)} 本，{len(errors)} 本失败")
        elif records:
            self.lbl_online.setText(f"✓ 已下载 {len(records)} 本词典")
        elif errors:
            self.lbl_online.setText(f"下载失败：{errors[0]}")
        self.refresh()
        if records and hasattr(self.app, "toasts"):
            self.app.toasts.show(f"已添加 {len(records)} 本在线词典", kind="success")

    # ---------------- 已安装词典 ----------------
    def refresh(self):
        records = self.cfg.dictionary_store.list_files()
        local_count = sum(1 for r in records if r.get("kind") != "online")
        online_count = sum(1 for r in records if r.get("kind") == "online")
        self.lbl_stats.setText(f"在线 {online_count} 本 · 我的 {local_count} 本")
        while self.files_box.count():
            item = self.files_box.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()
        if not records:
            empty = QLabel("还没有词典，请先添加本地词典或获取在线词典。")
            empty.setObjectName("muted")
            self.files_box.addWidget(empty)
            return
        for record in records:
            row = QHBoxLayout()
            kind = "在线" if record.get("kind") == "online" else "我的"
            label = QLabel(f"{kind}　{record.get('label', record['filename'])}　·　{record.get('count', 0)} 词")
            row.addWidget(label, 1)
            # clicked(bool) 会把按钮的 checked 状态传进 lambda；显式接住它，
            # 避免把 record 覆盖成 True/False。
            btn = make_button("删除", "danger",
                              lambda _checked=False, r=record: self.remove_file(r))
            row.addWidget(btn)
            holder = QWidget()
            holder.setLayout(row)
            self.files_box.addWidget(holder)

    def remove_file(self, record):
        answer = QMessageBox.question(
            self, "删除词典", f"确认删除「{record.get('label', '')}」？")
        if answer != QMessageBox.Yes:
            return
        self.cfg.dictionary_store.remove_file(record["filename"])
        self.refresh()
        if hasattr(self.app, "toasts"):
            self.app.toasts.show("词典已删除", kind="info")
