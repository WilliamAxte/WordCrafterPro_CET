# ==============================================================================
# 文件路径: wordcrafter/qt/pages/study_page.py
# 记单词（v2）：
#   - 学习计划 StudyDeck（来源：生词库 / 自定义单词(粘贴+导入TXT) / 本地词典词书）
#   - 复习优先门控：存在到期复习必须先完成，才能解锁新词
#   - SRS 记录 + 每日日志（今日树状统计，QTreeWidget 可折叠）
#   - 本地词典立即显示 → 在线异步增强；断网仍可学习；发音走统一服务
# ==============================================================================
import threading

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtWidgets import (QComboBox, QDialog, QDialogButtonBox, QFormLayout,
                               QFrame, QHBoxLayout, QLabel, QLineEdit, QSizePolicy,
                               QPushButton, QScrollArea, QStackedLayout,
                               QTextEdit, QTreeWidget, QTreeWidgetItem,
                               QVBoxLayout, QWidget)

from ...core import srs as srs_core
from ...services.ai import AIService
from ...services.definitions import DictionaryService
from ...services.pronunciation import PronunciationService
from ..widgets import EmptyState, cfg_hex, make_button

RATINGS = [("forget", "忘记"), ("hard", "困难"), ("good", "一般"), ("easy", "简单")]
SOURCE_LABELS = {"vocab": "生词库", "custom": "自定义单词", "local_dict": "我的词典"}


class _NewDeckDialog(QDialog):
    """新建学习计划：选择来源。"""

    def __init__(self, app, parent=None):
        super().__init__(parent)
        self.app = app
        self.setWindowTitle("新建学习计划")
        self.setMinimumWidth(460)
        form = QFormLayout(self)

        self.edit_name = QLineEdit()
        form.addRow("计划名称", self.edit_name)

        self.combo_source = QComboBox()
        self.combo_source.addItem("生词库", "vocab")
        self.combo_source.addItem("自定义单词（粘贴 / TXT）", "custom")
        store = app.config.dictionary_store.list_files()
        if store:
            self.combo_source.addItem("我的词典（已下载 / 本地）", "local_dict")
        self.combo_source.currentIndexChanged.connect(self._on_source)
        form.addRow("学习来源", self.combo_source)

        self.stack = QStackedLayout()
        # 生词库：说明
        self.lbl_vocab = QLabel("使用「统一生词库」——阅读收藏/词典加入/导入均汇入")
        self.lbl_vocab.setWordWrap(True)
        self.stack.addWidget(self.lbl_vocab)
        # 自定义
        self.txt_words = QTextEdit()
        self.txt_words.setPlaceholderText("每行一个单词，或用逗号/空格分隔；也可从 TXT 导入")
        self.stack.addWidget(self.txt_words)
        # 我的词典：选择已下载或本地导入的词典
        self._store = store
        self.dict_pick = QWidget()
        dl = QVBoxLayout(self.dict_pick)
        dl.setContentsMargins(0, 0, 0, 0)
        self.lbl_dict = QLabel("选择要学习的词典：")
        self.lbl_dict.setWordWrap(True)
        dl.addWidget(self.lbl_dict)
        self.combo_file = QComboBox()
        for rec in store:
            self.combo_file.addItem(f"{rec.get('label')}（{rec.get('count', 0)} 词）",
                                    rec["filename"])
        dl.addWidget(self.combo_file)
        self.stack.addWidget(self.dict_pick)
        form.addRow(self.stack)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._create)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)
        self._on_source(0)

    def _on_source(self, _i):
        idx = self.combo_source.currentIndex()
        self.stack.setCurrentIndex(min(idx, self.stack.count() - 1))

    def _create(self):
        name = self.edit_name.text().strip() or "新计划"
        src = self.combo_source.currentData()
        words = None
        source_id = None
        if src == "custom":
            text = self.txt_words.toPlainText()
            from ...core.text_utils import parse_words
            words = parse_words(text)
            if not words:
                return
        elif src == "local_dict" and self._store:
            source_id = self.combo_file.currentData()
        deck = self.app.decks.create(name, src, source_id=source_id, words=words)
        self.app.decks.set_active(deck["id"])
        self.accept()


class StudyPage(QWidget):
    _dict_ready = Signal(object)

    def __init__(self, app):
        super().__init__()
        self.app = app
        self.cfg = app.config
        self.repo = app.study
        self.logs = app.logs
        self.setFocusPolicy(Qt.StrongFocus)

        self.queue = []
        self.pos = 0
        self.current_word = None
        self.revealed = False
        self.session_done = 0
        self.mode = "new"          # new | review
        self._entry = None
        self._ai_busy = False

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        self.stack = QStackedLayout()
        root.addLayout(self.stack, 1)

        self._build_overview()
        self._build_study()
        self._build_done()
        self.show_overview()

        self._dict_ready.connect(self._apply_entry)

    # ---------- 当前计划词表 ----------
    def _deck(self):
        return self.app.decks.active()

    def _deck_words(self):
        return self.app.decks.word_set(self._deck(), self.cfg)

    def _words(self):
        words = self._deck_words()
        return words if words else list(self.cfg.vocab_history)

    # ================= 今日总览 =================
    def _build_overview(self):
        cfg = self.cfg
        self.overview = QWidget()
        lay = QVBoxLayout(self.overview)
        lay.setContentsMargins(24, 20, 24, 16)
        lay.setSpacing(8)

        title = QLabel("记单词")
        title.setStyleSheet("font-size: 20px; font-weight: 700;")
        lay.addWidget(title)

        # 计划切换行
        prow = QHBoxLayout()
        self.lbl_plan = QLabel("")
        self.lbl_plan.setStyleSheet("color: %s; font-weight: 600;"
                                    % cfg_hex(cfg, "primary"))
        prow.addWidget(self.lbl_plan)
        prow.addStretch(1)
        btn_new_plan = make_button("＋ 新建学习计划", "secondary",
                                   self._new_deck)
        prow.addWidget(btn_new_plan)
        lay.addLayout(prow)

        # 行动区（复习门控）
        act = QFrame()
        act.setObjectName("card")
        al = QHBoxLayout(act)
        al.setContentsMargins(16, 10, 16, 10)
        self.btn_review = make_button("开始复习", "primary", self.start_review)
        self.btn_review.setFixedHeight(34)
        al.addWidget(self.btn_review)
        self.btn_new_words = make_button("学习新词", "secondary", self.start_new)
        self.btn_new_words.setFixedHeight(34)
        al.addWidget(self.btn_new_words)
        self.lbl_gate = QLabel("")
        self.lbl_gate.setObjectName("muted")
        al.addWidget(self.lbl_gate, 1)
        lay.addWidget(act)

        # 今日树状统计
        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setMaximumHeight(240)
        lay.addWidget(self.tree, 1)

        # 计划列表（可滚动，小高度）
        self.lbl_decks = QLabel("学习计划")
        self.lbl_decks.setObjectName("muted")
        lay.addWidget(self.lbl_decks)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setMaximumHeight(180)
        from ..widgets import style_scroll
        style_scroll(scroll)
        self.deck_box = QWidget()
        self.deck_layout = QVBoxLayout(self.deck_box)
        self.deck_layout.setContentsMargins(0, 0, 0, 0)
        self.deck_layout.setSpacing(2)
        scroll.setWidget(self.deck_box)
        lay.addWidget(scroll)

        self.stack.addWidget(self.overview)

    # ================= 学习卡（复用 v1 结构） =================
    def _build_study(self):
        cfg = self.cfg
        self.study_view = QWidget()
        lay = QVBoxLayout(self.study_view)
        lay.setContentsMargins(16, 12, 16, 12)

        top = QHBoxLayout()
        self.lbl_progress = QLabel("")
        self.lbl_progress.setObjectName("muted")
        top.addWidget(self.lbl_progress)
        top.addStretch(1)
        self.lbl_state_chip = QLabel("")
        self.lbl_state_chip.setObjectName("muted")
        top.addWidget(self.lbl_state_chip)
        btn_end = make_button("结束学习", "ghost", self.finish_session)
        top.addWidget(btn_end)
        lay.addLayout(top)

        center = QHBoxLayout()
        center.setContentsMargins(18, 8, 18, 8)
        card = QFrame()
        card.setObjectName("surface")
        # 让卡片吃掉可用宽度；原来只有 sizeHint，窗口变宽时就会缩成窄条。
        card.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        card.setMaximumWidth(1120)
        card.setMinimumWidth(520)
        cl = QVBoxLayout(card)
        cl.setContentsMargins(28, 24, 28, 24)
        cl.setSpacing(8)

        wrow = QHBoxLayout()
        wrow.addStretch(1)
        self.lbl_word = QLabel("")
        self.lbl_word.setStyleSheet("font-size: 30px; font-weight: 700;")
        wrow.addWidget(self.lbl_word)
        self.lbl_phonetic = QLabel("")
        self.lbl_phonetic.setObjectName("muted")
        wrow.addWidget(self.lbl_phonetic)
        from ..widgets import make_emoji_icon
        btn_speak = make_emoji_icon("🔊", self.speak_word, tip="播放发音", size=34)
        wrow.addWidget(btn_speak)
        wrow.addStretch(1)
        cl.addLayout(wrow)

        self.lbl_answer = QLabel("点击「显示答案」或按 空格 查看释义")
        self.lbl_answer.setWordWrap(True)
        self.lbl_answer.setTextInteractionFlags(Qt.TextSelectableByMouse)
        cl.addWidget(self.lbl_answer, 1)

        self.btn_reveal = make_button("显示答案", "primary", self.reveal)
        self.btn_reveal.setFocusPolicy(Qt.NoFocus)
        cl.addWidget(self.btn_reveal, 0, Qt.AlignCenter)

        self.rating_row = QHBoxLayout()
        self.rating_row.addStretch(1)
        self._rating_btns = {}
        for key, label in RATINGS:
            b = make_button(label, "secondary",
                            lambda _checked=False, k=key: self.rate(k))
            b.setFocusPolicy(Qt.NoFocus)
            self.rating_row.addWidget(b)
            self._rating_btns[key] = b
        self.rating_row.addStretch(1)
        self.ai_btn = make_button("✨ AI 记忆提示", "ghost", self.ai_tip)
        self.ai_btn.setFocusPolicy(Qt.NoFocus)
        self.rating_row.addWidget(self.ai_btn)
        cl.addLayout(self.rating_row)

        # 不设置 AlignCenter：带 stretch 的 Expanding 卡片才能真正填满内容区。
        center.addWidget(card, 1)
        lay.addLayout(center, 1)
        self.stack.addWidget(self.study_view)

    def _build_done(self):
        cfg = self.cfg
        self.done_view = EmptyState(
            cfg, "🎉", "本次学习完成", "记忆状态已保存",
            action_label="返回今日", action_command=self.show_overview)
        self.stack.addWidget(self.done_view)

    # ================= 总览数据 =================
    def show_overview(self):
        self.stack.setCurrentWidget(self.overview)
        self.repo = self.app.study
        words = self._words()
        stats = self.repo.stats(words)
        deck = self._deck()
        self.lbl_plan.setText(f"当前计划：{(deck or {}).get('name', '（未创建，默认使用生词库）')}"
                              f"　·　词库 {len(words)} 词")
        due = stats["due"]
        fresh = stats["new"]
        self.btn_review.setEnabled(due > 0)
        self.btn_review.setText(f"开始复习（{due}）" if due else "今日复习完成 ✓")
        locked = due > 0
        self.btn_new_words.setEnabled(fresh > 0 and not locked)
        self.btn_new_words.setText("学习新词"
                                   if not locked else "完成复习后解锁新词")
        self.lbl_gate.setText(("新词将被锁定，先完成到期复习" if locked else
                               "复习优先：全部到期复习完成后新词解锁") if due else
                              "今日暂无到期复习，可直接学习新词")
        self._render_tree()
        self._render_decks()

    def _render_tree(self):
        self.tree.clear()
        day = self.logs.get_day()
        total = day.get("total", 0)
        root_item = QTreeWidgetItem([f"今日学习　{total} 次"])
        root_item.setExpanded(True)
        for label, key in (("新词", "new"), ("复习", "review")):
            node = QTreeWidgetItem([f"{label}　{day.get(key, 0)}"])
            for rlabel, rkey in (("简单", "easy"), ("一般", "good"),
                                 ("困难", "hard"), ("忘记", "forget")):
                leaf = QTreeWidgetItem([f"{rlabel}　{day.get(rkey, 0)}"])
                node.addChild(leaf)
            root_item.addChild(node)
        self.tree.addTopLevelItem(root_item)

    def _render_decks(self):
        while self.deck_layout.count():
            item = self.deck_layout.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()
        active = self.app.decks.active()
        for deck in self.app.decks.decks:
            row = QHBoxLayout()
            words = self.app.decks.word_set(deck, self.cfg)
            label = (("● " if deck.get("is_active") else "○ ")
                     + f"{deck.get('name')} · {SOURCE_LABELS.get(deck.get('source_type'), '')}"
                       f" · {len(words)} 词")
            lbl = QLabel(label)
            row.addWidget(lbl)
            row.addStretch(1)
            if not deck.get("is_active"):
                btn = make_button("设为当前", "ghost",
                                  lambda _checked=False, d=deck: self._activate_deck(d))
                row.addWidget(btn)
            btn_del = make_button(
                "删除", "danger",
                lambda _checked=False, d=deck: self._delete_deck(d))
            row.addWidget(btn_del)
            holder = QWidget()
            holder.setLayout(row)
            self.deck_layout.addWidget(holder)
        self.deck_layout.addStretch(1)

    def _activate_deck(self, deck):
        self.app.decks.set_active(deck["id"])
        self.show_overview()

    def _delete_deck(self, deck):
        self.app.decks.delete(deck["id"])
        self.show_overview()

    def _new_deck(self):
        dlg = _NewDeckDialog(self.app, self)
        dlg.exec()
        self.show_overview()

    # ================= 会话流程 =================
    def start_review(self):
        words = self._words()
        due = [w for w in words
               if (self.repo.get(w).get("state") not in (srs_core.STATE_NEW,
                                                         srs_core.STATE_MASTERED)
                   and self.repo.get(w).get("next_review", 0) <= self._now())]
        if not due:
            self.app.toasts.show("今日暂无到期复习", kind="info")
            return
        self._begin(due, "review")

    def start_new(self):
        words = self._words()
        # 门控：存在到期复习时锁定新词
        due = [w for w in words
               if (self.repo.get(w).get("state") not in (srs_core.STATE_NEW,
                                                         srs_core.STATE_MASTERED)
                   and self.repo.get(w).get("next_review", 0) <= self._now())]
        if due:
            self.app.toasts.show("请先完成到期复习（新词已锁定）", kind="info")
            return
        fresh = [w for w in words
                 if self.repo.get(w).get("state") == srs_core.STATE_NEW]
        limit = int(self.cfg.config_repo.data.get("daily_new_words", 10) or 10)
        self._begin(fresh[:limit], "new")

    def start_session(self):
        # 兼容旧调用：智能选择（到期优先）
        due = [w for w in self._words() if self._due(w)]
        if due:
            self.start_review()
        else:
            self.start_new()

    def _now(self):
        import time
        return time.time()

    def _due(self, w):
        card = self.repo.get(w)
        return (card.get("state") not in (srs_core.STATE_NEW, srs_core.STATE_MASTERED)
                and card.get("next_review", 0) <= self._now())

    def _begin(self, queue, mode):
        self.queue = list(queue)
        self.pos = 0
        self.session_done = 0
        self.mode = mode
        if not self.queue:
            self.app.toasts.show("没有待学习内容", kind="info")
            return
        self.stack.setCurrentWidget(self.study_view)
        self.setFocus()
        self._next()

    def _next(self):
        if self.pos >= len(self.queue):
            self.finish_session()
            return
        self.current_word = self.queue[self.pos]
        self.revealed = False
        card = self.repo.get(self.current_word)
        self.lbl_progress.setText(f"{'复习' if self.mode == 'review' else '新词'} "
                                  f"{self.pos + 1} / {len(self.queue)}")
        self.lbl_state_chip.setText(srs_core.STATE_NAMES_CN.get(
            card.get("state", srs_core.STATE_NEW), "新词"))
        self.lbl_word.setText(self.current_word)
        self.lbl_phonetic.setText("")
        self.lbl_answer.setText("点击「显示答案」或按 空格 查看释义")
        self.btn_reveal.show()
        for b in self._rating_btns.values():
            b.setVisible(False)
        self.ai_btn.hide()
        self._entry = None
        self._local_fill()
        DictionaryService.lookup_async(
            self.current_word, self.cfg,
            lambda entry, layer: self._dict_ready.emit((entry, layer)))
        self.setFocus()

    def _local_fill(self):
        cfg = self.cfg
        entry = cfg.vocab_repo.cache.get(self.current_word)
        if not entry:
            entry = cfg.dictionary_store.get(self.current_word)
        if entry:
            self._entry = entry
            self.lbl_phonetic.setText(entry.get("phonetic", ""))

    def _apply_entry(self, payload):
        entry, layer = payload
        if not entry:
            return
        self._entry = entry
        if entry.get("phonetic"):
            self.lbl_phonetic.setText(entry["phonetic"])
        if self.revealed:
            self._render_answer()

    def reveal(self):
        if self.revealed:
            return
        self.revealed = True
        self.btn_reveal.hide()
        for b in self._rating_btns.values():
            b.setVisible(True)
        self.ai_btn.show()
        self._render_answer()
        self.setFocus()

    def _answer_text(self):
        e = self._entry or {}
        pos = (e.get("pos_def") or "").strip()
        ex = (e.get("example") or "").strip()
        parts = []
        if pos:
            parts.append(f"【释义】\n{pos}")
        if ex:
            parts.append(f"【例句】\n{ex}")
        if not parts:
            parts.append("（本地暂无释义，正在尝试在线词典…\n可在词典页添加我的词典）")
        return "\n\n".join(parts)

    def _render_answer(self):
        self.lbl_answer.setText(self._answer_text())
        card = self.repo.get(self.current_word)
        mem = (card or {}).get("memory")
        if mem and "【AI 记忆辅助】" not in self.lbl_answer.text():
            self.lbl_answer.setText(self.lbl_answer.text() + "\n\n【AI 记忆辅助】\n" + mem)

    def rate(self, key):
        if not self.revealed or not self.current_word:
            return
        card = self.repo.get(self.current_word)
        was_new = card.get("state") == srs_core.STATE_NEW
        self.repo.record_review(self.current_word, key)
        try:
            self.logs.record(self._now(), was_new, key, self.current_word)
        except Exception:
            pass
        self.session_done += 1
        self.pos += 1
        self._next()
        self.setFocus()

    def finish_session(self):
        self.queue = []
        if self.session_done > 0:
            self.stack.setCurrentWidget(self.done_view)
        else:
            self.show_overview()

    def on_activated(self):
        self.show_overview()

    def speak_word(self):
        if self.current_word:
            PronunciationService.play(self.current_word, self.cfg)

    def ai_tip(self):
        if self._ai_busy or not self.current_word:
            return
        if not self.cfg.api_key:
            self.app.toasts.show("未配置 API Key（离线学习不受影响）", kind="info")
            return
        self._ai_busy = True
        self.ai_btn.setEnabled(False)
        self.ai_btn.setText("生成中…")
        prompt = (f"为英语学习者生成「{self.current_word}」的记忆提示（简短列表）：\n"
                  f"词根词缀 / 联想 / 近义词 / 易混词 / 常见搭配 各一行")
        collected = []

        def on_token(token):
            collected.append(token)

        def _run():
            try:
                AIService._stream_request(prompt, self.cfg.api_key,
                                          self.cfg.api_url, self.cfg.model_name,
                                          on_token)
                text = "".join(collected).strip() or "（无返回内容）"
                QTimer.singleShot(0, lambda: self._show_ai(text))
            except Exception as exc:
                QTimer.singleShot(0, lambda: self._show_ai(f"（生成失败：{exc}）", error=True))

        threading.Thread(target=_run, daemon=True).start()

    def _show_ai(self, text, error=False):
        self._ai_busy = False
        self.ai_btn.setEnabled(True)
        self.ai_btn.setText("✨ AI 记忆提示")
        if not error and "失败" not in text:
            try:
                card = self.repo.get(self.current_word)
                card["memory"] = text
                self.repo.save()
            except Exception:
                pass
        if "【AI 记忆辅助】" in self.lbl_answer.text():
            return
        self.lbl_answer.setText(self.lbl_answer.text() + "\n\n【AI 记忆辅助】\n" + text)

    def keyPressEvent(self, event):
        key = event.key()
        if self.stack.currentWidget() is not self.study_view:
            return super().keyPressEvent(event)
        if key == Qt.Key_Space:
            self.reveal()
            event.accept()
        elif key == Qt.Key_P:
            self.speak_word()
            event.accept()
        elif key in (Qt.Key_1, Qt.Key_2, Qt.Key_3, Qt.Key_4):
            if self.revealed:
                self.rate(["forget", "hard", "good", "easy"][key - Qt.Key_1])
            event.accept()
        elif key == Qt.Key_Escape:
            self.finish_session()
            event.accept()
        else:
            super().keyPressEvent(event)
