# ==============================================================================
# 文件路径: wordcrafter/qt/pages/acg_page.py
# ACG 模式（Qt）—— 特稿生成：题材/主题/词源/词数/篇幅 + 流式正文
# ==============================================================================
import random
import threading

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtWidgets import (QButtonGroup, QCheckBox, QComboBox, QFileDialog,
                               QFrame, QHBoxLayout, QLabel, QLineEdit,
                               QPlainTextEdit, QStackedLayout, QVBoxLayout,
                               QWidget)

from ...services.ai import AIService, StreamRouter
from ..newspaper import NewspaperReader
from ..typography import (DEFAULT_SIZE, get_saved_size, save_size, set_plain_font,
                          step_size)
from ..widgets import (ChunkSink, EmptyState, append_text, attach_text_menu,
                       cfg_hex, make_button, make_pill)

FONT_KEY = "content_font_size"

_CATEGORIES = [
    "🎬 动画深度漫评与剧情杂谈",
    "🎮 电子游戏世界观与评测报道",
    "🎵 动漫音乐/Galgame配乐/OST赏析",
    "🌆 赛博朋克与科幻随笔",
    "🏆 泛二次元文化观察",
]
_SOURCES = ["随机从历史词库抽取", "抽取最近学习的单词", "从第一页当前输入框抽取"]
_LENGTHS = ["精简漫评 (~200词)", "深度特稿 (~600词)", "千字深度长文 (~1000词)", "自定义字数"]
_CUSTOM = "自定义字数"
_DOTS = ["●○○", "○●○", "○○●"]


class AcgPage(QWidget):
    """Qt ACG 特稿工作页。"""

    finished_ok = Signal(object)
    failed = Signal(str)

    def __init__(self, app):
        super().__init__()
        self.app = app
        self.cfg = app.config
        self.generating = False
        self._dots = 0
        self.px = get_saved_size(self.cfg, FONT_KEY, DEFAULT_SIZE)

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        self.stack = QStackedLayout()
        root.addLayout(self.stack, 1)

        self.empty = EmptyState(self.cfg, "🎬", "写一篇 ACG 深度特稿",
                                "选择题材与作品主题，词条从生词库/输入框抽取")
        self.stack.addWidget(self.empty)
        self._build_reader()
        self.stack.addWidget(self.reader)
        self.set_state("empty")

        self.finished_ok.connect(self._on_success)
        self.failed.connect(self._on_error)

    def _build_reader(self):
        cfg = self.cfg
        self.reader = QFrame()
        self.reader.setObjectName("surface")
        lay = QVBoxLayout(self.reader)
        lay.setContentsMargins(16, 12, 16, 12)
        lay.setSpacing(6)

        head = QHBoxLayout()
        self.lbl_title = QLabel("ACG 深度特稿")
        self.lbl_title.setStyleSheet("font-size: 16px; font-weight: 600;")
        head.addWidget(self.lbl_title)
        self.lbl_state = QLabel("")
        self.lbl_state.setObjectName("muted")
        head.addWidget(self.lbl_state)
        head.addStretch(1)
        bg = QButtonGroup(self)
        self._pills = {}
        for i, (key, text) in enumerate([("dual", "📖 双语对照"), ("en", "🔤 纯英文"),
                                         ("zh", "🇨🇳 仅看中文")]):
            pill = make_pill(text, checked=(key == "dual"))
            pill.clicked.connect(lambda _=False, k=key: self.set_view(k))
            bg.addButton(pill, i)
            self._pills[key] = pill
            head.addWidget(pill)
        lay.addLayout(head)

        body = QWidget()
        bl = QVBoxLayout(body)
        bl.setContentsMargins(0, 0, 0, 0)
        bl.setSpacing(6)
        self.txt_en = QPlainTextEdit()
        self.txt_zh = QPlainTextEdit()
        for e in (self.txt_en, self.txt_zh):
            e.setReadOnly(True)
            e.setLineWrapMode(QPlainTextEdit.WidgetWidth)
            attach_text_menu(e, cfg, self.app)
        set_plain_font(self.txt_en, self.px)
        set_plain_font(self.txt_zh, self.px)
        bl.addWidget(self.txt_en, 1)
        bl.addWidget(self.txt_zh, 1)
        lay.addWidget(body, 1)

        tools = QHBoxLayout()
        tools.setSpacing(4)

        def _apply_font(delta):
            self.px = step_size(cfg, FONT_KEY, self.px, delta)
            save_size(cfg, FONT_KEY, self.px)
            set_plain_font(self.txt_en, self.px)
            set_plain_font(self.txt_zh, self.px)

        btn_fm = make_button("A−", "ghost", lambda: _apply_font(-1))
        tools.addWidget(btn_fm)
        btn_fp = make_button("A+", "ghost", lambda: _apply_font(1))
        tools.addWidget(btn_fp)
        btn_full = make_button("📖 沉浸阅读", "primary", self.open_immersion)
        tools.addWidget(btn_full)
        btn_export = make_button("📤 导出特稿", "ghost", self.export_article)
        tools.addWidget(btn_export)
        tools.addStretch(1)
        lay.addLayout(tools)

    def set_state(self, state):
        if state == "generating":
            self.stack.setCurrentWidget(self.reader)
            self.generating = True
            self._dots = 0
            self.lbl_state.setText("生成中 " + _DOTS[0])
            self._spin()
        elif state == "content":
            self.generating = False
            self.lbl_state.setText("")
            self.stack.setCurrentWidget(self.reader)
        else:
            self.generating = False
            self.lbl_state.setText("")
            self.stack.setCurrentWidget(self.empty)

    def _spin(self):
        if not self.generating:
            return
        self.lbl_state.setText("生成中 " + _DOTS[self._dots % 3])
        self._dots += 1
        QTimer.singleShot(160, self._spin)

    def set_view(self, key):
        self.txt_en.setVisible(key in ("dual", "en"))
        self.txt_zh.setVisible(key in ("dual", "zh"))
        for k, p in self._pills.items():
            p.setChecked(k == key)

    def open_fullscreen(self):
        self.open_immersion()

    def open_immersion(self):
        en = self.txt_en.toPlainText().strip()
        zh = self.txt_zh.toPlainText().strip()
        if not en and not zh:
            self.app.toasts.show("当前无内容", kind="info")
            return
        reader = NewspaperReader(self.cfg, "ACG 特稿", en, zh)
        reader.show()

    def export_article(self):
        en = self.txt_en.toPlainText().strip()
        zh = self.txt_zh.toPlainText().strip()
        if not en and not zh:
            self.app.toasts.show("当前无内容", kind="info")
            return
        path, _ = QFileDialog.getSaveFileName(self, "导出特稿", "acg_review.txt",
                                              "Text Files (*.txt)")
        if not path:
            return
        with open(path, "w", encoding="utf-8") as f:
            f.write(f"=== ACG English Review ===\n\n{en}\n\n"
                    f"=== Chinese Translation ===\n\n{zh}\n")
        self.app.toasts.show("特稿已保存", kind="success")

    # ---------------- 底部 ContextActionBar ----------------
    def build_context_bar(self, container):
        cfg = self.cfg
        bar = QFrame(container)
        bar.setObjectName("bar")
        v = QVBoxLayout(bar)
        v.setContentsMargins(14, 8, 14, 8)
        v.setSpacing(6)

        r1 = QHBoxLayout()
        r1.setSpacing(8)
        r1.addWidget(QLabel("题材"))
        self.combo_cat = QComboBox()
        self.combo_cat.addItems(_CATEGORIES)
        self.combo_cat.setMinimumWidth(200)
        r1.addWidget(self.combo_cat)
        r1.addWidget(QLabel("作品/主题"))
        self.edit_topic = QLineEdit()
        self.edit_topic.setPlaceholderText("例如：Cyberpunk / 赛博朋克科幻动画")
        self.edit_topic.setClearButtonEnabled(True)
        r1.addWidget(self.edit_topic, 1)
        self.lbl_status = QLabel("")
        self.lbl_status.setObjectName("muted")
        r1.addWidget(self.lbl_status)
        self.btn_generate = make_button("🚀 生成特稿", "primary", self.start_generation)
        r1.addWidget(self.btn_generate)
        v.addLayout(r1)

        r2 = QHBoxLayout()
        r2.setSpacing(6)
        r2.addWidget(QLabel("词源"))
        self.combo_source = QComboBox()
        self.combo_source.addItems(_SOURCES)
        r2.addWidget(self.combo_source)
        r2.addWidget(QLabel("词数"))
        self.edit_count = QLineEdit("5")
        self.edit_count.setFixedWidth(44)
        r2.addWidget(self.edit_count)
        r2.addWidget(QLabel("篇幅"))
        self.combo_len = QComboBox()
        self.combo_len.addItems(_LENGTHS)
        self.combo_len.currentTextChanged.connect(self._on_len_change)
        r2.addWidget(self.combo_len)
        self.edit_custom_len = QLineEdit("1000")
        self.edit_custom_len.setFixedWidth(56)
        self.edit_custom_len.hide()
        r2.addWidget(self.edit_custom_len)
        self.chk_extra = QCheckBox("拓展词汇")
        r2.addWidget(self.chk_extra)
        self.edit_extra = QLineEdit("3")
        self.edit_extra.setFixedWidth(40)
        r2.addWidget(self.edit_extra)
        r2.addStretch(1)
        v.addLayout(r2)

        cbox = container.layout()
        if cbox is None:
            cbox = QVBoxLayout(container)
            cbox.setContentsMargins(0, 0, 0, 0)
        cbox.addWidget(bar)

    def _on_len_change(self, text):
        self.edit_custom_len.setVisible(_CUSTOM in text)

    # ---------------- 生成 ----------------
    def _pick_words(self, hist, target_count):
        combo = getattr(self, "combo_source", None)
        src = combo.currentText() if combo is not None else _SOURCES[0]
        if "第一页" in src:
            page_vocab = self.app.pages.get("vocab")
            words = page_vocab.parse_input_words() if page_vocab else []
            if not words:
                return None, "第一页输入框中暂无单词"
            return random.sample(words, min(target_count, len(words))), None
        if "最近学习" in src:
            if len(hist) >= target_count:
                return hist[-target_count:], None
            return hist, None
        if not hist:
            return None, "词库暂无历史生词，请先在单词页添加"
        return random.sample(hist, min(target_count, len(hist))), None

    def start_generation(self):
        if self.generating:
            return
        try:
            target_count = max(1, int(self.edit_count.text().strip()))
        except Exception:
            target_count = 5
        chosen, err = self._pick_words(self.cfg.vocab_history, target_count)
        if err:
            self._status(err, "error")
            return
        len_mode = self.combo_len.currentText()
        target_len = (f"{self.edit_custom_len.text().strip()} 词左右"
                      if _CUSTOM in len_mode else len_mode)
        extra_cnt = 0
        if self.chk_extra.isChecked():
            try:
                extra_cnt = max(0, int(self.edit_extra.text().strip()))
            except Exception:
                extra_cnt = 3
        topic = self.edit_topic.text().strip() or "Modern ACG Culture Trends"
        category = self.combo_cat.currentText()

        self.txt_en.clear()
        self.txt_zh.clear()
        self.btn_generate.setEnabled(False)
        self.set_state("generating")
        self._status("正在构思…", None)

        sink_en = ChunkSink(self)
        sink_zh = ChunkSink(self)
        sink_en.chunk.connect(lambda t: append_text(self.txt_en, t))
        sink_zh.chunk.connect(lambda t: append_text(self.txt_zh, t))
        threading.Thread(target=self._worker,
                         args=(chosen, extra_cnt, target_len, category, topic,
                               sink_en, sink_zh),
                         daemon=True).start()

    def _worker(self, words, extra_cnt, target_len, category, topic, sink_en, sink_zh):
        cfg = self.cfg
        router = StreamRouter(sink_en, sink_zh)
        try:
            AIService.generate_acg_story_stream(
                words, extra_cnt, target_len, category, topic,
                cfg.difficulty, cfg.api_key, cfg.api_url, cfg.model_name, router.feed)
            router.close()
            self.finished_ok.emit({"words": words, "topic": topic, "length": target_len})
        except Exception as exc:
            self.failed.emit(str(exc))

    def _on_success(self, meta):
        self.generating = False
        self.btn_generate.setEnabled(True)
        self._status("✓ 特稿完成 · 右键划词可查词/朗读/收入生词库", "success")
        self.set_state("content")
        try:
            en = self.txt_en.toPlainText().strip()
            zh = self.txt_zh.toPlainText().strip()
            self.app.add_session("acg", (meta["topic"] or "ACG 特稿")[:40],
                                 summary=(en or "")[:120].replace("\n", " "),
                                 meta={"words": meta["words"][:8],
                                       "topic": meta["topic"],
                                       "length": meta["length"]},
                                 content={"en": en, "zh": zh})
        except Exception:
            pass

    def restore_session(self, session):
        """从历史恢复：还原特稿内容与主题。"""
        content = session.get("content") or {}
        en = (content.get("en") or "").strip()
        zh = (content.get("zh") or "").strip()
        if not en and not zh:
            return False
        self.txt_en.setPlainText(en)
        self.txt_zh.setPlainText(zh)
        params = session.get("parameters") or {}
        topic = params.get("topic") or session.get("title", "")
        if topic and hasattr(self, "edit_topic"):
            self.edit_topic.setText(topic)
        self.set_state("content")
        return True

    def _on_error(self, err):
        self.generating = False
        self.btn_generate.setEnabled(True)
        self._status(f"✕ 生成失败：{err}", "error")
        self.set_state("content")
        self.app.toasts.show(f"生成失败：{err}", kind="error")

    def _status(self, text, tone):
        color = {"success": cfg_hex(self.cfg, "success"),
                 "error": cfg_hex(self.cfg, "error")}.get(tone)
        if not hasattr(self, "lbl_status"):
            return
        self.lbl_status.setText(text)
        self.lbl_status.setStyleSheet(f"color: {color};" if color else "")
