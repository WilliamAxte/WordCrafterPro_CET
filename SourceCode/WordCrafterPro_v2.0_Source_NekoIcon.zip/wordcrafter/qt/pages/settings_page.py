# ==============================================================================
# 文件路径: wordcrafter/qt/pages/settings_page.py
# 设置模式（Qt）：外观(深浅/字号/主题色) · 壁纸 · AI 接口 · GPU · 微软翻译语音 ·
#               关于与更新 —— 配置键与 CTk 版完全一致
# ==============================================================================
import os
import webbrowser

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QCheckBox, QComboBox, QFileDialog, QFrame,
                               QHBoxLayout, QLabel, QLineEdit, QPushButton,
                               QScrollArea, QSlider, QVBoxLayout, QWidget)

from ...services.microsoft import MicrosoftSpeechService
from ...services.updater import CURRENT_VERSION, UpdateService
from ...theme.presets import ACCENTS, ACCENT_IDS, ACCENT_NAMES
from ..theme import qss
from ..widgets import cfg_hex, make_button, style_scroll

_FONT_SCALES = ["精小 (90%)", "标准 (100%)", "放大 (112%)", "特大 (125%)"]
_MODELS = ["deepseek-chat", "deepseek-reasoner", "gpt-4o", "gpt-4o-mini",
           "claude-3-7-sonnet", "qwen-max"]
_DIFFICULTIES = ["初高中/日常通俗 (周围词汇极简)", "大学四级 (通顺自然)",
                 "考研/六级/雅思 (地道语境)"]
_VOICES = [
    "en-US-JennyNeural (美音·女声·自然)", "en-US-GuyNeural (美音·男声·沉稳)",
    "en-US-AriaNeural (美音·女声·新闻)", "en-GB-SoniaNeural (英音·女声·优雅)",
    "en-GB-RyanNeural (英音·男声·清脆)",
]


class SettingsPage(QWidget):
    """Qt 设置工作页。"""

    _update_ready = Signal(str, object)

    def __init__(self, app):
        super().__init__()
        self.app = app
        self.cfg = app.config
        self._build()
        self._update_ready.connect(self._handle_update)

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        style_scroll(scroll)
        scroll.setWidgetResizable(True)
        root.addWidget(scroll)

        body = QWidget()
        body.setObjectName("surface")
        body.setMinimumWidth(420)
        scroll.setWidget(body)
        bl = QVBoxLayout(body)
        bl.setContentsMargins(24, 18, 24, 18)
        bl.setSpacing(6)

        # ---- 外观 ----
        bl.addWidget(self._header("外观 Appearance"))
        grp = QFrame()
        grp.setObjectName("card")
        g = QVBoxLayout(grp)
        g.setContentsMargins(12, 8, 12, 8)

        r = QHBoxLayout()
        r.addWidget(QLabel("色彩主题"))
        self.combo_theme = QComboBox()
        self.combo_theme.addItems(["深色模式", "浅色模式", "跟随系统"])
        self.combo_theme.setCurrentText(
            self.cfg.config_repo.data.get("appearance_mode", "深色模式"))
        self.combo_theme.currentTextChanged.connect(self.on_theme_change)
        r.addStretch(1)
        r.addWidget(self.combo_theme)
        g.addLayout(r)

        r = QHBoxLayout()
        r.addWidget(QLabel("全局字体"))
        r.addStretch(1)
        btn_plus = make_button("A+", "secondary", lambda: self._change_font(1))
        r.addWidget(btn_plus)
        btn_minus = make_button("A-", "secondary", lambda: self._change_font(-1))
        r.addWidget(btn_minus)
        self.lbl_font = QLabel(self.cfg.config_repo.data.get("font_size_scale", "标准 (100%)"))
        self.lbl_font.setStyleSheet("color: %s;" % cfg_hex(self.cfg, "primary"))
        r.addWidget(self.lbl_font)
        g.addLayout(r)

        r = QHBoxLayout()
        r.addWidget(QLabel("主题颜色"))
        r.addStretch(1)
        for aid in ACCENT_IDS:
            selected = aid == self.cfg.accent_id
            btn = QPushButton(f"● {ACCENT_NAMES[aid]}")
            btn.setCheckable(True)
            btn.setChecked(selected)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda _=False, a=aid: self.on_accent_change(a))
            r.addWidget(btn)
        g.addLayout(r)
        bl.addWidget(grp)

        # ---- AI 接口 ----
        bl.addWidget(self._header("AI 接口配置 API"))
        grp = QFrame()
        grp.setObjectName("card")
        g = QVBoxLayout(grp)
        g.setContentsMargins(12, 8, 12, 8)
        self._key_edit = self._line(self.cfg.api_key, password=True, cb=self._save_api)
        g.addLayout(self._pair("API Key", self._key_edit))
        self._url_edit = self._line(self.cfg.api_url, cb=self._save_api)
        g.addLayout(self._pair("API URL", self._url_edit))
        self.combo_model = QComboBox()
        self.combo_model.addItems(_MODELS)
        self.combo_model.setCurrentText(self.cfg.model_name)
        self.combo_model.currentTextChanged.connect(self._save_api)
        g.addLayout(self._pair("模型", self.combo_model))
        self.combo_diff = QComboBox()
        self.combo_diff.addItems(_DIFFICULTIES)
        self.combo_diff.setCurrentText(self.cfg.difficulty)
        self.combo_diff.currentTextChanged.connect(self._save_api)
        g.addLayout(self._pair("难度", self.combo_diff))
        bl.addWidget(grp)

        # ---- 壁纸 ----
        bl.addWidget(self._header("全景毛玻璃壁纸 Frosted Wallpaper"))
        grp = QFrame()
        grp.setObjectName("card")
        g = QVBoxLayout(grp)
        g.setContentsMargins(12, 8, 12, 8)
        r = QHBoxLayout()
        r.addWidget(QLabel("壁纸图片"))
        r.addStretch(1)
        self.lbl_wp = QLabel(self._wp_name())
        self.lbl_wp.setStyleSheet("color: %s;" % cfg_hex(self.cfg, "primary"))
        r.addWidget(self.lbl_wp)
        btn_choose = make_button("选择图片…", "secondary", self.choose_wallpaper)
        r.addWidget(btn_choose)
        btn_clear = make_button("清除", "danger", self.clear_wallpaper)
        r.addWidget(btn_clear)
        g.addLayout(r)
        r = QHBoxLayout()
        r.addWidget(QLabel("磨砂程度"))
        self.lbl_blur = QLabel(f"{self.cfg.wallpaper_blur} px")
        r.addStretch(1)
        self.lbl_blur.setStyleSheet("color: %s;" % cfg_hex(self.cfg, "primary"))
        r.addWidget(self.lbl_blur)
        self.slider_blur = QSlider(Qt.Horizontal)
        self.slider_blur.setRange(0, 30)
        self.slider_blur.setValue(self.cfg.wallpaper_blur)
        self.slider_blur.valueChanged.connect(self.on_blur)
        r.addWidget(self.slider_blur)
        g.addLayout(r)
        r = QHBoxLayout()
        r.addWidget(QLabel("通透度"))
        self.lbl_opacity = QLabel(f"{int(self.cfg.wallpaper_opacity * 100)}%")
        r.addStretch(1)
        self.lbl_opacity.setStyleSheet("color: %s;" % cfg_hex(self.cfg, "primary"))
        r.addWidget(self.lbl_opacity)
        self.slider_opacity = QSlider(Qt.Horizontal)
        self.slider_opacity.setRange(10, 90)
        self.slider_opacity.setValue(int(self.cfg.wallpaper_opacity * 100))
        self.slider_opacity.valueChanged.connect(self.on_opacity)
        r.addWidget(self.slider_opacity)
        g.addLayout(r)
        bl.addWidget(grp)

        # ---- 微软 ----
        bl.addWidget(self._header("微软翻译与语音 Microsoft Azure"))
        grp = QFrame()
        grp.setObjectName("card")
        g = QVBoxLayout(grp)
        g.setContentsMargins(12, 8, 12, 8)
        r = QHBoxLayout()
        r.addWidget(QLabel("查词引擎"))
        self.combo_engine = QComboBox()
        self.combo_engine.addItems(["AI 智能模型", "微软必应翻译"])
        self.combo_engine.setCurrentText(self.cfg.translate_engine)
        self.combo_engine.currentTextChanged.connect(self.on_engine_change)
        r.addStretch(1)
        r.addWidget(self.combo_engine)
        g.addLayout(r)
        self._ms_key_edit = self._line(self.cfg.ms_translator_key, password=True,
                                       cb=self._save_ms)
        g.addLayout(self._pair("Translator Key", self._ms_key_edit))
        self._ms_region_edit = self._line(self.cfg.ms_translator_region, cb=self._save_ms)
        g.addLayout(self._pair("Translator Region", self._ms_region_edit))
        self._sp_key_edit = self._line(self.cfg.ms_speech_key, password=True,
                                       cb=self._save_ms)
        g.addLayout(self._pair("语音 API Key", self._sp_key_edit))
        self._sp_region_edit = self._line(self.cfg.ms_speech_region, cb=self._save_ms)
        g.addLayout(self._pair("语音 Region", self._sp_region_edit))
        r = QHBoxLayout()
        r.addWidget(QLabel("语音音色"))
        self.combo_voice = QComboBox()
        self.combo_voice.addItems(_VOICES)
        for i, v in enumerate(_VOICES):
            if v.split(" ")[0] == self.cfg.ms_voice_name:
                self.combo_voice.setCurrentIndex(i)
                break
        self.combo_voice.currentTextChanged.connect(self._save_ms)
        r.addStretch(1)
        btn_test = make_button("🔊 试听", "secondary", self.test_voice)
        r.addWidget(btn_test)
        r.addWidget(self.combo_voice)
        g.addLayout(r)
        bl.addWidget(grp)

        # ---- 更新/关于 ----
        bl.addWidget(self._header("关于与更新 About & Update"))
        grp = QFrame()
        grp.setObjectName("card")
        g = QVBoxLayout(grp)
        g.setContentsMargins(12, 8, 12, 8)
        r = QHBoxLayout()
        lbl_ver = QLabel(f"WordCrafter Pro · {CURRENT_VERSION}")
        r.addWidget(lbl_ver)
        r.addStretch(1)
        btn_github = make_button("🌐 GitHub", "ghost",
                                 lambda: webbrowser.open(
                                     f"https://github.com/WilliamAxte/WordCrafterPro_CET"))
        r.addWidget(btn_github)
        self.btn_update = make_button("⚡ 检查更新", "primary", self.check_update)
        r.addWidget(self.btn_update)
        g.addLayout(r)
        self.lbl_update = QLabel("")
        self.lbl_update.setObjectName("muted")
        g.addWidget(self.lbl_update)
        bl.addWidget(grp)

        bl.addStretch(1)

    # ---------------- 工具 ----------------
    def _header(self, text):
        lbl = QLabel(text)
        lbl.setStyleSheet("color: %s; font-size: 15px; font-weight: 600;"
                          % cfg_hex(self.cfg, "primary"))
        return lbl

    def _pair(self, label, widget):
        r = QHBoxLayout()
        r.addWidget(QLabel(label))
        r.addWidget(widget, 1)
        return r

    def _line(self, value, password=False, cb=None):
        e = QLineEdit(value)
        e.setClearButtonEnabled(True)
        if password:
            e.setEchoMode(QLineEdit.Password)
        if cb:
            e.textChanged.connect(cb)
        return e

    def _wp_name(self):
        p = self.cfg.wallpaper_path
        return os.path.basename(p) if p else "未设置壁纸"

    # ---------------- 外观行为 ----------------
    def on_theme_change(self, text):
        self.cfg.config_repo.save_all({"appearance_mode": text})
        self.app.relaunch()

    def on_accent_change(self, aid):
        if aid == self.cfg.accent_id:
            return
        self.cfg.apply_accent(aid)
        self.app.relaunch(f"已应用主题颜色 · {ACCENT_NAMES.get(aid, aid)}")

    def _change_font(self, delta):
        scales = _FONT_SCALES
        cur = self.cfg.config_repo.data.get("font_size_scale", "标准 (100%)")
        idx = scales.index(cur) if cur in scales else 1
        n = idx + delta
        if not 0 <= n < len(scales):
            return
        new_scale = scales[n]
        self.cfg.config_repo.save_all({"font_size_scale": new_scale})
        self.lbl_font.setText(new_scale)
        self.app.relaunch(f"全局字号已调整至 {new_scale}")

    # ---------------- API / 微软 ----------------
    def _save_api(self, *_):
        try:
            self.cfg.save_config(
                self._api_url_text(), self._api_key_text(),
                self.combo_model.currentText(), self.combo_diff.currentText())
        except Exception:
            pass

    def _api_url_text(self):
        return getattr(self, "_url_edit").text()

    def _api_key_text(self):
        return getattr(self, "_key_edit").text()

    def on_engine_change(self, text):
        self.cfg.config_repo.save_all({"translate_engine": text})

    def _save_ms(self, *_):
        try:
            self.cfg.config_repo.save_all({
                "ms_translator_key": self._ms_key_text(),
                "ms_translator_region": self._ms_region_text() or "global",
                "ms_speech_key": self._sp_key_text(),
                "ms_speech_region": self._sp_region_text() or "eastasia",
                "ms_voice_name": self.combo_voice.currentText().split(" ")[0],
            })
        except Exception:
            pass

    def _ms_key_text(self):
        return getattr(self, "_ms_key_edit").text()

    def _ms_region_text(self):
        return getattr(self, "_ms_region_edit").text()

    def _sp_key_text(self):
        return getattr(self, "_sp_key_edit").text()

    def _sp_region_text(self):
        return getattr(self, "_sp_region_edit").text()

    def test_voice(self):
        MicrosoftSpeechService.speak_async(
            "Serendipity and persist.",
            self._sp_key_text().strip(), self._sp_region_text().strip(),
            self.combo_voice.currentText().split(" ")[0])

    # ---------------- 壁纸 ----------------
    def choose_wallpaper(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "选择壁纸", "", "图片 (*.png *.jpg *.jpeg *.webp *.bmp)")
        if path:
            self.cfg.config_repo.save_all({"wallpaper_path": path})
            self.lbl_wp.setText(os.path.basename(path))
            self.app.apply_wallpaper()

    def clear_wallpaper(self):
        self.cfg.config_repo.save_all({"wallpaper_path": ""})
        self.lbl_wp.setText("未设置壁纸")
        self.app.apply_wallpaper()

    def on_blur(self, val):
        self.lbl_blur.setText(f"{val} px")
        self.cfg.config_repo.save_all({"wallpaper_blur": int(val)})
        self.app.apply_wallpaper()

    def on_opacity(self, val):
        v = round(val / 100.0, 2)
        self.lbl_opacity.setText(f"{int(v * 100)}%")
        self.cfg.config_repo.save_all({"wallpaper_opacity": v})
        self.app.apply_wallpaper()

    # ---------------- 更新 ----------------
    def check_update(self):
        self.btn_update.setEnabled(False)
        self.btn_update.setText("检查中…")
        self.lbl_update.setText("正在连接 GitHub…")

        def done(status, data):
            self._update_ready.emit(status, data)

        UpdateService.check_update_async(done)

    def _handle_update(self, status, data):
        self.btn_update.setEnabled(True)
        self.btn_update.setText("⚡ 检查更新")
        if status == "update_available":
            self.lbl_update.setText(f"发现新版本 {data.get('tag')}（当前 {CURRENT_VERSION}）")
            self.lbl_update.setStyleSheet("color: %s;" % cfg_hex(self.cfg, "primary"))
        elif status == "latest":
            self.lbl_update.setText(f"✓ 已是最新版本 {CURRENT_VERSION}")
            self.lbl_update.setStyleSheet("color: %s;" % cfg_hex(self.cfg, "success"))
        else:
            self.lbl_update.setText(f"✕ 检查更新失败：{data}")
            self.lbl_update.setStyleSheet("color: %s;" % cfg_hex(self.cfg, "error"))
