# ==============================================================================
# 文件路径: wordcrafter/qt/pages/reading_page.py
# 阅读模式（Qt，修复版）：
#   - 内容 Typography：默认 18px 可调（A−/A/A+，持久化 reading_font_size）
#   - 自动排版（ContentRenderer/DocumentView，默认开启，不改原文）
#   - 正文限宽居中（≤900px）
#   - 中英对照/仅英文/仅中文
#   - 沉浸阅读（独立全屏 Reader Mode，复用 DocumentView）
#   - 流式生成、右键查词/朗读、会话落库
# ==============================================================================
import threading

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtWidgets import (QButtonGroup, QCheckBox, QComboBox, QFileDialog,
                               QFrame, QHBoxLayout, QLabel, QLineEdit,
                               QPlainTextEdit, QStackedLayout, QStackedWidget,
                               QSizePolicy, QVBoxLayout, QWidget)

from ...services.ai import AIService, StreamRouter
from ..newspaper import NewspaperReader
from ..renderer import DocumentView
from ..typography import (DEFAULT_SIZE, get_saved_size, save_size, set_plain_font,
                          step_size)
from ..widgets import (ChunkSink, EmptyState, attach_text_menu, cfg_hex,
                       make_button, make_pill)

_SOURCES = [
    "🎙️ 名人经典演讲 (Steve Jobs, Churchill, MLK 等)",
    "📖 世界经典文学名著 (1984, Gatsby, Little Prince 等)",
    "🎬 经典影视/纪录片原声独白与剧本",
    "🪐 哲学与社科深度随笔选读",
]
_LENGTHS = ["短篇精选 (~200词)", "中篇节选 (~400词)", "长篇深度精读 (~600词)",
            "千字名篇节选 (~1000词)", "自定义字数"]
_CUSTOM = "自定义字数"
_DOTS = ["●○○", "○●○", "○○●"]
FONT_KEY = "reading_font_size"


class ReadingPage(QWidget):
    finished_ok = Signal(object)
    failed = Signal(str)

    def __init__(self, app):
        super().__init__()
        self.app = app
        self.cfg = app.config
        self.generating = False
        self._dots = 0
        self._en = ""
        self._zh = ""
        self.px = get_saved_size(self.cfg, FONT_KEY, DEFAULT_SIZE)
        self.autop = True
        self.view_mode = "dual"

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        self.stack = QStackedLayout()
        root.addLayout(self.stack, 1)

        self.empty = EmptyState(self.cfg, "📖", "开始一篇新的精读",
                                "在下方选择来源与篇目，获取原著 / 演讲的经典节选")
        self.stack.addWidget(self.empty)

        self._build_reader()
        self.stack.addWidget(self.reader)
        self.set_state("empty")

        self.finished_ok.connect(self._on_success)
        self.failed.connect(self._on_error)

    # ---------------- 阅读卡 ----------------
    def _build_reader(self):
        cfg = self.cfg
        self.reader = QFrame()
        self.reader.setObjectName("surface")
        self.reader.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        lay = QVBoxLayout(self.reader)
        lay.setContentsMargins(16, 12, 16, 12)
        lay.setSpacing(6)

        head = QHBoxLayout()
        self.lbl_title = QLabel("阅读素材")
        self.lbl_title.setStyleSheet("font-size: 16px; font-weight: 600;")
        head.addWidget(self.lbl_title)
        self.lbl_state = QLabel("")
        self.lbl_state.setObjectName("muted")
        head.addWidget(self.lbl_state)
        head.addStretch(1)
        bg = QButtonGroup(self)
        self._pills = {}
        for i, (key, text) in enumerate([("dual", "📖 双语对照"), ("en", "🔤 纯英文"),
                                         ("zh", "🇨🇳 仅看中文")]):
            pill = make_pill(text, checked=(key == "dual"))
            pill.clicked.connect(lambda _=False, k=key: self._set_view(k))
            bg.addButton(pill, i)
            self._pills[key] = pill
            head.addWidget(pill)
        lay.addLayout(head)

        # ---- 正文：大卡片（与单词/ACG 页一致，不再居中窄条） ----
        self.body_sw = QStackedWidget()
        self.body_sw.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        lay.addWidget(self.body_sw, 1)

        # 底稿页（流式期间逐字显示）
        self.plain_box = QWidget()
        pb = QVBoxLayout(self.plain_box)
        pb.setContentsMargins(0, 0, 0, 0)
        pb.setSpacing(6)
        self.txt_en = QPlainTextEdit()
        self.txt_zh = QPlainTextEdit()
        for e in (self.txt_en, self.txt_zh):
            e.setReadOnly(True)
            e.setLineWrapMode(QPlainTextEdit.WidgetWidth)
            e.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            attach_text_menu(e, cfg, self.app)
        set_plain_font(self.txt_en, self.px)
        set_plain_font(self.txt_zh, self.px)
        pb.addWidget(self.txt_en, 1)
        pb.addWidget(self.txt_zh, 1)
        self.body_sw.addWidget(self.plain_box)

        # 自动排版视图
        self.doc = DocumentView(cfg)
        self.doc.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.body_sw.addWidget(self.doc)

        # ---- 工具行 ----
        tools = QHBoxLayout()
        tools.setSpacing(6)

        def _apply_font(px):
            self.px = px
            save_size(cfg, FONT_KEY, px)
            set_plain_font(self.txt_en, px)
            set_plain_font(self.txt_zh, px)
            if self.autop:
                self._refresh_rendered()

        btn_imm = make_button("📖 沉浸阅读", "primary", self.open_immersion)
        tools.addWidget(btn_imm)

        btn_fm = make_button("A−", "ghost", lambda: _apply_font(
            step_size(cfg, FONT_KEY, self.px, -1)))
        tools.addWidget(btn_fm)
        self.lbl_font = QLabel(f"{self.px}px")
        self.lbl_font.setObjectName("muted")
        tools.addWidget(self.lbl_font)
        btn_fp = make_button("A+", "ghost", lambda: _apply_font(
            step_size(cfg, FONT_KEY, self.px, 1)))
        tools.addWidget(btn_fp)

        self.chk_autop = QCheckBox("自动排版")
        self.chk_autop.setChecked(self.autop)
        self.chk_autop.toggled.connect(self._toggle_autop)
        tools.addWidget(self.chk_autop)

        btn_export = make_button("📤 导出", "ghost", self.export_article)
        tools.addWidget(btn_export)
        tools.addStretch(1)
        lay.addLayout(tools)

    # ---------------- 视图 ----------------
    def _set_view(self, key):
        self.view_mode = key
        for k, p in self._pills.items():
            p.setChecked(k == key)
        if self.autop and (self._en or self._zh):
            self._refresh_rendered()
        else:
            self.txt_en.setVisible(key in ("dual", "en"))
            self.txt_zh.setVisible(key in ("dual", "zh"))

    def _toggle_autop(self, on):
        self.autop = on
        self._rebuild_body()

    def _rebuild_body(self):
        if self.autop and (self._en or self._zh):
            self.body_sw.setCurrentWidget(self.doc)
            self._refresh_rendered()
        else:
            self.body_sw.setCurrentWidget(self.plain_box)
            self._set_view(self.view_mode)

    def _refresh_rendered(self):
        mode = "dual" if self.view_mode == "dual" else (
            "en" if self.view_mode == "en" else "zh")
        from ..theme import is_light_mode
        theme = "light" if is_light_mode(self.cfg) else "dark"
        self.doc.set_content(self._en, self._zh)
        self.doc.apply_typography(px=self.px, mode=mode, theme=theme)

    # ---------------- 状态 ----------------
    def set_state(self, state):
        if state == "generating":
            self.generating = True
            self._dots = 0
            self.lbl_state.setText("生成中 " + _DOTS[0])
            self.stack.setCurrentWidget(self.reader)
            self.body_sw.setCurrentWidget(self.plain_box)
            self._spin()
        elif state == "content":
            self.generating = False
            self.lbl_state.setText("")
            self.stack.setCurrentWidget(self.reader)
            self._rebuild_body()
        else:
            self.generating = False
            self.lbl_state.setText("")
            self.stack.setCurrentWidget(self.empty)

    def _spin(self):
        if not self.generating:
            return
        self.lbl_state.setText("生成中 " + _DOTS[self._dots % 3])
        self._dots += 1
        QTimer.singleShot(160, self._spin)

    # ---------------- 导出 / 沉浸 ----------------
    def export_article(self):
        en = self._en or self.txt_en.toPlainText().strip()
        zh = self._zh or self.txt_zh.toPlainText().strip()
        if not en and not zh:
            self.app.toasts.show("当前无内容", kind="info")
            return
        path, _ = QFileDialog.getSaveFileName(self, "导出名篇", "reading.txt",
                                              "Text Files (*.txt)")
        if not path:
            return
        with open(path, "w", encoding="utf-8") as f:
            f.write(f"=== Authentic English Reading ===\n\n{en}\n\n"
                    f"=== Chinese Translation ===\n\n{zh}\n")
        self.app.toasts.show("名篇已保存", kind="success")

    def open_immersion(self):
        en = self._en or self.txt_en.toPlainText().strip()
        zh = self._zh or self.txt_zh.toPlainText().strip()
        if not en and not zh:
            self.app.toasts.show("当前无内容", kind="info")
            return
        reader = NewspaperReader(self.cfg, "经典名篇精读", en, zh)
        reader.show()

    # ---------------- 底部 ContextActionBar ----------------
    def build_context_bar(self, container):
        cfg = self.cfg
        bar = QFrame(container)
        bar.setObjectName("bar")
        row = QHBoxLayout(bar)
        row.setContentsMargins(14, 8, 14, 8)
        row.setSpacing(8)

        row.addWidget(QLabel("来源"))
        self.combo_source = QComboBox()
        self.combo_source.addItems(_SOURCES)
        row.addWidget(self.combo_source)

        row.addWidget(QLabel("篇目/演讲者"))
        self.edit_work = QLineEdit()
        self.edit_work.setPlaceholderText("例如：Steve Jobs Stanford Speech / 乔布斯斯坦福演讲")
        self.edit_work.setClearButtonEnabled(True)
        row.addWidget(self.edit_work, 1)

        row.addWidget(QLabel("篇幅"))
        self.combo_len = QComboBox()
        self.combo_len.addItems(_LENGTHS)
        self.combo_len.currentTextChanged.connect(self._on_len_change)
        row.addWidget(self.combo_len)

        self.edit_custom_len = QLineEdit("1000")
        self.edit_custom_len.setFixedWidth(64)
        self.edit_custom_len.hide()
        row.addWidget(self.edit_custom_len)

        self.lbl_status = QLabel("")
        self.lbl_status.setObjectName("muted")
        row.addWidget(self.lbl_status)

        self.btn_generate = make_button("🚀 获取名篇", "primary", self.start_generation)
        row.addWidget(self.btn_generate)

        vbox = container.layout()
        if vbox is None:
            vbox = QVBoxLayout(container)
            vbox.setContentsMargins(0, 0, 0, 0)
        vbox.addWidget(bar)

    def _on_len_change(self, text):
        self.edit_custom_len.setVisible(_CUSTOM in text)

    # ---------------- 生成 ----------------
    def start_generation(self):
        if self.generating:
            return
        work = self.edit_work.text().strip()
        if not work:
            self._status("请输入篇目/演讲者", "error")
            return
        len_mode = self.combo_len.currentText()
        target_len = f"{self.edit_custom_len.text().strip()} 词左右" if _CUSTOM in len_mode else len_mode

        self._en = ""
        self._zh = ""
        self.txt_en.clear()
        self.txt_zh.clear()
        self.btn_generate.setEnabled(False)
        self.set_state("generating")
        self._status("正在获取…", None)

        sink_en = ChunkSink(self)
        sink_zh = ChunkSink(self)
        sink_en.chunk.connect(self._append_en)
        sink_zh.chunk.connect(self._append_zh)
        threading.Thread(target=self._worker,
                         args=(self.combo_source.currentText(), work, target_len,
                               sink_en, sink_zh),
                         daemon=True).start()

    def _append_en(self, t):
        from ..widgets import append_text
        self._en += t
        append_text(self.txt_en, t)

    def _append_zh(self, t):
        from ..widgets import append_text
        self._zh += t
        append_text(self.txt_zh, t)

    def _worker(self, source_type, work, target_len, sink_en, sink_zh):
        cfg = self.cfg
        router = StreamRouter(sink_en, sink_zh)
        try:
            AIService.fetch_authentic_reading_stream(
                source_type, work, target_len,
                cfg.difficulty, cfg.api_key, cfg.api_url, cfg.model_name, router.feed)
            router.close()
            self.finished_ok.emit({"work": work, "length": target_len})
        except Exception as exc:
            self.failed.emit(str(exc))

    def _on_success(self, meta):
        self.generating = False
        self.btn_generate.setEnabled(True)
        self._status("✓ 获取完成 · 可自动排版 / 沉浸阅读", "success")
        self.set_state("content")
        try:
            en = (self._en or "").strip()
            self.app.add_session(
                "reading", meta["work"][:40],
                summary=en[:120].replace("\n", " "),
                meta={"source": self.combo_source.currentText(),
                      "work": meta["work"],
                      "length": meta["length"]},
                content={"en": en, "zh": (self._zh or "").strip()})
        except Exception:
            pass

    def restore_session(self, session):
        """从历史记录恢复：跳回本页并还原上次生成内容（不重新生成）。"""
        content = session.get("content") or {}
        en = (content.get("en") or "").strip()
        zh = (content.get("zh") or "").strip()
        if not en and not zh:
            return False
        self._en = en
        self._zh = zh
        self.txt_en.setPlainText(en)
        self.txt_zh.setPlainText(zh)
        params = session.get("parameters") or {}
        work = params.get("work") or session.get("title", "")
        if work and hasattr(self, "edit_work"):
            self.edit_work.setText(work)
        src = params.get("source")
        if src and hasattr(self, "combo_source"):
            for i in range(self.combo_source.count()):
                if src in self.combo_source.itemText(i):
                    self.combo_source.setCurrentIndex(i)
                    break
        self.set_state("content")
        return True

    def _on_error(self, err):
        self.generating = False
        self.btn_generate.setEnabled(True)
        self._status(f"✕ 获取失败：{err}", "error")
        self.set_state("content")
        self.app.toasts.show(f"获取失败：{err}", kind="error")

    def _status(self, text, tone):
        color = {"success": cfg_hex(self.cfg, "success"),
                 "error": cfg_hex(self.cfg, "error")}.get(tone)
        self.lbl_status.setText(text)
        self.lbl_status.setStyleSheet(f"color: {color};" if color else "")
