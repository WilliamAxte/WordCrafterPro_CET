# ==============================================================================
# 文件路径: wordcrafter/qt/vocab_dialog.py
# 生词库管理窗（Qt）：搜索 · 分页 · 异步释义卡(统一查词) · 朗读/删除 · 导入导出 TXT
# ==============================================================================
import threading

from PySide6.QtCore import QObject, Qt, Signal
from PySide6.QtWidgets import (QDialog, QFileDialog, QFrame, QHBoxLayout,
                               QLabel, QLineEdit, QMessageBox, QScrollArea,
                               QVBoxLayout, QWidget)

from ..core.text_utils import parse_words, read_text_any_encoding
from ..services.definitions import DictionaryService
from ..services.microsoft import MicrosoftSpeechService
from .widgets import cfg_hex, make_button, style_scroll

PAGE_SIZE = 20


class _LookupWorker(QObject):
    """单行异步查词（后台线程 → 主线程信号）。"""

    done = Signal(object)

    def start(self, word, cfg):
        def _run():
            try:
                entry, layer = DictionaryService.lookup_sync(word, cfg)
                if layer == "online":
                    try:
                        cfg.vocab_repo.cache[word] = entry
                        cfg.vocab_repo.save_cache()
                    except Exception:
                        pass
            except Exception:
                entry = None
            self.done.emit(entry or {})

        threading.Thread(target=_run, daemon=True).start()


class _WordRow(QFrame):
    def __init__(self, dialog, word, index):
        super().__init__()
        self.dialog = dialog
        self.cfg = dialog.cfg
        self.word = word
        self.setObjectName("card")

        lay = QHBoxLayout(self)
        lay.setContentsMargins(14, 8, 14, 8)
        lay.setSpacing(10)

        info = QVBoxLayout()
        info.setSpacing(2)
        head = QHBoxLayout()
        head.setSpacing(8)
        idx = QLabel(str(index))
        idx.setObjectName("muted")
        head.addWidget(idx)
        wl = QLabel(word)
        wl.setStyleSheet("font-size: 15px; font-weight: 600; color: %s;"
                         % cfg_hex(self.cfg, "primary"))
        head.addWidget(wl)
        self.lbl_phonetic = QLabel("解析中…")
        self.lbl_phonetic.setObjectName("muted")
        head.addWidget(self.lbl_phonetic)
        head.addStretch(1)
        from .widgets import make_emoji_icon
        btn_voice = make_emoji_icon("🔊", self.play_voice, tip="播放发音", size=34)
        self.btn_voice = btn_voice
        head.addWidget(btn_voice)
        btn_del = make_button("✕", "danger", self.delete_self)
        btn_del.setFixedSize(26, 26)
        head.addWidget(btn_del)
        info.addLayout(head)

        self.lbl_meaning = QLabel("正在调用词典解析释义…")
        self.lbl_meaning.setWordWrap(True)
        info.addWidget(self.lbl_meaning)
        lay.addLayout(info)

        # 缓存命中直接显示
        cached = self.cfg.vocab_repo.cache.get(word)
        if cached and cached.get("pos_def") and "暂未获取" not in cached.get("pos_def"):
            self.apply(cached)
            return
        worker = _LookupWorker()
        worker.done.connect(self.apply)
        worker.start(word, self.cfg)

    def apply(self, entry):
        entry = entry or {}
        self.lbl_phonetic.setText(entry.get("phonetic", ""))
        meaning = entry.get("pos_def", "暂无中文释义").replace("\n", "   ·   ")
        self.lbl_meaning.setText(meaning)

    def play_voice(self):
        from ..services.pronunciation import PronunciationService
        PronunciationService.play(self.word, self.cfg)

    def delete_self(self):
        self.dialog.delete_word(self.word)


class VocabManagerDialog(QDialog):
    """生词库管理窗口。"""

    def __init__(self, app):
        super().__init__(app)
        self.app = app
        self.cfg = app.config
        self.page = 1
        self.filtered = []

        self.setWindowTitle("本地生词库")
        self.resize(860, 680)
        self.setMinimumSize(720, 520)

        root = QVBoxLayout(self)
        root.setContentsMargins(14, 12, 14, 12)
        root.setSpacing(8)

        # 顶部：统计 + 搜索
        top = QHBoxLayout()
        self.lbl_stats = QLabel("")
        top.addWidget(self.lbl_stats)
        top.addStretch(1)
        self.edit_search = QLineEdit()
        self.edit_search.setPlaceholderText("🔍 搜索生词…")
        self.edit_search.setFixedWidth(200)
        self.edit_search.textChanged.connect(self.on_search)
        top.addWidget(self.edit_search)
        root.addLayout(top)

        # 列表
        scroll = QScrollArea()
        style_scroll(scroll)
        scroll.setWidgetResizable(True)
        root.addWidget(scroll, 1)
        self.list_host = QWidget()
        self.list_layout = QVBoxLayout(self.list_host)
        self.list_layout.setContentsMargins(0, 0, 0, 0)
        self.list_layout.setSpacing(4)
        self.list_layout.addStretch(1)
        scroll.setWidget(self.list_host)

        # 分页
        page_row = QHBoxLayout()
        self.btn_prev = make_button("◀ 上一页", "secondary", self.prev_page)
        page_row.addWidget(self.btn_prev)
        self.lbl_page = QLabel("第 1 / 1 页")
        self.lbl_page.setObjectName("muted")
        page_row.addWidget(self.lbl_page)
        self.btn_next = make_button("下一页 ▶", "secondary", self.next_page)
        page_row.addWidget(self.btn_next)
        page_row.addStretch(1)
        root.addLayout(page_row)

        # 底部操作
        bottom = QHBoxLayout()
        btn_export = make_button("导出 TXT", "secondary", self.export_vocab)
        bottom.addWidget(btn_export)
        btn_import = make_button("导入 TXT", "secondary", self.import_vocab)
        bottom.addWidget(btn_import)
        btn_clear = make_button("清空生词", "danger", self.clear_vocab)
        bottom.addWidget(btn_clear)
        bottom.addStretch(1)
        btn_done = make_button("完成", "primary", self.accept)
        bottom.addWidget(btn_done)
        root.addLayout(bottom)

        self.refresh()

    # ---------------- 数据 ----------------
    def refresh(self):
        words = self.cfg.vocab_history
        kw = self.edit_search.text().strip().lower()
        self.filtered = [w for w in words if kw in w.lower()] if kw else list(words)
        total_words, total_letters = self.cfg.vocab_repo.get_stats()
        self.lbl_stats.setText(f"生词库 · {total_words} 词 ({total_letters} 字母)")
        self.render()

    def on_search(self, *_):
        self.page = 1
        self.refresh()

    def render(self):
        # 清空（保留 stretch）
        while self.list_layout.count() > 1:
            item = self.list_layout.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()
        total = len(self.filtered)
        pages = max(1, (total + PAGE_SIZE - 1) // PAGE_SIZE)
        self.page = max(1, min(self.page, pages))
        self.lbl_page.setText(f"第 {self.page} / {pages} 页 (共 {total} 词)")
        self.btn_prev.setEnabled(self.page > 1)
        self.btn_next.setEnabled(self.page < pages)
        if not self.filtered:
            empty = QLabel("📭 词库暂无匹配生词")
            empty.setObjectName("muted")
            empty.setAlignment(Qt.AlignCenter)
            empty.setMinimumHeight(140)
            self.list_layout.insertWidget(0, empty)
            return
        start = (self.page - 1) * PAGE_SIZE
        for i, word in enumerate(self.filtered[start:start + PAGE_SIZE]):
            self.list_layout.insertWidget(i, _WordRow(self, word, start + i + 1))

    def prev_page(self):
        if self.page > 1:
            self.page -= 1
            self.render()

    def next_page(self):
        pages = max(1, (len(self.filtered) + PAGE_SIZE - 1) // PAGE_SIZE)
        if self.page < pages:
            self.page += 1
            self.render()

    def delete_word(self, word):
        self.cfg.vocab_repo.remove_word(word)
        if hasattr(self.app, "update_global_vocab_status"):
            self.app.update_global_vocab_status()
        self.refresh()

    # ---------------- 导入导出 ----------------
    def export_vocab(self):
        words = self.cfg.vocab_history
        if not words:
            self._toast("词库暂无词汇")
            return
        path, _ = QFileDialog.getSaveFileName(self, "导出生词", "vocab.txt",
                                              "Text Files (*.txt)")
        if not path:
            return
        with open(path, "w", encoding="utf-8") as f:
            f.write(", ".join(words))
        self._toast(f"已导出 {len(words)} 个单词")

    def import_vocab(self):
        path, _ = QFileDialog.getOpenFileName(self, "导入 TXT", "",
                                              "Text Files (*.txt)")
        if not path:
            return
        content, ok = read_text_any_encoding(path)
        if not ok:
            self._toast("编码不支持", error=True)
            return
        cnt = self.cfg.vocab_repo.add_words(parse_words(content))
        if hasattr(self.app, "update_global_vocab_status"):
            self.app.update_global_vocab_status()
        self.refresh()
        self._toast(f"已导入 {cnt} 个新词汇")

    def clear_vocab(self):
        if QMessageBox.question(self, "确认", "确定清空本地所有生词吗？") == QMessageBox.Yes:
            self.cfg.vocab_repo.clear_history()
            if hasattr(self.app, "update_global_vocab_status"):
                self.app.update_global_vocab_status()
            self.refresh()

    def _toast(self, message, error=False):
        if hasattr(self.app, "toasts"):
            self.app.toasts.show(message, kind="error" if error else "success")
