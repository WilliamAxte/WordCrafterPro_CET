# ==============================================================================
# 文件路径: wordcrafter/qt/chrome.py
# Qt 主框架（v3）：
#   Sidebar（文件夹 + 拖宽 + 折叠动画 + 宽度持久化 + 右键管理/导出）
#   · TopModeBar · Workspace(QStackedWidget) · ContextActionArea · 壁纸/毛玻璃背景
# 页面与业务逻辑保持：add_session 落全量内容、open_session 真恢复、relaunch 换肤
# ==============================================================================
import os

from PySide6.QtCore import QEasingCurve, QPropertyAnimation, Qt, QTimer
from PySide6.QtGui import QCursor, QColor, QIcon, QPixmap
from PySide6.QtWidgets import (QFileDialog, QFrame, QGraphicsBlurEffect,
                               QGraphicsOpacityEffect, QHBoxLayout, QInputDialog,
                               QLabel, QLineEdit, QListWidget, QListWidgetItem,
                               QMainWindow, QMenu, QMessageBox, QStackedWidget,
                               QVBoxLayout, QWidget)

from ..core.deck import DailyLogs, DeckRepository
from ..core.folders import FolderRepository
from ..core.session import SessionRepository
from ..core.study import StudyRepository
from .backdrop import BackdropManager
from .context import QtConfig
from .theme import is_light_mode, qss
from ..resources import asset
from .widgets import ToastHost, make_button, make_image_icon_button, make_wifi_button, make_pill
from .pages.acg_page import AcgPage
from .pages.dictionary_page import DictionaryPage
from .pages.reading_page import ReadingPage
from .pages.settings_page import SettingsPage
from .pages.study_page import StudyPage
from .pages.vocab_page import VocabPage

IMPLEMENTED = [
    ("vocab", "单词"), ("study", "记单词"), ("reading", "阅读"),
    ("acg", "ACG"), ("dictionary", "词典"), ("settings", "设置"),
]

_KIND_ICON = {"vocab": "📝", "study": "🧠", "reading": "📖", "acg": "🎬",
              "dictionary": "📚", "settings": "⚙️"}
KIND_LABEL = {"vocab": "单词", "study": "记单词", "reading": "阅读",
              "acg": "ACG", "dictionary": "词典", "settings": "设置"}

SIDEBAR_MIN = 60
SIDEBAR_MAX = 440
SIDEBAR_DEFAULT = 236


class _ResizeHandle(QFrame):
    """Sidebar 右缘拖宽手柄（即时跟随，无动画）。"""

    def __init__(self, sidebar):
        super().__init__()
        self.sidebar = sidebar
        self.setFixedWidth(5)
        self.setCursor(QCursor(Qt.SplitHCursor))
        self.setMouseTracking(True)

    def mousePressEvent(self, event):
        self._drag_x = event.globalPosition().x()
        self._drag_w = self.sidebar.width()
        event.accept()

    def mouseMoveEvent(self, event):
        if getattr(self, "_drag_x", None) is None:
            return
        delta = int(event.globalPosition().x() - self._drag_x)
        self.sidebar.set_user_width(self._drag_w + delta)
        event.accept()

    def mouseReleaseEvent(self, event):
        self.sidebar.persist_width()
        self._drag_x = None
        event.accept()


class Sidebar(QFrame):
    """左侧导航：品牌/新建/搜索/文件夹+历史（可拖宽、可折叠、可持久化）。"""

    def __init__(self, app):
        super().__init__()
        self.app = app
        self.cfg = app.config
        self.sessions = SessionRepository()
        self.folders = app.folders
        self.is_collapsed = False
        self._anim = None
        self._anim2 = None
        self.setObjectName("surface")
        self.setFixedWidth(SIDEBAR_DEFAULT)

        self._collapsed_folder_ids = set()
        self._q = None

        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 12, 10, 10)
        lay.setSpacing(6)

        brand_row = QHBoxLayout()
        self.lbl_brand = QLabel("WordCrafter")
        self.lbl_brand.setObjectName("brand")
        brand_row.addWidget(self.lbl_brand)
        brand_row.addStretch(1)
        self.btn_collapse = make_button("◧", "ghost", self.toggle, self)
        self.btn_collapse.setObjectName("sidebarToggle")
        self.btn_collapse.setFixedSize(26, 26)
        self.btn_collapse.setToolTip("收起侧边栏")
        brand_row.addWidget(self.btn_collapse)
        lay.addLayout(brand_row)

        self.btn_new = make_button("＋  新建", "primary", app.on_new_task, self)
        self.btn_new.setFixedHeight(34)
        lay.addWidget(self.btn_new)

        self.edit_search = QLineEdit()
        self.edit_search.setPlaceholderText("🔍 搜索历史")
        self.edit_search.textChanged.connect(self.refresh)
        lay.addWidget(self.edit_search)

        self.btn_add_folder = make_button("＋ 新建文件夹", "ghost",
                                          self.new_folder, self)
        lay.addWidget(self.btn_add_folder)

        self.list_history = QListWidget()
        self.list_history.setContextMenuPolicy(Qt.CustomContextMenu)
        self.list_history.customContextMenuRequested.connect(self._menu)
        self.list_history.itemActivated.connect(self._activate)
        lay.addWidget(self.list_history, 1)

        from ..services.updater import CURRENT_VERSION
        self.lbl_version = QLabel(f"WordCrafter Pro · {CURRENT_VERSION}")
        self.lbl_version.setObjectName("muted")
        lay.addWidget(self.lbl_version)

        self._restore_width()
        self.refresh()

    # ---------------- 宽度（拖拽/折叠/持久化） ----------------
    def set_user_width(self, w):
        w = max(SIDEBAR_MIN, min(SIDEBAR_MAX, int(w)))
        self.is_collapsed = w <= SIDEBAR_MIN + 4
        self.setFixedWidth(w)
        if self.is_collapsed:
            self._apply_collapse_ui(True)
        elif getattr(self, "_was_collapsed", False):
            self._apply_collapse_ui(False)

    def persist_width(self):
        try:
            self.cfg.config_repo.save_all({"sidebar_width": self.width()})
        except Exception:
            pass

    def _restore_width(self):
        try:
            w = int(self.cfg.config_repo.data.get("sidebar_width", SIDEBAR_DEFAULT))
        except Exception:
            w = SIDEBAR_DEFAULT
        w = max(SIDEBAR_MIN, min(SIDEBAR_MAX, w))
        self.is_collapsed = w <= SIDEBAR_MIN + 4
        self.setFixedWidth(w)
        self._apply_collapse_ui(self.is_collapsed)

    def toggle(self):
        if self._anim is not None:
            return
        if not self.is_collapsed:
            self._was_collapsed = True
            target = SIDEBAR_MIN
        else:
            target = self._expanded_width()
            self._was_collapsed = False
        self.is_collapsed = not self.is_collapsed
        start = self.width()
        self._anim = QPropertyAnimation(self, b"maximumWidth", self)
        self._anim.setDuration(200)
        self._anim.setStartValue(start)
        self._anim.setEndValue(target)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        anim2 = QPropertyAnimation(self, b"minimumWidth", self)
        anim2.setDuration(200)
        anim2.setStartValue(start)
        anim2.setEndValue(target)
        anim2.setEasingCurve(QEasingCurve.OutCubic)
        self._anim2 = anim2
        anim2.finished.connect(self._anim_done)
        self._anim.start()
        anim2.start()

    def _anim_done(self):
        self.setFixedWidth(self.width())
        self._anim = None
        self._apply_collapse_ui(self.is_collapsed)
        if not self.is_collapsed:
            self.persist_width()

    def _expanded_width(self):
        try:
            w = int(self.cfg.config_repo.data.get("sidebar_width", SIDEBAR_DEFAULT))
        except Exception:
            w = SIDEBAR_DEFAULT
        return max(SIDEBAR_MIN + 8, min(SIDEBAR_MAX, w))

    def _apply_collapse_ui(self, collapsed):
        show = not collapsed
        self.lbl_brand.setText("WordCrafter" if show else "WC")
        self.edit_search.setVisible(show)
        self.btn_add_folder.setVisible(show)
        self.list_history.setVisible(show)
        self.btn_new.setText("＋  新建" if show else "＋")
        self.btn_collapse.setText("◧")
        self.btn_collapse.setToolTip("展开侧边栏" if collapsed else "收起侧边栏")

    # ---------------- 文件夹 ----------------
    def new_folder(self):
        name, ok = QInputDialog.getText(self, "新建文件夹", "文件夹名称：")
        if ok and name.strip():
            self.folders.create(name.strip())
            self.refresh()

    def rename_folder(self, fid):
        f = self.folders.get(fid)
        if not f:
            return
        name, ok = QInputDialog.getText(self, "重命名文件夹", "名称：",
                                        text=f["name"])
        if ok and name.strip():
            self.folders.rename(fid, name.strip())
            self.refresh()

    def delete_folder(self, fid):
        f = self.folders.get(fid)
        if not f:
            return
        if QMessageBox.question(self, "删除文件夹",
                                f"删除「{f['name']}」？其中历史记录将移回未归档（内容保留）。") != QMessageBox.Yes:
            return
        removed = self.folders.delete(fid)
        for s in self.sessions.sessions:
            if s.get("folder_id") in removed:
                s["folder_id"] = None
        self.sessions._save()
        self.refresh()

    # ---------------- 列表渲染 ----------------
    def refresh(self, *_):
        self.list_history.clear()
        q = (self.edit_search.text().strip() or "").lower() if self.edit_search.text() else ""
        self._collapsed_folder_ids = getattr(self, "_collapsed_folder_ids", set())
        by_folder = {}
        for s in self.sessions.sessions:
            if q and q not in (s.get("title", "") + s.get("summary", "")).lower():
                continue
            by_folder.setdefault(s.get("folder_id"), []).append(s)

        folders = sorted(self.folders.list_all(), key=lambda f: f.get("sort_index", 0))
        root_items = by_folder.get(None, [])
        for fid, f in {x["id"]: x for x in folders}.items():
            children = by_folder.get(fid, [])
            it = QListWidgetItem(
                ("▶ " if fid not in self._collapsed_folder_ids else "▶ ") +
                f"📁 {f['name']}  ({len(children)})")
            it.setData(Qt.UserRole, {"type": "folder", "id": fid})
            it.setFlags(Qt.ItemIsEnabled)
            self.list_history.addItem(it)
            if fid not in self._collapsed_folder_ids:
                for s in sorted(children, key=lambda x: x.get("created_at", 0),
                                reverse=True):
                    self._session_item(s)
        if root_items or True:
            if root_items:
                sec = QListWidgetItem("未归档")
                sec.setFlags(Qt.NoItemFlags)
                sec.setForeground(Qt.gray)
                self.list_history.addItem(sec)
                for s in sorted(root_items, key=lambda x: x.get("created_at", 0),
                                reverse=True):
                    self._session_item(s)

    def _session_item(self, s):
        icon = _KIND_ICON.get(s.get("kind", ""), "•")
        star = "★ " if s.get("favorite") else ""
        it = QListWidgetItem(f"{icon} {star}{s.get('title', '')}")
        it.setData(Qt.UserRole, {"type": "session", "id": s["id"], "session": s})
        self.list_history.addItem(it)

    # ---------------- 交互 ----------------
    def add_session_entry(self, kind, title, summary="", meta=None, content=None):
        item = self.sessions.add(kind, title, summary=summary, meta=meta, content=content)
        pending = getattr(self.app, "_pending_folder", None)
        if pending:
            self.sessions.move_to_folder(item["id"], pending)
            self.app._pending_folder = None
        self.refresh()
        return item

    def _activate(self, item):
        data = item.data(Qt.UserRole)
        if not data:
            return
        if data.get("type") == "session":
            self.app.open_session(data["session"])
        elif data.get("type") == "folder":
            self._toggle_folder(data["id"])

    def _toggle_folder(self, fid):
        ids = getattr(self, "_collapsed_folder_ids", set())
        if fid in ids:
            ids.discard(fid)
        else:
            ids.add(fid)
        self._collapsed_folder_ids = ids
        self.refresh()

    def _menu(self, pos):
        item = self.list_history.itemAt(pos)
        if item is None:
            return
        data = item.data(Qt.UserRole)
        menu = QMenu(self)
        if not data:
            menu.addAction("新建文件夹", self.new_folder)
        elif data.get("type") == "folder":
            fid = data["id"]
            f = self.folders.get(fid)
            if f:
                menu.addAction("新建项目", lambda: self._new_in_folder(fid))
                menu.addAction("重命名", lambda: self.rename_folder(fid))
                menu.addAction("删除", lambda: self.delete_folder(fid))
        elif data.get("type") == "session":
            s = data["session"]
            menu.addAction("打开", lambda: self.app.open_session(s))
            fav = "取消收藏" if s.get("favorite") else "★ 收藏"
            menu.addAction(fav, lambda: (
                self.sessions.toggle_favorite(s["id"]), self.refresh()))
            menu.addAction("重命名…", lambda: self._rename(s))
            mv = menu.addMenu("移动到文件夹")
            mv.addAction("未归档", lambda: self._move(s, None))
            for f in self.folders.list_all():
                mv.addAction(f["name"], lambda fid=f["id"], ss=s: self._move(ss, fid))
            ex = menu.addMenu("导出…")
            ex.addAction("TXT", lambda: self._export(s, "txt"))
            ex.addAction("Markdown", lambda: self._export(s, "md"))
            menu.addAction("删除…", lambda: self._delete(s))
        menu.exec(self.list_history.viewport().mapToGlobal(pos))

    def _new_in_folder(self, fid):
        kinds = [(k, KIND_LABEL.get(k, k)) for k in ("vocab", "reading", "acg")]
        m = QMenu(self)
        for k, label in kinds:
            m.addAction(label, lambda kk=k: self._begin_in_folder(fid, kk))
        m.exec(QCursor.pos())

    def _begin_in_folder(self, fid, kind):
        self.app._pending_folder = fid
        self.app.switch_mode(kind)
        self.app.toasts.show("生成内容将自动保存到该文件夹", kind="info")

    def _move(self, s, folder_id):
        self.sessions.move_to_folder(s["id"], folder_id)
        self.refresh()

    def _rename(self, s):
        new_title, ok = QInputDialog.getText(self, "重命名历史", "新的标题：",
                                             text=s.get("title", ""))
        if ok and new_title.strip():
            self.sessions.rename(s["id"], new_title.strip())
            self.refresh()

    def _delete(self, s):
        if QMessageBox.question(self, "删除历史",
                                f"确认删除「{s.get('title', '')}」？此操作不可恢复。") != QMessageBox.Yes:
            return
        self.sessions.delete(s["id"])
        self.refresh()

    def _export(self, s, fmt):
        default = f"{s.get('id', 'history')}.{'md' if fmt == 'md' else 'txt'}"
        path, _ = QFileDialog.getSaveFileName(self, "导出历史", default,
                                              "Markdown (*.md)" if fmt == "md"
                                              else "Text Files (*.txt)")
        if not path:
            return
        try:
            self.sessions.export_session(s["id"], path, fmt)
            self.app.toasts.show("已导出", kind="success")
        except Exception as exc:
            self.app.toasts.show(f"导出失败：{exc}", kind="error")


class TopModeBar(QFrame):
    def __init__(self, modes, active_id, on_mode):
        super().__init__()
        lay = QHBoxLayout(self)
        lay.setContentsMargins(2, 2, 2, 2)
        lay.setSpacing(4)
        self._pills = {}
        for mid, label in modes:
            pill = make_pill(label, checked=(mid == active_id))
            pill.clicked.connect(lambda _=False, m=mid: on_mode(m))
            self._pills[mid] = pill
            lay.addWidget(pill)
        lay.addStretch(1)
        self.actions_layout = QHBoxLayout()
        self.actions_layout.setSpacing(4)
        lay.addLayout(self.actions_layout)

    def set_active(self, mode_id):
        for mid, p in self._pills.items():
            p.setChecked(mid == mode_id)

    def add_action(self, text, command):
        btn = make_button(text, "secondary", command)
        self.actions_layout.addWidget(btn)
        return btn


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.config = QtConfig()
        cfg = self.config
        self.setWindowTitle("WordCrafter Pro")
        self.resize(1320, 880)
        self.setMinimumSize(1080, 700)
        app_ico = asset("app_icon.ico") or asset("app_icon.png")
        if app_ico:
            self.setWindowIcon(QIcon(app_ico))

        self.folders = FolderRepository()
        self._pending_folder = None

        self.central = QWidget()
        self.central.setObjectName("bg")
        self.setCentralWidget(self.central)
        self.setStyleSheet(qss(cfg))

        self._wallpaper_bg = None
        self._wallpaper_shade = None

        outer = QVBoxLayout(self.central)
        outer.setContentsMargins(12, 12, 12, 12)
        outer.setSpacing(8)

        self.toasts = ToastHost(self.central, cfg)

        row = QHBoxLayout()
        row.setSpacing(0)
        outer.addLayout(row, 1)

        self.sidebar = Sidebar(self)
        row.addWidget(self.sidebar)
        handle = _ResizeHandle(self.sidebar)
        row.addWidget(handle)

        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(8, 0, 0, 0)
        right_layout.setSpacing(8)

        self.mode_bar = TopModeBar(IMPLEMENTED, "vocab", self.switch_mode)
        # Web UI 开关（单个 JK 图标，位于生词库左侧；图片缺失时回退 WiFi 图形）
        self._web = None
        web_icon = asset("web_icon.png")
        self.btn_web = (make_image_icon_button(web_icon, self.toggle_web, size=30)
                        if web_icon else make_wifi_button(self.toggle_web, size=30))
        self.btn_web.setToolTip("局域网 Web UI：开启后手机/平板可访问并同步数据")
        self.mode_bar.actions_layout.addWidget(self.btn_web)
        self._apply_web_style(bool(cfg.config_repo.data.get("web_enabled")))
        self.btn_vocab = self.mode_bar.add_action(
            f"生词库 ({len(cfg.vocab_history)})", self.open_vocab_manager)
        right_layout.addWidget(self.mode_bar)

        self.stack = QStackedWidget()
        right_layout.addWidget(self.stack, 1)

        self.effect = QGraphicsOpacityEffect(self.stack)
        self.stack.setGraphicsEffect(self.effect)
        self.effect.setOpacity(1.0)
        self._fading = False

        self.context_holder = QWidget()
        self._ctx_vbox = QVBoxLayout(self.context_holder)
        self._ctx_vbox.setContentsMargins(0, 0, 0, 0)
        right_layout.addWidget(self.context_holder)

        row.addWidget(right, 1)

        self.study = StudyRepository()
        self.decks = DeckRepository()
        self.logs = DailyLogs()
        self.pages = {}
        self._register("vocab", VocabPage)
        self._register("study", StudyPage)
        self._register("reading", ReadingPage)
        self._register("acg", AcgPage)
        self._register("dictionary", DictionaryPage)
        self._register("settings", SettingsPage)

        self.stack.currentChanged.connect(self._fade_in)
        self.switch_mode("vocab")
        self._active_mode = "vocab"

        self.apply_wallpaper()
        # 上次开启过 Web UI → 启动后自动恢复（免手点，仅 Toast 提示）
        if cfg.config_repo.data.get("web_enabled"):
            QTimer.singleShot(600,
                              lambda: self._start_web(show_dialog=False))

    # ---------------- 页面 ----------------
    def _register(self, mode_id, page_cls):
        page = page_cls(self)
        self.pages[mode_id] = page
        self.stack.addWidget(page)

    def switch_mode(self, mode_id):
        if mode_id not in self.pages:
            self.toasts.show("该功能页仍在迁移中", kind="info")
            return
        self._active_mode = mode_id
        self.mode_bar.set_active(mode_id)
        self.stack.setCurrentWidget(self.pages[mode_id])
        page = self.pages[mode_id]
        if hasattr(page, "on_activated"):
            try:
                page.on_activated()
            except Exception:
                pass
        self._rebuild_context()

    def _rebuild_context(self):
        while self._ctx_vbox.count():
            item = self._ctx_vbox.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()
        page = self.pages.get(self._active_mode)
        if page is not None and hasattr(page, "build_context_bar"):
            page.build_context_bar(self.context_holder)

    def _fade_in(self, index):
        self.effect.setOpacity(0.0)
        QTimer.singleShot(0, lambda: self._fade_step(0))

    def _fade_step(self, step):
        if step > 9:
            self.effect.setOpacity(1.0)
            return
        self.effect.setOpacity(step / 9.0)
        QTimer.singleShot(18, lambda: self._fade_step(step + 1))

    # ---------------- 行为 ----------------
    def on_new_task(self):
        self.switch_mode("reading")
        self.toasts.show("开始一次新的阅读任务", kind="info")

    def open_session(self, session):
        kind = session.get("page_type") or session.get("kind", "")
        target = kind if kind in self.pages else ("reading" if kind else "vocab")
        self.switch_mode(target)
        restored = False
        page = self.pages.get(target)
        if page is not None and hasattr(page, "restore_session"):
            try:
                restored = bool(page.restore_session(session))
            except Exception as exc:
                print(f"[SessionRestore] {target}: {exc}")
        if restored:
            self.toasts.show(f"已恢复：{session.get('title', '')}", kind="success")
        else:
            self.toasts.show("已打开（旧版记录或内容为空）", kind="info")

    def add_session(self, kind, title, summary="", meta=None, content=None):
        return self.sidebar.add_session_entry(kind, title, summary=summary,
                                              meta=meta, content=content)

    def update_global_vocab_status(self):
        try:
            self.btn_vocab.setText(f"生词库 ({len(self.config.vocab_history)})")
        except Exception:
            pass

    def open_vocab_manager(self):
        from .vocab_dialog import VocabManagerDialog
        dlg = VocabManagerDialog(self)
        dlg.exec()

    # ---------------- Web UI（局域网访问） ----------------
    def toggle_web(self):
        if self._web and self._web.is_running():
            self._stop_web()
            self.toasts.show("Web UI 已关闭", kind="info")
            return
        self._start_web(show_dialog=True)

    def _start_web(self, show_dialog=True):
        from ..webui import WebServer, WebState
        if self._web and self._web.is_running():
            return
        import secrets
        token = self.config.config_repo.data.get("web_token") or ""
        if not token:
            token = secrets.token_hex(4)
        port = int(self.config.config_repo.data.get("web_port", 8765) or 8765)
        state = WebState(self.config, self.study, self.decks, self.logs,
                         self.sidebar.sessions)
        server = WebServer(state, port=port, token=token)
        try:
            ok = server.start()
        except Exception as exc:
            self.toasts.show(f"启动失败：{exc}", kind="error")
            return
        if not ok:
            return
        self._web = server
        self.config.config_repo.save_all({"web_enabled": True,
                                          "web_port": port,
                                          "web_token": token})
        self._apply_web_style(True)
        if show_dialog:
            urls = server.urls
            body = ("Web UI 已开启：手机 / 平板连接同一 WiFi 后，用浏览器打开以下任一地址：\n\n" +
                    "\n".join(urls) + "\n\n（含 token；请勿把地址发给陌生人）")
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.information(self, "📶 局域网 Web UI", body)
        self.toasts.show("Web UI 已开启（首次请用含 token 的地址打开一次）",
                         kind="success")

    def _stop_web(self):
        if self._web is not None:
            try:
                self._web.stop()
            except Exception:
                pass
            self._web = None
            try:
                self.config.config_repo.save_all({"web_enabled": False})
            except Exception:
                pass
            self._apply_web_style(False)

    def _apply_web_style(self, on):
        try:
            accent = self.config.c_primary[0 if is_light_mode(self.config) else 1]
            self.btn_web.set_state(on, accent)
            self.btn_web.setToolTip(
                "局域网 Web UI：开启后手机/平板可访问并同步数据"
                if not on else "局域网 Web UI：点击关闭")
        except Exception:
            pass

    def closeEvent(self, event):
        self._stop_web()
        super().closeEvent(event)


    def relaunch(self, message=None):
        self.setStyleSheet(qss(self.config))
        self.apply_wallpaper()
        if message:
            self.toasts.show(message, kind="success")

    # ---------------- 壁纸 ----------------
    def apply_wallpaper(self):
        cfg = self.config
        for old in (self._wallpaper_bg, self._wallpaper_shade):
            if old is not None:
                old.deleteLater()
        self._wallpaper_bg = self._wallpaper_shade = None
        path = cfg.wallpaper_path
        if not path or not os.path.exists(path):
            self.setStyleSheet(qss(cfg))
            return
        try:
            pix = QPixmap(path)
            if pix.isNull():
                return
            size = self.central.size()
            if size.width() < 10:
                size = self.size()
            pix = pix.scaled(size, Qt.KeepAspectRatioByExpanding,
                             Qt.SmoothTransformation)
            x = (pix.width() - size.width()) // 2
            y = (pix.height() - size.height()) // 2
            if x > 0 or y > 0:
                pix = pix.copy(max(0, x), max(0, y), size.width(), size.height())
            bg = QLabel(self.central)
            bg.setPixmap(pix)
            bg.setGeometry(0, 0, size.width(), size.height())
            if cfg.wallpaper_blur > 0:
                eff = QGraphicsBlurEffect(bg)
                eff.setBlurRadius(min(30, cfg.wallpaper_blur * 2))
                bg.setGraphicsEffect(eff)
            bg.lower()
            bg.show()
            alpha = int(255 * (1.0 - cfg.wallpaper_opacity))
            light = is_light_mode(cfg)
            rgb = (247, 247, 248) if light else (23, 23, 23)
            shade = QLabel(self.central)
            shade.setStyleSheet(f"background: rgba({rgb[0]},{rgb[1]},{rgb[2]},{alpha});")
            shade.setGeometry(0, 0, size.width(), size.height())
            shade.lower()
            shade.show()
            self._wallpaper_bg = bg
            self._wallpaper_shade = shade
        except Exception as exc:
            print(f"[QtWallpaper] failed: {exc}")

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self._wallpaper_bg is not None:
            self.apply_wallpaper()

    def showEvent(self, event):
        super().showEvent(event)
        # Win11 Mica（尽力而为，失败自动回退不透明样式）
        try:
            BackdropManager.apply(self)
        except Exception:
            pass
