# ==============================================================================
# 文件路径: wordcrafter/services/pronunciation.py
# 统一发音服务：各页面（单词/生词库/词典/记单词）共用同一发音入口
# 能力取决于现有 TTS 配置（微软 TTS Key；无 Key 时回退系统 PowerShell TTS）
# ==============================================================================
from .microsoft import MicrosoftSpeechService


class PronunciationService:
    """统一发音入口（当前能力：配置的单一微软音色；后续可扩展英/美音菜单）。"""

    @staticmethod
    def play(word, cfg, region_voice=None):
        """朗读单词。cfg 缺省取全局配置；region_voice 可用于指定不同口音。"""
        text = str(word).strip()
        if not text:
            return
        voice = cfg.ms_voice_name if region_voice is None else region_voice
        MicrosoftSpeechService.speak_async(
            text, cfg.ms_speech_key, cfg.ms_speech_region, voice)

    @staticmethod
    def supported_accents(cfg):
        """当前实际可用的口音（按现有音色配置返回；避免伪造不存在的音源）。"""
        return {"默认": cfg.ms_voice_name}
