# ==============================================================================
# 文件路径: wordcrafter/services/dictionary.py
# 包含服务: FreeDictService
# 免费在线英语词典 (dictionaryapi.dev) 查询
# ==============================================================================
import json
import threading
import urllib.request


class FreeDictService:
    @staticmethod
    def lookup(word):
        clean_word = word.strip().lower()
        url = f"https://api.dictionaryapi.dev/api/v2/entries/en/{clean_word}"
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=5) as response:
                data = json.loads(response.read().decode("utf-8"))
                if isinstance(data, list) and len(data) > 0:
                    entry = data[0]
                    phonetic = entry.get("phonetic", "")
                    if not phonetic and entry.get("phonetics"):
                        for p in entry["phonetics"]:
                            if p.get("text"):
                                phonetic = p["text"]
                                break
                    meanings = entry.get("meanings", [])
                    pos_def_list = []
                    example_sentence = ""
                    for m in meanings:
                        pos = m.get("partOfSpeech", "")
                        defs = m.get("definitions", [])
                        if defs:
                            def_text = defs[0].get("definition", "")
                            pos_def_list.append(f"{pos}. {def_text}")
                            if not example_sentence and defs[0].get("example"):
                                example_sentence = defs[0]["example"]
                    return {
                        "phonetic": phonetic or "[No phonetic]",
                        "pos_def": "\n".join(pos_def_list) if pos_def_list else "暂无释义",
                        "example": example_sentence or f"This is an authentic example containing '{clean_word}'."
                    }
        except Exception:
            pass
        return {
            "phonetic": "[离线词库]",
            "pos_def": "未查询到释义，可在设置中配置微软翻译/AI模型",
            "example": f"Example sentence using {clean_word}."
        }

    @staticmethod
    def submit_lookup(word, callback):
        def _run():
            res = FreeDictService.lookup(word)
            callback(res)
        threading.Thread(target=_run, daemon=True).start()
