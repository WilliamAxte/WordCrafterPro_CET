# ==============================================================================
# KyleBing/english-vocabulary 词典下载服务
# ==============================================================================
import json
import os
import tempfile
import urllib.parse
import urllib.request

TREE_API = "https://api.github.com/repos/KyleBing/english-vocabulary/git/trees/master?recursive=1"
RAW_BASE = "https://raw.githubusercontent.com/KyleBing/english-vocabulary/master/"
UA = {"User-Agent": "WordCrafterPro/2.0 (open-source vocabulary client)"}


class KyleBingWordbooks:
    @staticmethod
    def list_dictionary_files(timeout=15):
        """递归列出仓库中全部可直接导入的词典文件。

        包含根目录 TXT、json/ JSON、full_line_jsonl/ JSONL、
        full_line_tsv/ TSV；README、示例和 SQL 等非词典文件会被排除。
        """
        req = urllib.request.Request(TREE_API, headers=UA)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))

        out = []
        tree = data.get("tree", []) if isinstance(data, dict) else []
        for item in tree:
            if not isinstance(item, dict) or item.get("type") != "blob":
                continue
            path = str(item.get("path", ""))
            low = path.lower()
            if os.path.basename(path).lower().startswith("sample_"):
                continue
            is_root_txt = "/" not in path and low.endswith(".txt")
            is_json = low.startswith("json/") and low.endswith(".json")
            is_jsonl = low.startswith("full_line_jsonl/") and low.endswith(".jsonl")
            is_tsv = low.startswith("full_line_tsv/") and low.endswith(".txt")
            if not (is_root_txt or is_json or is_jsonl or is_tsv):
                continue
            fmt = "txt" if is_root_txt else ("json" if is_json else
                  "jsonl" if is_jsonl else "tsv")
            out.append({
                "name": path,
                "download_url": RAW_BASE + urllib.parse.quote(path, safe="/"),
                "size": item.get("size", 0),
                "format": fmt,
            })
        return sorted(out, key=lambda x: x["name"].lower())

    @staticmethod
    def list_json_files(timeout=15):
        """兼容旧调用名：现在返回仓库中的全部可导入词典。"""
        return KyleBingWordbooks.list_dictionary_files(timeout=timeout)

    @classmethod
    def import_to_store(cls, entry, store, label=None):
        """下载一个远程词典，解析后保存到本地词典仓储。"""
        url = entry.get("download_url")
        if not url:
            raise ValueError("该词典没有可下载地址")
        # GitHub 路径可能包含中文；先编码成 ASCII URL，避免 Windows urllib 报错。
        safe_url = urllib.parse.quote(str(url), safe=":/?&=#%")
        req = urllib.request.Request(safe_url, headers=UA)
        with urllib.request.urlopen(req, timeout=120) as resp:
            raw = resp.read()

        fmt = entry.get("format") or "json"
        suffix = ".jsonl" if fmt == "jsonl" else ".txt" if fmt in ("txt", "tsv") else ".json"
        tmp = tempfile.NamedTemporaryFile(suffix=suffix, delete=False)
        try:
            tmp.write(raw)
            tmp.close()
            filename = os.path.basename(entry.get("name", "wordbook"))
            book_label = label or os.path.splitext(filename)[0]
            if fmt == "jsonl":
                return store.import_jsonl_file(
                    tmp.name, label=book_label, kind="online",
                    source="KyleBing/english-vocabulary")
            if fmt == "tsv":
                return store.import_tsv_file(
                    tmp.name, label=book_label, kind="online",
                    source="KyleBing/english-vocabulary")
            if fmt == "txt":
                return store.import_text_file(
                    tmp.name, label=book_label, kind="online",
                    source="KyleBing/english-vocabulary")
            return store.import_wordbook(tmp.name, label=book_label)
        finally:
            try:
                os.unlink(tmp.name)
            except Exception:
                pass
