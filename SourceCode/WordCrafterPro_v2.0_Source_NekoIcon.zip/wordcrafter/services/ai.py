# ==============================================================================
# 文件路径: wordcrafter/services/ai.py
# 包含组件: StreamRouter, AIService
# 流式文本分流 + OpenAI 兼容接口的流式短文/特稿/精读生成
# ==============================================================================
import json
import re
import urllib.request


class StreamRouter:
    """高可用流式分流路由器：精准识别中英文分界标签，杜绝中文串入英文框"""
    _CJK_RE = re.compile(r"[\u4e00-\u9fff]")
    _TAG_RE = re.compile(r"\[/?(ENGLISH|CHINESE)_(START|END)\]")

    def __init__(self, txt_en, txt_zh):
        self.txt_en = txt_en
        self.txt_zh = txt_zh
        self.buffer = ""
        self.mode = "INIT"
        self.has_switched_to_zh = False

    def feed(self, token):
        self.buffer += token

        while True:
            if self.mode == "INIT":
                if "[ENGLISH_START]" in self.buffer:
                    _, self.buffer = self.buffer.split("[ENGLISH_START]", 1)
                    self.mode = "EN"
                    continue
                elif len(self.buffer) > 20 and "[" not in self.buffer:
                    self.mode = "EN"
                    continue
                break

            if self.mode == "EN":
                if "[ENGLISH_END]" in self.buffer:
                    en_part, self.buffer = self.buffer.split("[ENGLISH_END]", 1)
                    if en_part:
                        self.txt_en.insert("end", en_part)
                    self.mode = "WAIT_ZH"
                    continue
                elif "[CHINESE_START]" in self.buffer:
                    en_part, self.buffer = self.buffer.split("[CHINESE_START]", 1)
                    if en_part:
                        self.txt_en.insert("end", en_part)
                    self.mode = "ZH"
                    self.has_switched_to_zh = True
                    continue

                if "[" in self.buffer:
                    idx = self.buffer.find("[")
                    if idx > 0:
                        self.txt_en.insert("end", self.buffer[:idx])
                        self.buffer = self.buffer[idx:]
                    break
                else:
                    self.txt_en.insert("end", self.buffer)
                    self.buffer = ""
                    break

            if self.mode == "WAIT_ZH":
                if "[CHINESE_START]" in self.buffer:
                    _, self.buffer = self.buffer.split("[CHINESE_START]", 1)
                    self.mode = "ZH"
                    self.has_switched_to_zh = True
                    continue
                elif self._CJK_RE.search(self.buffer):
                    self.mode = "ZH"
                    self.has_switched_to_zh = True
                    continue
                break

            if self.mode == "ZH":
                if "[CHINESE_END]" in self.buffer:
                    zh_part, self.buffer = self.buffer.split("[CHINESE_END]", 1)
                    if zh_part:
                        self.txt_zh.insert("end", zh_part)
                    self.mode = "DONE"
                    continue

                if "[" in self.buffer:
                    idx = self.buffer.find("[")
                    if idx > 0:
                        self.txt_zh.insert("end", self.buffer[:idx])
                        self.buffer = self.buffer[idx:]
                    break
                else:
                    self.txt_zh.insert("end", self.buffer)
                    self.buffer = ""
                    break

            if self.mode == "DONE":
                break

    def close(self):
        if self.buffer:
            clean = self._TAG_RE.sub('', self.buffer).strip()
            if clean:
                if self.mode == "ZH" or self.has_switched_to_zh or self._CJK_RE.search(clean):
                    self.txt_zh.insert("end", clean)
                else:
                    self.txt_en.insert("end", clean)
        self.buffer = ""


class AIService:
    @staticmethod
    def generate_vocab_story_stream(words, extra_cnt, target_len, difficulty, api_key, api_url, model_name, on_token):
        prompt = f"""You are a professional English tutor. Write a coherent, engaging story using the target vocabulary.

Target Words: {', '.join(words)}
Length: {target_len}
Difficulty: {difficulty}
Extra expansion vocabulary: {extra_cnt} words.

CRITICAL INSTRUCTIONS:
1. You MUST separate the English story and Chinese translation strictly using the tags below.
2. DO NOT include any conversational greetings or introductory text.

[ENGLISH_START]
(Write the pure English story text here)
[ENGLISH_END]
[CHINESE_START]
(Write the accurate, natural Chinese translation here)
[CHINESE_END]"""
        AIService._stream_request(prompt, api_key, api_url, model_name, on_token)

    @staticmethod
    def generate_acg_story_stream(words, extra_cnt, target_len, category, topic, difficulty, api_key, api_url, model_name, on_token):
        prompt = f"""You are an elite ACG / Anime & Gaming culture columnist. Write an in-depth essay or review.

Category: {category}
Topic: {topic}
Mandatory Vocabulary: {', '.join(words)}
Length: {target_len}
Difficulty: {difficulty}
Extra Words: {extra_cnt}

CRITICAL FORMAT REQUIREMENT:
[ENGLISH_START]
(Write the pure English ACG essay text here)
[ENGLISH_END]
[CHINESE_START]
(Write the pure Chinese translation here)
[CHINESE_END]"""
        AIService._stream_request(prompt, api_key, api_url, model_name, on_token)

    @staticmethod
    def fetch_authentic_reading_stream(source_type, work_name, target_len, difficulty, api_key, api_url, model_name, on_token):
        prompt = f"""You are a literary reading assistant. Provide an authentic reading excerpt.

Source Type: {source_type}
Work/Speaker: {work_name}
Excerpt Length: {target_len}
Difficulty: {difficulty}

CRITICAL FORMAT REQUIREMENT:
[ENGLISH_START]
(Write the authentic English reading text here)
[ENGLISH_END]
[CHINESE_START]
(Write the Chinese translation here)
[CHINESE_END]"""
        AIService._stream_request(prompt, api_key, api_url, model_name, on_token)

    @staticmethod
    def _stream_request(prompt, api_key, api_url, model_name, on_token):
        if not api_key:
            raise ValueError("API Key 为空，请在顶部或设置中配置。")
        payload = {
            "model": model_name,
            "messages": [
                {"role": "system", "content": "You are a bilingual teaching engine. Strictly adhere to formatting tags."},
                {"role": "user", "content": prompt}
            ],
            "stream": True,
            "temperature": 0.7
        }
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key.strip()}"
        }
        req = urllib.request.Request(api_url, data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=60) as resp:
            for line in resp:
                line = line.decode("utf-8").strip()
                if not line or not line.startswith("data:"):
                    continue
                data_str = line[5:].strip()
                if data_str == "[DONE]":
                    break
                try:
                    chunk = json.loads(data_str)
                    choices = chunk.get("choices", [])
                    if choices:
                        delta = choices[0].get("delta", {})
                        token = delta.get("content", "")
                        if token:
                            on_token(token)
                except Exception:
                    pass
