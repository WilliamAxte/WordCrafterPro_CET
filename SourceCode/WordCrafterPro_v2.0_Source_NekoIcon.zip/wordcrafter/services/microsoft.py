# ==============================================================================
# 文件路径: wordcrafter/services/microsoft.py
# 包含服务: MicrosoftTranslatorService, MicrosoftSpeechService
# 微软 Azure 翻译/词典查词 + 微软 TTS 语音朗读
# ==============================================================================
import json
import subprocess
import sys
import threading
import urllib.request


class MicrosoftTranslatorService:
    @staticmethod
    def translate_text(text, api_key, region="global", target_lang="zh-Hans"):
        if not api_key:
            raise ValueError("未配置微软翻译 API Key。")

        endpoint = "https://api.cognitive.microsofttranslator.com/translate"
        params = f"?api-version=3.0&to={target_lang}"
        url = endpoint + params

        headers = {
            "Ocp-Apim-Subscription-Key": api_key.strip(),
            "Content-Type": "application/json; charset=UTF-8"
        }
        if region and region.strip() != "global":
            headers["Ocp-Apim-Subscription-Region"] = region.strip()

        body = json.dumps([{"Text": text}]).encode("utf-8")
        req = urllib.request.Request(url, data=body, headers=headers, method="POST")

        with urllib.request.urlopen(req, timeout=10) as response:
            result = json.loads(response.read().decode("utf-8"))
            if result and isinstance(result, list):
                translations = result[0].get("translations", [])
                if translations:
                    return translations[0].get("text", "")
        return ""

    @staticmethod
    def lookup_word(word, api_key, region="global"):
        if not api_key:
            raise ValueError("微软翻译 API Key 未设置。")

        lookup_url = "https://api.cognitive.microsofttranslator.com/dictionary/lookup?api-version=3.0&from=en&to=zh-Hans"
        headers = {
            "Ocp-Apim-Subscription-Key": api_key.strip(),
            "Content-Type": "application/json; charset=UTF-8"
        }
        if region and region.strip() != "global":
            headers["Ocp-Apim-Subscription-Region"] = region.strip()

        body = json.dumps([{"Text": word}]).encode("utf-8")
        req = urllib.request.Request(lookup_url, data=body, headers=headers, method="POST")

        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                res = json.loads(resp.read().decode("utf-8"))
                defs = []
                if res and isinstance(res, list) and res[0].get("translations"):
                    for tr in res[0]["translations"][:4]:
                        pos = tr.get("posTag", "").lower()
                        display_target = tr.get("displayTarget", "")
                        defs.append(f"{pos}. {display_target}")
                pos_def = "\n".join(defs) if defs else "微软翻译释义"
                if not defs:
                    trans = MicrosoftTranslatorService.translate_text(word, api_key, region)
                    pos_def = f"n./v. {trans}"

                return {
                    "phonetic": "[Microsoft Azure Translator]",
                    "pos_def": pos_def,
                    "example": f"Example sentence containing '{word}'."
                }
        except Exception:
            trans = MicrosoftTranslatorService.translate_text(word, api_key, region)
            return {
                "phonetic": "[Microsoft Translator]",
                "pos_def": f"释义: {trans}",
                "example": f"Example sentence using {word}."
            }


class MicrosoftSpeechService:
    @staticmethod
    def speak_async(text, speech_key="", region="eastasia", voice="en-US-JennyNeural"):
        threading.Thread(
            target=MicrosoftSpeechService._speak_worker,
            args=(text, speech_key, region, voice),
            daemon=True
        ).start()

    @staticmethod
    def _speak_worker(text, speech_key, region, voice):
        if speech_key and speech_key.strip():
            try:
                url = f"https://{region.strip()}.tts.speech.microsoft.com/cognitiveservices/v1"
                headers = {
                    "Ocp-Apim-Subscription-Key": speech_key.strip(),
                    "Content-Type": "application/ssml+xml",
                    "X-Microsoft-OutputFormat": "riff-16khz-16bit-mono-pcm",
                    "User-Agent": "WordCrafterPro"
                }
                ssml = f"""<speak version='1.0' xml:lang='en-US'><voice name='{voice}'>{text}</voice></speak>"""
                req = urllib.request.Request(url, data=ssml.encode("utf-8"), headers=headers, method="POST")
                with urllib.request.urlopen(req, timeout=8) as resp:
                    audio_data = resp.read()
                    import winsound
                    winsound.PlaySound(audio_data, winsound.SND_MEMORY)
                    return
            except Exception:
                pass

        try:
            if sys.platform == "win32":
                clean = text.replace('"', ' ').replace("'", " ")
                ps_cmd = (
                    "Add-Type -AssemblyName System.Speech; "
                    f"(New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{clean}')"
                )
                subprocess.run(
                    ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_cmd],
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
        except Exception:
            pass
