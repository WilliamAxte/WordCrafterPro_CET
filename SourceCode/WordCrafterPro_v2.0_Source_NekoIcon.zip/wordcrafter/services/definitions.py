# ==============================================================================
# 文件路径: wordcrafter/services/definitions.py
# 包含服务: PROVIDERS 提供商注册表, WiktionaryService, MerriamWebsterService,
#           DictionaryService（统一查词 + 批量导入）
#
# 词典源说明（公益公开数据）：
#   - wiktionary  维基词典 (Wikimedia 基金会·非营利，免费 REST API，CC BY-SA)
#   - freedict    免费词典 dictionaryapi.dev（Wiktionary 开放数据）
#   - merriam     韦氏 Learner's（免费教育授权 API，需自备 Key）
#   - wordnet     普林斯顿 WordNet（免费研究数据，通过离线文件导入使用）
#   - microsoft   微软必应翻译（中英双语释义，沿用原查词引擎配置）
#   - oxford/cambridge 为商业授权词典（官方 API 付费），预留占位、不可用
# ==============================================================================
import json
import threading
import urllib.error
import urllib.parse
import urllib.request

_UA = {"User-Agent": "WordCrafterPro/1.1 (open-source bilingual reader)"}

PROVIDERS = [
    {"id": "microsoft", "name": "微软必应翻译", "tag": "中英双语释义", "kind": "online",
     "needs_key": True, "key_id": "ms_translator_key", "note": "由「设置 → 查词引擎」控制"},
    {"id": "wiktionary", "name": "维基词典 Wiktionary", "tag": "维基基金会·公益", "kind": "online",
     "needs_key": False, "key_id": None, "note": "免费 REST API · CC BY-SA"},
    {"id": "freedict", "name": "Free Dictionary", "tag": "Wiktionary 开放数据", "kind": "online",
     "needs_key": False, "key_id": None, "note": "dictionaryapi.dev"},
    {"id": "merriam", "name": "韦氏 Learner's", "tag": "免费教育授权", "kind": "online",
     "needs_key": True, "key_id": "merriam_key", "note": "需在 dictionaryapi.com 免费申请 Key"},
    {"id": "wordnet", "name": "WordNet（普林斯顿）", "tag": "免费研究数据库", "kind": "offline",
     "needs_key": False, "key_id": None, "note": "通过「离线词典文件导入」使用"},
    {"id": "oxford", "name": "牛津词典", "tag": "商业授权", "kind": "reserved",
     "needs_key": True, "key_id": None, "note": "官方 API 为付费授权，暂不支持"},
    {"id": "cambridge", "name": "剑桥词典", "tag": "商业授权", "kind": "reserved",
     "needs_key": True, "key_id": None, "note": "官方 API 为商业合作制，暂不支持"},
]
PROVIDER_BY_ID = {p["id"]: p for p in PROVIDERS}


def provider_available(pid, cfg):
    """根据当前配置判断某个在线源是否可用（未启用/缺 Key/保留源均视为不可用）。"""
    p = PROVIDER_BY_ID.get(pid)
    if not p or p["kind"] != "online":
        return False
    if pid == "microsoft":
        return cfg.translate_engine == "微软必应翻译" and bool(cfg.ms_translator_key)
    if p["needs_key"]:
        return bool((cfg.config_repo.data.get(p["key_id"]) or "").strip())
    return True


class WiktionaryService:
    """维基词典 Wikimedia REST API（en 词条，公益免费）。"""

    BASE = "https://en.wiktionary.org/api/rest_v1/page/definition/{word}?redirect=true"

    @staticmethod
    def lookup(word):
        url = WiktionaryService.BASE.format(word=urllib.parse.quote(word.strip()))
        req = urllib.request.Request(url, headers=_UA)
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return WiktionaryService.parse_response(data, word)

    @staticmethod
    def parse_response(data, word):
        """把 REST 响应解析为统一词条；无有效英文释义时返回 None。"""
        sections = data.get("en") or []
        pos_defs = []
        example = ""
        for sec in sections:
            pos = sec.get("partOfSpeech") or ""
            for d in (sec.get("definitions") or []):
                text = (d.get("definition") or "").strip()
                if not text:
                    continue
                pos_defs.append(f"{pos}. {text}" if pos else text)
                if not example:
                    for ex in (d.get("examples") or []):
                        ex_text = ex.get("text") if isinstance(ex, dict) else str(ex)
                        if ex_text and ex_text.strip():
                            example = ex_text.strip()
                            break
            if len(pos_defs) >= 4:
                break
        if not pos_defs:
            return None
        return {
            "word": str(word).strip().lower(),
            "phonetic": "",
            "pos_def": "\n".join(pos_defs),
            "example": example or f"An authentic example sentence containing '{word.strip()}'.",
            "source": "wiktionary",
        }


class MerriamWebsterService:
    """韦氏 Learner's Dictionary API（需免费教育 Key）。"""

    BASE = "https://www.dictionaryapi.com/api/v3/references/learners/json/{word}"

    @staticmethod
    def lookup(word, api_key):
        url = MerriamWebsterService.BASE.format(word=urllib.parse.quote(word.strip()))
        req = urllib.request.Request(f"{url}?key={urllib.parse.quote(api_key)}", headers=_UA)
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        if not isinstance(data, list) or not data:
            return None
        first = data[0]
        if isinstance(first, str):
            return None  # 拼写建议，视为未命中
        return MerriamWebsterService.parse_entry(first, word)

    @staticmethod
    def parse_entry(first, word):
        hwi = first.get("hwi") or {}
        phonetic = ""
        prs = hwi.get("prs") or []
        if prs and isinstance(prs[0], dict):
            phonetic = prs[0].get("ipa") or ""
        fl = first.get("fl") or ""
        shortdef = first.get("shortdef") or []
        pos_defs = []
        for d in shortdef[:3]:
            pos_defs.append(f"{fl}. {d}" if fl else str(d))
        if not pos_defs:
            return None
        return {
            "word": str(word).strip().lower(),
            "phonetic": phonetic,
            "pos_def": "\n".join(pos_defs),
            "example": f"An authentic learner example containing '{word.strip()}'.",
            "source": "merriam",
        }


class DictionaryService:
    """统一查词服务：本地缓存 → 词典仓储（批量/离线文件）→ 在线公益词典链。
    在线命中会由调用方写回 vocab 缓存，加快二次查词。"""

    @staticmethod
    def _online_chain(cfg):
        """按优先级返回在线查词链（provider id 列表）。"""
        chain = []
        if cfg.translate_engine == "微软必应翻译" and cfg.ms_translator_key:
            chain.append("microsoft")
        enabled = cfg.dictionary_enabled_sources
        for pid in enabled:
            if pid not in chain and provider_available(pid, cfg):
                chain.append(pid)
        return chain

    @staticmethod
    def _lookup_provider(pid, w, cfg):
        if pid == "wiktionary":
            return WiktionaryService.lookup(w)
        if pid == "freedict":
            from .dictionary import FreeDictService
            res = FreeDictService.lookup(w)
            if res.get("pos_def") and "未查询到释义" not in res.get("pos_def"):
                return res
            return None
        if pid == "microsoft":
            from .microsoft import MicrosoftTranslatorService
            return MicrosoftTranslatorService.lookup_word(
                w, cfg.ms_translator_key, cfg.ms_translator_region
            )
        if pid == "merriam":
            key = (cfg.config_repo.data.get("merriam_key") or "").strip()
            if key:
                return MerriamWebsterService.lookup(w, key)
        return None

    @classmethod
    def lookup_sync(cls, word, cfg):
        """同步查词。返回 (entry, layer)，layer ∈ {"cache","store","online",None}。"""
        w = str(word).strip().lower()
        if not w:
            return None, None

        cached = cfg.vocab_repo.cache.get(w)
        if cached and (cached.get("pos_def") or cached.get("phonetic")):
            return dict(cached), "cache"

        entry = cfg.dictionary_store.get(w)
        if entry:
            return dict(entry), "store"

        for pid in cls._online_chain(cfg):
            try:
                entry = cls._lookup_provider(pid, w, cfg)
            except Exception:
                entry = None
            if entry and (entry.get("pos_def") or entry.get("example")):
                entry.setdefault("source", pid)
                return entry, "online"
        return None, None

    @classmethod
    def lookup_async(cls, word, cfg, callback):
        def _run():
            try:
                entry, layer = cls.lookup_sync(word, cfg)
            except Exception:
                entry, layer = None, None
            callback(entry, layer)
        threading.Thread(target=_run, daemon=True).start()

    @classmethod
    def batch_import(cls, words, cfg, on_progress=None, cancel_flag=None):
        """对词表逐词按在线链抓取词条并整体写入仓储 batch。
        on_progress(i, total, word, ok, fail) 每词回调；cancel_flag: threading.Event。
        返回 {"ok", "kept", "failed", "canceled"}。"""
        store = cfg.dictionary_store
        old_batch = store.batch_entries()
        results = {}
        ok = kept = failed = 0
        words = [w for w in (str(x).strip().lower() for x in words) if w]
        total = len(words)
        chain = cls._online_chain(cfg)
        if not chain:
            return {"ok": 0, "kept": 0, "failed": len(words),
                    "canceled": False, "error": "没有可用的在线词典源（请在设置中启用公益词典源或配置查词引擎）"}

        for i, w in enumerate(words, 1):
            if cancel_flag is not None and cancel_flag.is_set():
                if on_progress:
                    on_progress(i, total, w, ok, failed)
                break
            entry = None
            for pid in chain:
                try:
                    entry = cls._lookup_provider(pid, w, cfg)
                except Exception:
                    entry = None
                if entry and (entry.get("pos_def") or entry.get("example")):
                    entry.setdefault("source", pid)
                    break
            if entry:
                results[w] = entry
                ok += 1
            else:
                old = old_batch.get(w)
                if old:
                    results[w] = old
                    kept += 1
                else:
                    failed += 1
            if on_progress:
                on_progress(i, total, w, ok, failed)

        store.set_batch_entries(results)
        return {"ok": ok, "kept": kept, "failed": failed,
                "canceled": bool(cancel_flag is not None and cancel_flag.is_set())}
