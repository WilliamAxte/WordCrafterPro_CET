# ==============================================================================
# 文件路径: wordcrafter/theme/tokens.py
# 设计尺度与语义色键（单一数据源）
# ==============================================================================

# ---------------- 间距体系 (px) ----------------
SPACING = {
    "xs": 4,
    "s": 8,
    "m": 12,
    "l": 16,
    "xl": 20,
    "xxl": 24,
    "xxxl": 32,
}

# ---------------- 圆角体系 (px) ----------------
RADIUS = {
    "chip": 8,        # 小控件 / 胶囊片段
    "control": 10,    # 普通控件（输入框、按钮）
    "card": 14,       # 卡片
    "panel": 18,      # 大型区域
    "window": 20,     # 弹窗/页面级容器
}

# ---------------- 语义色键（light/dark 必须一一对应） ----------------
COLOR_KEYS = (
    # 背景/表面
    "bg",              # 窗口背景
    "surface",         # 面板/卡片表面
    "surface_alt",     # 次级表面 / 中性按钮底
    "control_hover",   # 中性控件 hover
    "input",           # 输入框底
    # 边框
    "border",
    "border_subtle",
    # 文字
    "text",
    "text_secondary",
    "text_muted",
    # 强调色（全应用唯一）
    "accent",
    "accent_hover",
    "on_accent",
    "accent_soft",     # 强调色的浅底（次级按钮/选中背景）
    "on_accent_soft",  # 浅底上的文字
    # 语义状态（危险操作/成功提示）
    "danger",
    "danger_hover",
    "danger_bg",
    "danger_bg_hover",
    "success",
    "success_bg",
)

# ---------------- 字号基准 (px) ----------------
FONT_SCALE = {
    "display": 26,
    "title": 17,
    "heading": 15,
    "body": 13,
    "caption": 11,
}

# ---------------- 常用布局常量 ----------------
SIDEBAR_WIDTH = 236          # Sidebar 展开宽度
SIDEBAR_WIDTH_COLLAPSED = 64 # Sidebar 折叠宽度
CONTENT_MAX_WIDTH = 920      # 阅读/正文最大宽度（居中）
