# ==============================================================================
# 文件路径: wordcrafter/theme/palette.py
# 组装 (浅色, 深色) 元组色板，供 customtkinter 双模式控件直接使用
# 中性色固定来自 light/dark；强调色族由用户选择的强调色预设决定
# ==============================================================================
from .light import L
from .dark import D
from .presets import ACCENTS
from .tokens import COLOR_KEYS

# 强调色族键（随用户选择变化）
_ACCENT_KEYS = ("accent", "accent_hover", "on_accent", "accent_soft", "on_accent_soft")


def build_palette(accent_id="indigo"):
    """按强调色预设组装完整语义色板：{语义名: (light_hex, dark_hex)}。"""
    preset = ACCENTS.get(accent_id) or ACCENTS["indigo"]
    palette = {}
    for key in COLOR_KEYS:
        if key in _ACCENT_KEYS:
            palette[key] = (preset["light"][key], preset["dark"][key])
        else:
            palette[key] = (L[key], D[key])
    return palette


# 默认（靛蓝）色板，兼容按需引用
PALETTE = build_palette()


def tuple_of(name, accent_id="indigo"):
    """返回 (light, dark) 元组；未知键回退中性灰。"""
    return build_palette(accent_id).get(name, ("#888888", "#888888"))


def resolve(is_light, accent_id="indigo"):
    """按当前模式与强调色返回具体色值 dict。"""
    p = build_palette(accent_id)
    return {key: p[key][0 if is_light else 1] for key in COLOR_KEYS}
