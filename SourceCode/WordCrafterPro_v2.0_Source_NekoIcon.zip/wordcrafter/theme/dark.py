# ==============================================================================
# 文件路径: wordcrafter/theme/dark.py
# 深色语义色板：非纯黑、低饱和中性灰、同系淡强调色
# ==============================================================================
D = {
    "bg": "#171717",
    "surface": "#1F1F22",
    "surface_alt": "#27272A",
    "control_hover": "#3A3A3F",
    "input": "#202024",

    "border": "#323236",
    "border_subtle": "#2A2A2E",

    "text": "#F4F4F5",
    "text_secondary": "#A1A1AA",
    "text_muted": "#71717A",

    "accent": "#818CF8",
    "accent_hover": "#A5B4FC",
    "on_accent": "#101014",
    "accent_soft": "#262A40",
    "on_accent_soft": "#C7D2FE",

    "danger": "#F87171",
    "danger_hover": "#EF4444",
    "danger_bg": "#3A2323",
    "danger_bg_hover": "#4A2A2A",
    "success": "#4ADE80",
    "success_bg": "#1C2B21",
}
