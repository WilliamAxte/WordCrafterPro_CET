# ==============================================================================
# 文件路径: wordcrafter/theme/presets.py
# 强调色预设（用户可在设置中选择，应用全局唯一强调色）
# 每个预设提供 light/dark 两套：accent / accent_hover / on_accent / accent_soft / on_accent_soft
# ==============================================================================
ACCENTS = {
    "indigo": {
        "name": "靛蓝",
        "light": {"accent": "#4F46E5", "accent_hover": "#4338CA", "on_accent": "#FFFFFF",
                  "accent_soft": "#EEF2FF", "on_accent_soft": "#3730A3"},
        "dark": {"accent": "#818CF8", "accent_hover": "#A5B4FC", "on_accent": "#101014",
                 "accent_soft": "#262A40", "on_accent_soft": "#C7D2FE"},
    },
    "sky": {
        "name": "青蓝",
        "light": {"accent": "#0284C7", "accent_hover": "#0369A1", "on_accent": "#FFFFFF",
                  "accent_soft": "#E0F2FE", "on_accent_soft": "#075985"},
        "dark": {"accent": "#38BDF8", "accent_hover": "#7DD3FC", "on_accent": "#0C1620",
                 "accent_soft": "#123B55", "on_accent_soft": "#BAE6FD"},
    },
    "emerald": {
        "name": "翠绿",
        "light": {"accent": "#059669", "accent_hover": "#047857", "on_accent": "#FFFFFF",
                  "accent_soft": "#D1FAE5", "on_accent_soft": "#065F46"},
        "dark": {"accent": "#34D399", "accent_hover": "#6EE7B7", "on_accent": "#06281B",
                 "accent_soft": "#0B2E24", "on_accent_soft": "#A7F3D0"},
    },
    "violet": {
        "name": "紫罗兰",
        "light": {"accent": "#7C3AED", "accent_hover": "#6D28D9", "on_accent": "#FFFFFF",
                  "accent_soft": "#EDE9FE", "on_accent_soft": "#5B21B6"},
        "dark": {"accent": "#A78BFA", "accent_hover": "#C4B5FD", "on_accent": "#150B2E",
                 "accent_soft": "#2E1F4F", "on_accent_soft": "#DDD6FE"},
    },
    "rose": {
        "name": "玫红",
        "light": {"accent": "#E11D48", "accent_hover": "#BE123C", "on_accent": "#FFFFFF",
                  "accent_soft": "#FFE4E6", "on_accent_soft": "#9F1239"},
        "dark": {"accent": "#FB7185", "accent_hover": "#FDA4AF", "on_accent": "#2A0A12",
                 "accent_soft": "#43232C", "on_accent_soft": "#FECDD3"},
    },
    "amber": {
        "name": "琥珀",
        "light": {"accent": "#D97706", "accent_hover": "#B45309", "on_accent": "#FFFFFF",
                  "accent_soft": "#FEF3C7", "on_accent_soft": "#92400E"},
        "dark": {"accent": "#FBBF24", "accent_hover": "#FCD34D", "on_accent": "#1F1800",
                 "accent_soft": "#3A2E0C", "on_accent_soft": "#FDE68A"},
    },
}

ACCENT_IDS = list(ACCENTS.keys())
ACCENT_NAMES = {aid: ACCENTS[aid]["name"] for aid in ACCENT_IDS}
