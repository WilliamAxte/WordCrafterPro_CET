# ==============================================================================
# 文件路径: wordcrafter/theme/light.py
# 浅色语义色板：非纯白、微暖灰底、克制单强调色（靛蓝）
# ==============================================================================
L = {
    "bg": "#F7F7F8",
    "surface": "#FFFFFF",
    "surface_alt": "#EFEFF1",
    "control_hover": "#E4E4E7",
    "input": "#FFFFFF",

    "border": "#E4E4E7",
    "border_subtle": "#ECECEF",

    "text": "#18181B",
    "text_secondary": "#52525B",
    "text_muted": "#8E8E98",

    "accent": "#4F46E5",
    "accent_hover": "#4338CA",
    "on_accent": "#FFFFFF",
    "accent_soft": "#EEF2FF",
    "on_accent_soft": "#3730A3",

    "danger": "#DC2626",
    "danger_hover": "#B91C1C",
    "danger_bg": "#FEF2F2",
    "danger_bg_hover": "#FEE2E2",
    "success": "#16A34A",
    "success_bg": "#F0FDF4",
}
