; WordCrafter Pro 2.0 - Inno Setup installer

#define AppName "WordCrafter Pro"
#define AppVersion "2.0"
#define AppPublisher "WilliamAxte"
#define AppExeName "WordCrafterPro.exe"

[Setup]
AppId={{B2A0B7A2-6B77-4F29-9B55-20D7A6D2C2F0}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} {#AppVersion}
AppPublisher={#AppPublisher}
AppPublisherURL=https://github.com/WilliamAxte/WordCrafterPro_CET
AppSupportURL=https://github.com/WilliamAxte/WordCrafterPro_CET/issues
AppUpdatesURL=https://github.com/WilliamAxte/WordCrafterPro_CET/releases
DefaultDirName={localappdata}\Programs\WordCrafterPro
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
OutputDir=installer-output
OutputBaseFilename=WordCrafterPro_v2.0_Setup
SetupIconFile=assets\app_icon.ico
UninstallDisplayIcon={app}\{#AppExeName}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
VersionInfoVersion=2.0.0.0
VersionInfoDescription=WordCrafter Pro English learning workbench
VersionInfoCopyright=Copyright (c) 2026 WilliamAxte
Uninstallable=yes

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Files]
Source: "dist\WordCrafterPro\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\{#AppName}"; Filename: "{app}\{#AppExeName}"; WorkingDir: "{app}"; IconFilename: "{app}\{#AppExeName}"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\{#AppExeName}"; WorkingDir: "{app}"; IconFilename: "{app}\{#AppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExeName}"; Description: "Launch {#AppName}"; WorkingDir: "{app}"; Flags: nowait postinstall skipifsilent
